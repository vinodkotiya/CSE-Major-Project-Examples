#! /bin/sh
#
# Private script, called from the example scripts
#

if [ $# == 0 ]
then
   echo No arguments specified!
elif [ "${ftda_CLASSPATH}" == "" ]
then
   echo ftda_CLASSPATH is not set. Please use one of the useXXXX scripts
elif [ "${ftda_MIDDLEWARE}" == "" ]
then
   echo ftda_MIDDLEWARE is not set. Please use one of the useXXXX scripts
else
   if [ "${JAVA_HOME}" == "" ]
   then
      java -classpath ${ftda_CLASSPATH} ${ftda_ORB_DEFS} $*
   else
      ${JAVA_HOME}/bin/java -classpath ${ftda_CLASSPATH} ${ftda_ORB_DEFS} $*
   fi
fi
