#! /bin/sh
#
# launches the Concurrency example

_launcher.sh ftdaTests.concurrency.${ftda_MIDDLEWARE}.Main $*
