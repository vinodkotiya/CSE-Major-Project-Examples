#! /bin/sh
#
# launches the DomainsTest example

_launcher.sh ftdaTests.domainsTest.Main $*

