#! /bin/sh
#
# launches the PerformanceGMS  example

_launcher.sh ftdaTests.performanceGMS.${ftda_MIDDLEWARE}.Main $*

