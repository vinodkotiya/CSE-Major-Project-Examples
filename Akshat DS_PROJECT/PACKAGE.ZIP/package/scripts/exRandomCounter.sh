#! /bin/sh
#
# launches the RandomCounter example

_launcher.sh ftdaTests.randomCounter.${ftda_MIDDLEWARE}.Main $*

