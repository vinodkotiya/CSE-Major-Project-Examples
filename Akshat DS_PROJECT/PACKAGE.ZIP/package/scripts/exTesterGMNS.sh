#! /bin/sh
#
# launches the TesterGMNS example

_launcher.sh ftdaTests.testerGMNS.${FTDA_MIDDLEWARE}.Main $*

