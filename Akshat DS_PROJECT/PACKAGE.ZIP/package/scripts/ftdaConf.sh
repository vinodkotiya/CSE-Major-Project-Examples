#! /bin/sh
#
# launches the program showing the Ftda Configuration 

_launcher.sh ftda.util.FtdaConf $*


