#! /bin/sh
#
# launches the GMNS server 

_launcher.sh ftda.gmns.Main $*


