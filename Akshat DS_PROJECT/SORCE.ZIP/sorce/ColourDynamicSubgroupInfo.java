package FTDATests.middleware.domainsTest;

import FTDA.middleware.domains.DynamicSubgroupInfo;

public class ColourDynamicSubgroupInfo extends FTDA.middleware.domains.DynamicSubgroupInfo
{
    public String info;
    public StateTransferType transferType;
    public ColoursStates initialState;
}
