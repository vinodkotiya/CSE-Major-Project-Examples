package FTDATests.middleware.domainsTest;

import org.omg.CORBA.ORB;
import java.util.Properties;

import FTDA.middleware.util.ORBcentral;

public class MiddlewareInitialitation
{
  public static void init(Runnable realMain, String args[]) throws Exception
  {
    ORB orb = null;
    try
    {
      orb = ORB.init(args, System.getProperties());

      if (orb!=null)
      {
        ORBcentral.setORB(orb);
        realMain.run();
        orb.run();
      }
    }
    finally
    {
      if (orb!=null)
        try {orb.destroy();}catch(Exception ex){}
    }
  }
}
