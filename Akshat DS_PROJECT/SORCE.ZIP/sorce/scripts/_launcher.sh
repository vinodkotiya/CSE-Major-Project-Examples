#! /bin/sh
#
# Private script, called from the example scripts
#

if [ $# == 0 ]
then
   echo No arguments specified!
elif [ "${SENSEI_CLASSPATH}" == "" ]
then
   echo SENSEI_CLASSPATH is not set. Please use one of the useXXXX scripts
elif [ "${SENSEI_MIDDLEWARE}" == "" ]
then
   echo SENSEI_MIDDLEWARE is not set. Please use one of the useXXXX scripts
else
   if [ "${JAVA_HOME}" == "" ]
   then
      java -classpath ${SENSEI_CLASSPATH} ${SENSEI_ORB_DEFS} $*
   else
      ${JAVA_HOME}/bin/java -classpath ${SENSEI_CLASSPATH} ${SENSEI_ORB_DEFS} $*
   fi
fi
