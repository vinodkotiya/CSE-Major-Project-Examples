#! /bin/sh
#
# launches the Chat example
#
_launcher.sh senseiTests.chat.${SENSEI_MIDDLEWARE}.Main $*
