#! /bin/sh
#
# launches the Concurrency example

_launcher.sh senseiTests.concurrency.${SENSEI_MIDDLEWARE}.Main $*
