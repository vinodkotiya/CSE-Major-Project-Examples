#! /bin/sh
#
# launches the DomainsTest example

_launcher.sh senseiTests.domainsTest.Main $*

