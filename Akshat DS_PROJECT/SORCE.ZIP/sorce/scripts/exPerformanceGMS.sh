#! /bin/sh
#
# launches the PerformanceGMS  example

_launcher.sh senseiTests.performanceGMS.${SENSEI_MIDDLEWARE}.Main $*

