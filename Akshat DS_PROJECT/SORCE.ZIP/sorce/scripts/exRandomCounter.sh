#! /bin/sh
#
# launches the RandomCounter example

_launcher.sh senseiTests.randomCounter.${SENSEI_MIDDLEWARE}.Main $*

