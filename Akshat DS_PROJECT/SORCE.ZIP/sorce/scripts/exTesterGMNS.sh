#! /bin/sh
#
# launches the TesterGMNS example

_launcher.sh senseiTests.testerGMNS.${SENSEI_MIDDLEWARE}.Main $*

