#! /bin/sh
#
# launches the GMNS server 

_launcher.sh sensei.gmns.Main $*


