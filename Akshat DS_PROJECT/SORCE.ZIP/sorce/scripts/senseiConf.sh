#! /bin/sh
#
# launches the program showing the Sensei Configuration 

_launcher.sh sensei.util.SenseiConf $*


