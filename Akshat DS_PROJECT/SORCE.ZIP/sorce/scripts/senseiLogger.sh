#! /bin/sh
#
# launches the Logger SERVER 

_launcher.sh sensei.util.logging.LoggerServer $*


