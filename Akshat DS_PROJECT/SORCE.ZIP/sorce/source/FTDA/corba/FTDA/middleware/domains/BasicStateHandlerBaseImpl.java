package FTDA.middleware.domains;

/**
  * Implementation of the BasicStateHandler CORBA interface.
  **/
public abstract class BasicStateHandlerBaseImpl extends BasicStateHandlerPOA
{

  public BasicStateHandlerBaseImpl() throws Exception
  {
    this(true);
  }

  public BasicStateHandlerBaseImpl(boolean active) throws Exception
  {
    if (active)
      activate();
  }

  public void activate() throws Exception
  {
    if (thisBasicStateHandler==null)
    {
      id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
      thisBasicStateHandler = BasicStateHandlerHelper.narrow
          (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
    }
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (thisBasicStateHandler!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      thisBasicStateHandler=null;
    }
  }

  public final BasicStateHandler theBasicStateHandler()
  {
    return thisBasicStateHandler;
  }

  protected BasicStateHandler thisBasicStateHandler;
  byte[] id;
};

