package FTDA.middleware.domains;

/**
  * Implementation of the Checkpointable CORBA interface.
  **/
public abstract class CheckpointableBaseImpl extends CheckpointablePOA
{

  public CheckpointableBaseImpl() throws Exception
  {
    this(true);
  }

  public CheckpointableBaseImpl(boolean active) throws Exception
  {
    if (active)
      activate();
  }

  public void activate() throws Exception
  {
    if (thisCheckpointable==null)
    {
      id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
      thisCheckpointable = CheckpointableHelper.narrow
          (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
    }
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (thisCheckpointable!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      thisCheckpointable=null;
    }
  }

  public final Checkpointable theCheckpointable()
  {
    return thisCheckpointable;
  }

  protected Checkpointable thisCheckpointable;
  byte[] id;
};

