package FTDA.middleware.domains;

/**
  * Implementation of the CoordinatorElector CORBA interface.
  **/
public abstract class CoordinatorElectorBaseImpl extends CoordinatorElectorPOA
{

  public CoordinatorElectorBaseImpl() throws Exception
  {
    this(true);
  }

  public CoordinatorElectorBaseImpl(boolean active) throws Exception
  {
    if (active)
      activate();
  }

  public void activate() throws Exception
  {
    if (thisCoordinatorElector==null)
    {
      id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
      thisCoordinatorElector = CoordinatorElectorHelper.narrow
          (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
    }
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (thisCoordinatorElector!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      thisCoordinatorElector=null;
    }
  }

  public final CoordinatorElector theCoordinatorElector()
  {
    return thisCoordinatorElector;
  }

  protected CoordinatorElector thisCoordinatorElector;
  byte[] id;
};

