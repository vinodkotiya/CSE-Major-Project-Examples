package FTDA.middleware.domains;

/**
  * Implementation of the GroupMember CORBA interface.
  **/
public abstract class DomainGroupHandlerBaseImpl extends DomainGroupHandlerPOA
{

  public DomainGroupHandlerBaseImpl() throws Exception
  {
    this(true);
  }

  public DomainGroupHandlerBaseImpl(boolean active) throws Exception
  {
    if (active)
      activate();
  }

  public void activate() throws Exception
  {
    if (thisDomainGroupHandler==null)
    {
      id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
      thisDomainGroupHandler = DomainGroupHandlerHelper.narrow
          (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
    }
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (thisDomainGroupHandler!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      thisDomainGroupHandler=null;
    }
  }

  public final DomainGroupHandler theDomainGroupHandler()
  {
    return thisDomainGroupHandler;
  }

  protected DomainGroupHandler thisDomainGroupHandler;
  byte[] id;
};

