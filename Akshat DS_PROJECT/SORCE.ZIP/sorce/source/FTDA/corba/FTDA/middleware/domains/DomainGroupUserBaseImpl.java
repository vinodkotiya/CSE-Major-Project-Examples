package FTDA.middleware.domains;

/**
  * Implementation of the DomainGroupUser CORBA interface.
  **/
public abstract class DomainGroupUserBaseImpl extends DomainGroupUserPOA
{

  public DomainGroupUserBaseImpl() throws Exception
  {
    this(true);
  }

  public DomainGroupUserBaseImpl(boolean active) throws Exception
  {
    if (active)
      activate();
  }

  public void activate() throws Exception
  {
    if (thisDomainGroupUser==null)
    {
      id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
      thisDomainGroupUser = DomainGroupUserHelper.narrow
          (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
    }
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (thisDomainGroupUser!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      thisDomainGroupUser=null;
    }
  }

  public final DomainGroupUser theDomainGroupUser()
  {
    return thisDomainGroupUser;
  }

  protected DomainGroupUser thisDomainGroupUser;
  byte[] id;
};

