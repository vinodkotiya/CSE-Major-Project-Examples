package FTDA.middleware.domains;

import FTDA.middleware.gms.GroupMember;

/**
  * Utility class performing narrow operations for Domain middleware objects
  **/
public class DomainsNarrower
{

  final static org.omg.CORBA.Object toObject(Object object)
  {
    return object instanceof org.omg.CORBA.Object? (org.omg.CORBA.Object) object : null;
  }

  public final static boolean isObjectNotExistException(Exception ex)
  {
    return ex instanceof org.omg.CORBA.OBJECT_NOT_EXIST;
  }

  public final static DomainGroupHandler toDomainGroupHandler(Object object)
  {
    DomainGroupHandler ret = null;
    try
    {
      ret = DomainGroupHandlerHelper.narrow(toObject(object));
    }
    catch(Exception ex)
    {
      ret=null;
    }
    return ret;
  }

  public final static Checkpointable toCheckpointable(Object object)
  {
    Checkpointable ret = null;
    try
    {
      ret = CheckpointableHelper.narrow(toObject(object));
    }
    catch(Exception ex)
    {
      ret=null;
    }
    return ret;
  }

  public final static ExtendedCheckpointable toExtendedCheckpointable(Object object)
  {
    ExtendedCheckpointable ret = null;
    try
    {
      ret = ExtendedCheckpointableHelper.narrow(toObject(object));
    }
    catch(Exception ex)
    {
      ret=null;
    }
    return ret;
  }

  public final static StateHandler toStateHandler(Object object)
  {
    StateHandler ret = null;
    try
    {
      ret = StateHandlerHelper.narrow(toObject(object));
    }
    catch(Exception ex)
    {
      ret=null;
    }
    return ret;
  }

  public final static BasicStateHandler toBasicStateHandler(Object object)
  {
    BasicStateHandler ret = null;
    try
    {
      ret = BasicStateHandlerHelper.narrow(toObject(object));
    }
    catch(Exception ex)
    {
      ret=null;
    }
    return ret;
  }

};

