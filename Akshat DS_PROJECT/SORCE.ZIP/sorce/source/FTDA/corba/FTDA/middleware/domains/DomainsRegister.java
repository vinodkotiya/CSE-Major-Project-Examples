package FTDA.middleware.domains;

import FTDA.middleware.util.ORBcentral;

import org.omg.CORBA.portable.ValueFactory;
import org.omg.CORBA_2_3.ORB;
import org.omg.CORBA_2_3.portable.InputStream;


/**
  * Class registering valuetypes for the domain corba definitions
  **/
public class DomainsRegister
{

//*************************************************************************************//
//**************************** ORB REGISTERING ****************************************//
//*************************************************************************************//
  private DomainsRegister(){} //cannot be instanciated!
  static public void register(){} //Next lines are automatically invoked
  static
  {
    ORB orb = ((ORB)(ORBcentral.getORB()));
    orb.register_value_factory
    (
      MessagePHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new MessageP(){});}}
    );
    orb.register_value_factory
    (
      MessageCHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new MessageC(){});}}
    );
    orb.register_value_factory
    (
      MessageEHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new MessageE(){});}}
    );
    orb.register_value_factory
    (
      MessageSHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new MessageS(){});}}
    );
    orb.register_value_factory
    (
      MessageMemberPropertiesHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new MessageMemberProperties(){});}}
    );
    orb.register_value_factory
    (
      MessageCreateSubgroupHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new MessageCreateSubgroup(){});}}
    );
    orb.register_value_factory
    (
      MessageRemoveSubgroupHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new MessageRemoveSubgroup(){});}}
    );
    orb.register_value_factory
    (
      DynamicSubgroupInfoHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new DynamicSubgroupInfo(){});}}
    );
    orb.register_value_factory
    (
      DynamicSubgroupInfoAsStringHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new DynamicSubgroupInfoAsString(){});}}
    );
    orb.register_value_factory
    (
      PhaseCoordinationHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new PhaseCoordination(){});}}
    );
    orb.register_value_factory
    (
      EndOfTransactionMessageHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new EndOfTransactionMessage(){});}}
    );
    orb.register_value_factory
    (
      MonitorMessageHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new MonitorMessage(){});}}
    );
    orb.register_value_factory
    (
      MonitorStateHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new MonitorState(){});}}
    );
  }
}
