package FTDA.middleware.domains;

/**
  * Implementation of the DomainGroupUser CORBA interface.
  **/
public abstract class DynamicSubgroupsUserBaseImpl extends DynamicSubgroupsUserPOA
{

  public DynamicSubgroupsUserBaseImpl() throws Exception
  {
    this(true);
  }

  public DynamicSubgroupsUserBaseImpl(boolean active) throws Exception
  {
    if (active)
      activate();
  }

  public void activate() throws Exception
  {
    if (thisDynamicSubgroupsUser==null)
    {
      id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
      thisDynamicSubgroupsUser = DynamicSubgroupsUserHelper.narrow
          (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
    }
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (thisDynamicSubgroupsUser!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      thisDynamicSubgroupsUser=null;
    }
  }

  public final DynamicSubgroupsUser theDynamicSubgroupsUser()
  {
    return thisDynamicSubgroupsUser;
  }

  protected DynamicSubgroupsUser thisDynamicSubgroupsUser;
  byte[] id;
};

