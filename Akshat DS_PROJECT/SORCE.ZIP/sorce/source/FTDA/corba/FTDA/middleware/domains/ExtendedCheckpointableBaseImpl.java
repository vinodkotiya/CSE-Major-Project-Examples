package FTDA.middleware.domains;

/**
  * Implementation of the ExtendedCheckpointable CORBA interface.
  **/
public abstract class ExtendedCheckpointableBaseImpl extends ExtendedCheckpointablePOA
{

  public ExtendedCheckpointableBaseImpl() throws Exception
  {
    this(true);
  }

  public ExtendedCheckpointableBaseImpl(boolean active) throws Exception
  {
    if (active)
      activate();
  }

  public void activate() throws Exception
  {
    if (thisExtendedCheckpointable==null)
    {
      id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
      thisExtendedCheckpointable = ExtendedCheckpointableHelper.narrow
          (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
    }
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (thisExtendedCheckpointable!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      thisExtendedCheckpointable=null;
    }
  }

  public final ExtendedCheckpointable theExtendedCheckpointable()
  {
    return thisExtendedCheckpointable;
  }

  protected ExtendedCheckpointable thisExtendedCheckpointable;
  byte[] id;
};

