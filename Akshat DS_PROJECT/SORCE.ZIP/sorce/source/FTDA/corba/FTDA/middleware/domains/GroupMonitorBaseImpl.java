package FTDA.middleware.domains;

import FTDA.middleware.util.ORBcentral;

/**
  * Monitor implementation on a replicated environment
  **/
public abstract class GroupMonitorBaseImpl extends GroupMonitorPOA
{

//*************************************************************************************//
//**************************** CONSTRUCTOR ********************************************//
//*************************************************************************************//

  public GroupMonitorBaseImpl() throws Exception
  {
    this(true);
  }

  public GroupMonitorBaseImpl(boolean active) throws Exception
  {
    if (active)
      activate();
  }

  public void activate() throws Exception
  {
    if (thisGroupMonitor==null)
    {
      id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
      thisGroupMonitor = GroupMonitorHelper.narrow
          (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
    }
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (id!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      id=null;
    }
  }

  public final GroupMonitor theGroupMonitor()
  {
    return thisGroupMonitor;
  }

//*************************************************************************************//
//**************************** DATA MEMBERS *******************************************//
//*************************************************************************************//

  protected GroupMonitor thisGroupMonitor;
  byte[] id;
}
