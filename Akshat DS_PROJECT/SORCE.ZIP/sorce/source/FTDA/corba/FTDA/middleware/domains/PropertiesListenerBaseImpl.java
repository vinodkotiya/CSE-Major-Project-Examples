package FTDA.middleware.domains;

/**
  * Implementation of the DomainGroupUser CORBA interface.
  **/
public abstract class PropertiesListenerBaseImpl extends PropertiesListenerPOA
{

  public PropertiesListenerBaseImpl() throws Exception
  {
    this(true);
  }

  public PropertiesListenerBaseImpl(boolean active) throws Exception
  {
    if (active)
      activate();
  }

  public void activate() throws Exception
  {
    if (thisPropertiesListener==null)
    {
      id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
      thisPropertiesListener = PropertiesListenerHelper.narrow
          (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
    }
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (thisPropertiesListener!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      thisPropertiesListener=null;
    }
  }

  public final PropertiesListener thePropertiesListener()
  {
    return thisPropertiesListener;
  }

  protected PropertiesListener thisPropertiesListener;
  byte[] id;
};

