package FTDA.middleware.domains;

/**
  * Implementation of the StateHandler CORBA interface.
  **/
public abstract class StateHandlerBaseImpl extends StateHandlerPOA
{

  public StateHandlerBaseImpl() throws Exception
  {
    this(true);
  }

  public StateHandlerBaseImpl(boolean active) throws Exception
  {
    if (active)
      activate();
  }

  public void activate() throws Exception
  {
    if (thisStateHandler==null)
    {
      id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
      thisStateHandler = StateHandlerHelper.narrow
          (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
    }
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (thisStateHandler!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      thisStateHandler=null;
    }
  }

  public final StateHandler theStateHandler()
  {
    return thisStateHandler;
  }

  protected StateHandler thisStateHandler;
  byte[] id;
};

