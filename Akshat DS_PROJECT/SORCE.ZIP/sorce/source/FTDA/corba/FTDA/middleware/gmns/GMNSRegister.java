package FTDA.middleware.gmns;

import FTDA.middleware.util.ORBcentral;

import java.util.Properties;

import org.omg.CORBA.portable.ValueFactory;
import org.omg.CORBA_2_3.ORB;
import org.omg.CORBA_2_3.portable.InputStream;

/**
  * Class to register the valuetypes on the ORB
  **/
public class GMNSRegister
{
  //*************************************************************************************
  //**************************** ORB REGISTERING ****************************************
  //*************************************************************************************

  public GMNSRegister(GMNSMain mainClass, String args[], boolean graphicalMode)
  {
    org.omg.CORBA.ORB orb = null;
    try
    {
      Properties props = System.getProperties();
      orb = org.omg.CORBA.ORB.init(args, props);

      ORBcentral.setORB(orb);
      register();
      mainClass.runGMNS(graphicalMode);
      orb.run();
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
    }
    if (orb!=null)
      try {orb.destroy();}catch(Exception ex){}
  }

  void register()
  {
    ORB orb = ((ORB)(ORBcentral.getORB()));
    orb.register_value_factory
    (
      GroupHandlerFactoryCreatorHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new GroupHandlerFactoryCreatorImpl());}}
    );
    orb.register_value_factory
    (
      MapStringSetPutMessageHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new MapStringSetPutMessage(){});}}
    );
    orb.register_value_factory
    (
      MapStringSetRemoveMessageHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new MapStringSetRemoveMessage(){});}}
    );
    orb.register_value_factory
    (
      MapStringSetStateHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new MapStringSetState(){});}}
    );
    orb.register_value_factory
    (
      SetMemberInfoChangedMessageHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new SetMemberInfoChangedMessage(){});}}
    );
    orb.register_value_factory
    (
      SetMemberInfoStateHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new SetMemberInfoState(){});}}
    );
    orb.register_value_factory
    (
      GroupsCheckerStateHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new GroupsCheckerState(){});}}
    );
  }
}

