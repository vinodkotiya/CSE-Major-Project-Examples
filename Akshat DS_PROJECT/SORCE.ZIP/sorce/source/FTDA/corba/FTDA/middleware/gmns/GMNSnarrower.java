package FTDA.middleware.gmns;

/**
  * Utility class performing narrow operations for GMNS middleware objects
  **/
public class GMNSnarrower
{

  public final static org.omg.CORBA.Object toObject(Object object)
  {
    return object instanceof org.omg.CORBA.Object? (org.omg.CORBA.Object) object : null;
  }

  public final static SetMemberInfo toSetMemberInfo(Object object)
  {
    SetMemberInfo ret = null;
    try
    {
      ret = SetMemberInfoHelper.narrow(toObject(object));
    }
    catch(Exception ex)
    {
      ret=null;
    }
    return ret;
  }

  public final static GroupHandlerFactory toGroupHandlerFactory(Object object)
  {
    GroupHandlerFactory ret = null;
    try
    {
      ret = GroupHandlerFactoryHelper.narrow(toObject(object));
    }
    catch(Exception ex)
    {
      ret=null;
    }
    return ret;
  }

  public final static GroupMembershipBasicService toGroupMembershipBasicService(Object object)
  {
    GroupMembershipBasicService ret = null;
    try
    {
      ret = GroupMembershipBasicServiceHelper.narrow(toObject(object));
    }
    catch(Exception ex)
    {
      ret=null;
    }
    return ret;
  }

  public final static GroupMembershipNamingService toGroupMembershipNamingService(Object object)
  {
    GroupMembershipNamingService ret = null;
    try
    {
      ret = GroupMembershipNamingServiceHelper.narrow(toObject(object));
    }
    catch(Exception ex)
    {
      ret=null;
    }
    return ret;
  }

  public final static ReplicatedServer toReplicatedServer(Object object)
  {
    ReplicatedServer ret = null;
    try
    {
      ret = ReplicatedServerHelper.narrow(toObject(object));
    }
    catch(Exception ex)
    {
      ret=null;
    }
    return ret;
  }

};

