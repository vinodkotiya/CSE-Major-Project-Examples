package FTDA.middleware.gmns;

import FTDA.middleware.gms.GroupMember;

/**
  * Class (not interface) that creates GroupHandlerFactories on
  *	demand. This is not a remote object, the intention is to
  *	create the GroupHandler in the local memory belonging to the
  *	group member, and therefore avoid new points of failure.
  *	If the GroupHandler would be created directly by any of the
  *	membership services, the failure of the service would suppose
  *	the failure of the associated GroupMember
  **/
public class GroupHandlerFactoryCreatorImpl extends GroupHandlerFactoryCreator
{
  /**
    * Creates a new handler factory for the given member
    **/
  public GroupHandlerFactory create(GroupMember member) throws GroupHandlerFactoryException
  {
    GroupHandlerFactory ret = null;
    try
    {
      ret = new GroupHandlerFactoryImpl(member).theGroupHandlerFactory();
    }
    catch (Exception ex)
    {
      ret=null;
      throw new GroupHandlerFactoryException(ex.getMessage());
    }
    return ret;
  }
}
