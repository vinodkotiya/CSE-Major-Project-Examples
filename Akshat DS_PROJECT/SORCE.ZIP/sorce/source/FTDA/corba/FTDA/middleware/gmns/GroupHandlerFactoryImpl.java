package FTDA.middleware.gmns;

import FTDA.gms.ActiveGroupMember;
import FTDA.middleware.gms.GroupMember;
import FTDA.middleware.gms.GroupHandler;

/**
  * Implementation of the GroupHandlerFactory
  **/
public class GroupHandlerFactoryImpl extends GroupHandlerFactoryPOA
{
  public GroupHandlerFactoryImpl(GroupMember member) throws Exception
  {
    this.member = member;
    id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
    thisGroupHandlerFactory = GroupHandlerFactoryHelper.narrow
        (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (thisGroupHandlerFactory!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      thisGroupHandlerFactory=null;
    }
  }

  public final GroupHandlerFactory theGroupHandlerFactory()
  {
    return thisGroupHandlerFactory;
  }

  /**
    * Creates a new handler. Returns null if no handle can be created
    **/
  public GroupHandler create() throws GroupHandlerFactoryException
  {
    GroupHandler ret = null;
    try
    {
      ret = new ActiveGroupMember(member).theFTDAGMSMember();
    }
    catch (Exception ex)
    {
      ret=null;
      throw new GroupHandlerFactoryException(ex.getMessage());
    }
    return ret;
  }

  GroupMember member;
  protected GroupHandlerFactory thisGroupHandlerFactory;
  byte[] id;
}
