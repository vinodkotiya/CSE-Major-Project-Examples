package FTDA.middleware.gmns;

/**
  * Implementation of the GroupMembershipBasicService
  **/
public abstract class GroupMembershipBasicServiceBaseImpl extends GroupMembershipBasicServicePOA
{
  public GroupMembershipBasicServiceBaseImpl() throws Exception
  {
    id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
    thisGroupMembershipBasicService = GroupMembershipBasicServiceHelper.narrow
        (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (thisGroupMembershipBasicService!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      thisGroupMembershipBasicService=null;
    }
  }

  public final GroupMembershipBasicService theGroupMembershipBasicService()
  {
    return thisGroupMembershipBasicService;
  }

  protected GroupMembershipBasicService thisGroupMembershipBasicService;
  byte[] id;
};
