package FTDA.middleware.gmns;

/**
  * Implementation of the GroupMembershipNamingService
  **/
public abstract class GroupMembershipNamingServiceBaseImpl extends GroupMembershipNamingServicePOA
{
  public GroupMembershipNamingServiceBaseImpl() throws Exception
  {
    id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
    thisGroupMembershipNamingService = GroupMembershipNamingServiceHelper.narrow
        (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (thisGroupMembershipNamingService!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      thisGroupMembershipNamingService=null;
    }
  }

  public final GroupMembershipNamingService theGroupMembershipNamingService()
  {
    return thisGroupMembershipNamingService;
  }

  protected GroupMembershipNamingService thisGroupMembershipNamingService;
  byte[] id;
};
