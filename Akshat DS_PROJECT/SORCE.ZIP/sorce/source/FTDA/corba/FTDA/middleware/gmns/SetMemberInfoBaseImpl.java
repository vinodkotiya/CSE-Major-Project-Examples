package FTDA.middleware.gmns;

/**
  * Implementation of the SetMemberInfo
  **/
public abstract class SetMemberInfoBaseImpl extends SetMemberInfoPOA
{
  public SetMemberInfoBaseImpl() throws Exception
  {
    id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
    thisSetMemberInfo = SetMemberInfoHelper.narrow
        (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (thisSetMemberInfo!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      thisSetMemberInfo=null;
    }
  }

  public final SetMemberInfo theSetMemberInfo()
  {
    return thisSetMemberInfo;
  }

  protected SetMemberInfo thisSetMemberInfo;
  byte[] id;
};
