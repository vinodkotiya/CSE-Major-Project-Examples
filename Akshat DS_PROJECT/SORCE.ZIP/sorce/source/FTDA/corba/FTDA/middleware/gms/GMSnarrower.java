package FTDA.middleware.gms;

/**
  * Utility class performing narrow operations for GMS middleware objects
  **/
public class GMSnarrower
{
	
	public final static org.omg.CORBA.Object toObject(Object object)
	{
		return object instanceof org.omg.CORBA.Object? (org.omg.CORBA.Object) object : null;
	}
	
	public final static GroupHandler toGroupHandler(Object object)
	{
		GroupHandler ret = null;
		try
		{
			ret = GroupHandlerHelper.narrow(toObject(object));
		}
		catch(Exception ex)
		{
			ret=null;
		}
		return ret;
	}
	
	public final static GroupMember toGroupMember(Object object)
	{
		GroupMember ret = null;
		try
		{
			ret = GroupMemberHelper.narrow(toObject(object));
		}
		catch(Exception ex)
		{
			ret=null;
		}
		return ret;
	}
	
	public final static FTDAGMSMember toFTDAGMSMember(Object object)
	{
		FTDAGMSMember ret = null;
		try
		{
			ret = FTDAGMSMemberHelper.narrow(toObject(object));
		}
		catch(Exception ex)
		{
			ret=null;
		}
		return ret;
	}
	
};
  
