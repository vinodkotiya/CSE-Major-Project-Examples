package FTDA.middleware.gms;

/**
  * Class implementing the CORBA interface for the GroupMember.
  **/
public abstract class GroupMemberImpl extends GroupMemberPOA
{
  public GroupMemberImpl() throws Exception
  {
    this(true);
  }

  public GroupMemberImpl(boolean active) throws Exception
  {
    if (active)
      activate();
  }

  public void activate() throws Exception
  {
    if (thisGroupMember==null)
    {
      id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
      thisGroupMember = GroupMemberHelper.narrow
          (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
    }
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (id!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      id=null;
    }
  }

  public final GroupMember theGroupMember()
  {
    return thisGroupMember;
  }

  protected GroupMember	thisGroupMember;
  byte[] id;
};

