package FTDA.middleware.gms;

/**
  * Class implementing the CORBA interface for the GroupMember.
  **/
public abstract class FTDAGMSMemberImpl extends FTDAGMSMemberPOA
{
  public FTDAGMSMemberImpl() throws Exception
  {
    this(true);
  }

  public FTDAGMSMemberImpl(boolean active) throws Exception
  {
    if (active)
      activate();
  }

  public void activate() throws Exception
  {
    if (thisFTDAGMSMember==null)
    {
      id = FTDA.middleware.util.ORBcentral.getPOA().activate_object(this);
      thisFTDAGMSMember = FTDAGMSMemberHelper.narrow
          (FTDA.middleware.util.ORBcentral.getPOA().id_to_reference(id));
    }
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (id!=null)
        FTDA.middleware.util.ORBcentral.getPOA().deactivate_object(id);
      id=null;
    }
  }

  public final FTDAGMSMember theFTDAGMSMember()
  {
    return thisFTDAGMSMember;
  }

  FTDAGMSMember thisFTDAGMSMember;
  byte[] id;
};

