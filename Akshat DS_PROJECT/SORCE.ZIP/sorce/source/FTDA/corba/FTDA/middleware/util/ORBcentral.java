package FTDA.middleware.util;

import FTDA.util.Consts;
import FTDA.util.Error;

import org.omg.CORBA.ORB;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;

/**
  * Utility class which main purpose is to store centrally the ORB
  *	instance. It includes additional functionality around this basic
  *	one, like POA handling
  **/
public class ORBcentral
{

//*************************************************************************************//
//**************************** SET ORB ************************************************//
//*************************************************************************************//

  /**
    * Stores the ORB to be used by FTDA corba objects. It can be set only once.
    **/
  static public void setORB(ORB orb)
  {
    assert ORBcentral.orb==null;
    ORBcentral.orb = orb;
  }

//*************************************************************************************//
//**************************** GET ORB ************************************************//
//*************************************************************************************//

  /**
    * Retrieves the ORB set, which must be already set (an assertion is raised otherwise)
    **/
  static public ORB getORB()
  {
    assert ORBcentral.orb!=null;
    return orb;
  }

//*************************************************************************************//
//**************************** SET POA ************************************************//
//*************************************************************************************//

  /**
    * Stores the POA to be used by FTDA corba objects. It can be set only once.
    * Classes can retrieve the stored POA with getPOA. If that function is used
    * before setPOA is called, the rootPOA is used by default, and is considered to
    * be the set POA, that is, an assertion is equally raised if setPOA is called.
    **/
  static public void setPOA(POA poa)
  {
    assert ORBcentral.poa==null;
    ORBcentral.poa = poa;
  }

//*************************************************************************************//
//**************************** GET POA ************************************************//
//*************************************************************************************//

  /**
    * Retrieves the POA set. If not yet set, the default POA is used instead (root POA),
    * and it's directly activated.
    **/
  static public POA getPOA()
  {
    if (poa == null)
    {
      try
      {
        poa = POAHelper.narrow(getORB().resolve_initial_references("RootPOA"));
        assert poa!=null;
        poa.the_POAManager().activate();
      }
      catch(Exception ex)
      {
        Error.unhandledException(Consts.AREA_NAME, ex);
      }
    }
    return ORBcentral.poa;
  }


//*************************************************************************************//
//**************************** DATA MEMBERS *******************************************//
//*************************************************************************************//

  static ORB orb = null;
  static POA poa = null;
}
