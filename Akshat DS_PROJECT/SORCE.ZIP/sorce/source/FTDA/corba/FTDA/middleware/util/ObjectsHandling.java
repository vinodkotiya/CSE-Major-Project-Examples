package FTDA.middleware.util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
  * Class utility implementing object persistence for CORBA objects
  **/
public class ObjectsHandling
{

//*************************************************************************************//
//**************************** WRITE OBJECT *******************************************//
//*************************************************************************************//

  /**
    * @param object the corba object to store, which must be a valid corba object (activated)
    * @param outputStream the stream to write the reference of this member.
    **/
  static public void writeObject(org.omg.CORBA.Object object, OutputStream stream) throws IOException
  {
    DataOutputStream dos = new DataOutputStream(stream);
    dos.writeUTF(ORBcentral.getORB().object_to_string(object));
  }

//*************************************************************************************//
//**************************** WRITE OBJECT *******************************************//
//*************************************************************************************//

  /**
    * @param object the remote object to store, which must habe been previously exported
    * @param fileName the name of the file where the reference is stored
    **/
  static public void writeObject(org.omg.CORBA.Object object, String fileName) throws IOException
  {
    FileOutputStream file=null;
    try
    {
      file = new FileOutputStream(fileName);
      writeObject(object, file);
    }
    finally
    {
      if (file!=null)
        file.close();
    }
  }

//*************************************************************************************//
//**************************** READ OBJECT ********************************************//
//*************************************************************************************//

  /**
    * @param inputStream the stream to write the reference of this member.
    * @returns the object read
    **/
  static public org.omg.CORBA.Object readObject(InputStream stream) throws IOException
  {
    DataInputStream dis = new DataInputStream (stream);
    return ORBcentral.getORB().string_to_object(dis.readUTF());
  }

//*************************************************************************************//
//**************************** READ OBJECT ********************************************//
//*************************************************************************************//

  /**
    * @param fileName the name of the file where the reference is stored
    * @returns the object read
    **/
  static public org.omg.CORBA.Object readObject(String fileName) throws IOException
  {
    org.omg.CORBA.Object ret = null;
    FileInputStream file=null;
    try
    {
      file = new FileInputStream(fileName);
      ret = readObject(file);
    }
    finally
    {
      if (file!=null)
        file.close();
    }
    return ret;
  }

//*************************************************************************************//
//**************************** ARE EQUIVALENT *****************************************//
//*************************************************************************************//

  /**
    * check if the two specified objects are equivalents
    **/
  static public boolean areEquivalent(org.omg.CORBA.Object left, org.omg.CORBA.Object right)
  {
    return left==null? right==null : left._is_equivalent(right);
  }

}
