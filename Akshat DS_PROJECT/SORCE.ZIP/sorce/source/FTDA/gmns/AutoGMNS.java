package ftda.gmns;

import ftda.gms.ActiveGroupMember;
import ftda.util.Configuration;
import ftda.util.Error;
import ftda.util.ShutdownHook;
import ftda.util.ShutdownHooker;

import ftda.middleware.gms.GMSnarrower;
import ftda.middleware.gms.GroupHandler;
import ftda.middleware.gms.GroupMember;
import ftda.middleware.gms.ftdaGMSMember;
import ftda.middleware.gmns.GroupMembershipNamingService;
import ftda.middleware.util.ObjectsHandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
  * Class to perform the GMNS functions in absence of a GMNS: needed for the GMNS itself
  * It does his job using configuration values, like sockets/ports & common files
  **/
class AutoGMNS implements ShutdownHooker
{

  /***********************************************************************************************/
  /********************** CONSTRUCTOR ************************************************************/
  /***********************************************************************************************/

  /**
   * Creates / joins a group for the given member.
   */
  public AutoGMNS(GroupMember member, GroupMembershipNamingService service) throws GMNSregistrationException, Exception
  {
    Trace.code("AutoGMNS.java -> AutoGMNS ( GroupMember member , GroupMembershipNamingService service )");
    conformGroup(member, service);
  }

  /***********************************************************************************************/
  /********************** SHUTTING DOWN **********************************************************/
  /***********************************************************************************************/

  /**
    * This method is called when the Java VM is shutting down.
    **/
  public void shuttingDown()
  {
    Trace.code("AutoGMNS.java -> void shuttingDown ( )");
    try{handler.leaveGroup();}catch(Exception ex){}
  }

  /***********************************************************************************************/
  /********************** CONFORM GROUP **********************************************************/
  /***********************************************************************************************/

  /**
    * Writes into the file specified this reference (the group handler reference)
    **/
  private void conformGroup(GroupMember member, GroupMembershipNamingService service)
    throws GMNSregistrationException, Exception
  {
    Trace.code("AutoGMNS.java -> void conformGroup ( GroupMember member , GroupMembershipNamingService service )");
    //the discovery of other GMLS members is done through the GMLSAutoLocation functionality
    AutoLocation locator = new AutoLocation();
    boolean joining=true;
    do
    {
      //create the member for this handler
      handler = new ActiveGroupMember(member).theftdaGMSMember();

      Configuration properties=Configuration.getSingleton();
      //the references for this server must be published, if the file or socket are available!
      if (properties.isGMNSReferencePublishedBySocket())
        publishReferences(handler, service, properties.getGMNSReferencePort());
      else
        persistReferences(handler, service, properties.getGMNSReferenceFile());

      try
      {
        GroupHandler toJoin = locator.locateGroupHandler(handler, properties.getGMNSHosts());
        if (toJoin==null)
        {
          //no gmns to join -> create a group
          joining = !handler.createGroup();

          //if it's false, its belong already to a group, but that is not possible
          assert !joining;
        }
        else
        {
          joining=!handler.joinGroup(GMSnarrower.toftdaGMSMember(toJoin));
          //if it's false, the toJoin member is falling down or it's directly our member
          //who is thought to be falling down, repeat the process.
        }
      }
      catch (InterruptedException iex)
      {
        Error.unhandledException(Consts.AREA, iex);
      }
      catch(Exception ex)
      {
        Trace.handledException(ex);
        joining = true;
      }
    }
    while (joining);
  }

  /***********************************************************************************************/
  /********************** PERSIST REFERENCES *****************************************************/
  /***********************************************************************************************/

  /**
    * Writes into the file specified this reference (the group handler reference) and the
    * reference for the group member naming service
    * @exception GMNSexistingException if file contains a valid GMNS
    **/
  private void persistReferences(GroupHandler handler, GroupMembershipNamingService service, File file)
      throws GMNSregistrationException
  {
    Trace.code("AutoGMNS.java -> void persistReferences ( GroupHandler handler , GroupMembershipNamingService service , File file )");
    checkFile(file);
    FileOutputStream fo = null;
    try
    {
      fo=new FileOutputStream(file);
      ObjectsHandling.writeObject(handler, fo);
      ObjectsHandling.writeObject(service, fo);
      file.deleteOnExit();	//on termination, this file is removed
    }
    catch(IOException ioex)
    {
      throw new GMNSregistrationException(ioex);
    }
    finally
    {
      if (fo!=null)
        try{fo.close();}catch(Exception ex){}
    }

  }

  /***********************************************************************************************/
  /********************** PUBLISH REFERENCES *****************************************************/
  /***********************************************************************************************/

  private void publishReferences(GroupHandler handler, GroupMembershipNamingService service, int port)
    throws GMNSregistrationException
  {
    Trace.code("AutoGMNS.java -> void publishReferences ( GroupHandler handler , GroupMembershipNamingService service , int port )");
    try
    {
      new GMNSreferencePublisher((ftdaGMSMember) handler, service, port);
    }
    catch(IOException ioex)
    {
      throw new GMNSregistrationException(ioex);
    }
  }

  /***********************************************************************************************/
  /********************** CHECK FILE *************************************************************/
  /***********************************************************************************************/

  /**
    * Checks that the specified file does not contain a valid GroupHandler
    * @exception GMNSexistingException if file contains a valid GMNS
    **/
  private void checkFile(File file) throws GMNSregistrationException
  {
    Trace.code("AutoGMNS.java -> void checkFile ( File file )");
    FileInputStream fi = null;
    boolean bad=false;
    try
    {
      fi=new FileInputStream(file);
      Object o = ObjectsHandling.readObject(fi);
      if (GMSnarrower.toftdaGMSMember(o).isValidGroup())
        bad = true;
    }
    catch (Exception ex)
    {
      Trace.handledException(ex);
    }
    finally
    {
      if (fi!=null)
        try{fi.close();}catch(Exception ex){}
    }
    if (bad)
      throw new GMNSregistrationException(file.toString());
  }

    ftdaGMSMember handler; //this member!
}
