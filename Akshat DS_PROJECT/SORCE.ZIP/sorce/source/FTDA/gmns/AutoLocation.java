package ftda.gmns;

import ftda.util.Configuration;

import ftda.middleware.gms.GMSnarrower;
import ftda.middleware.gms.GroupHandler;
import ftda.middleware.util.ObjectsHandling;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.URL;

/**
  * Class implementing a location service for GroupHandlers
	*          	The GMNS gives a location service, but it must locate itself the other
  *	members of its own group. This class defines a generic method to look
  *	for another GroupHandler. The protocol is simple:
  *	It needs the handler looking for another handler. This allows to
  *		decide in the case that several GroupHandlers are being created
  *		at same time. It also requires the validLocations where another
  *		GroupHandler's references are stored.
  *	-If any of the others locations contains a valid GroupHandler, it is
  *		returned.
  *	-If no other locations contain valid GroupHandlers, it is returned null.
  *	-If only other GroupHandlers being activated are found, it is checked
  *		if this one has the highest memberId. If so, it is considered to have
  *		priority on the activation and it is returned null.
  *	-If this one has not the priority, it will wait for some specific amount
  *		of time and then it will start again the search. This could eventually
  *		produce some deadlock if some GroupHandler is behaving incorrectly, but
  *		that is not a normal case and could always be studied on the trace
  **/
class AutoLocation
{

//*************************************************************************************//
//**************************** LOCATE GROUP HANDLER ***********************************//
//*************************************************************************************//

  /**
    * Searchs for a valid GroupHandler in the locations specified. It returns null if there are
    * no valid Group Handlers.
    * @param thisHandler The GroupHandler locating other members.
    * @returns the associated GroupMember
    **/
  public synchronized GroupHandler locateGroupHandler(GroupHandler thisHandler, Configuration.GMNShost validLocations[]) throws InterruptedException
  {
    Trace.code("AutoLocation.java -> synchronized GroupHandler locateGroupHandler ( GroupHandler thisHandler , Configuration.GMNShost validLocations [ ] )");
    groupHandler = null;
    boolean searching = true;
    while(searching)
      switch (search(thisHandler, validLocations))
      {
        case NO_VALID_HANDLER:
        case ACTIVATING_HANDLER:
          //there is no valid GroupMemberLocationService, or there is some one which is being
          //activated and that will wait for the activation of this member. The search is
          //stopped and it is returned null
          groupHandler = null;
          searching = false;
          break;
        case VALID_HANDLER:
          //there is a valid groupHandler, which is already stored in 'groupHandler'.
          //stop the search and return that group handler.
          searching = false;
          break;
        case ACTIVATING_HANDLER_WAIT:
          //there is some other handler, being activated, with lowest group member id than
          //this one. Wait some time and start the search again
          Thread.currentThread().sleep(PERIOD_BETWEEN_SEARCHS);
          break;
        default:
      }

    return groupHandler;
  }

//*************************************************************************************//
//**************************** SEARCH *************************************************//
//*************************************************************************************//

  /**
    * Searchs for a valid GroupHandler in the locations specified. If there are valid ones,
    * 'groupHandler' points to the valid one.
    * @returns NO_VALID_HANDLER if there are no valid HANDLERs
    * @returns VALID_HANDLER if a valid HANDLER has been found
    * @returns ACTIVATING_HANDLER if there is some activating HANDLER, but this one has
	  *                  	priority on the activation.
    * @returns ACTIVATING_HANDLER_WAIT if there is some activating HANDLER but the calling
	  *                  	method should wait some time before searching again for the HANDLER.
    **/
  int search(GroupHandler thisHandler, Configuration.GMNShost validLocations[])
  {
    Trace.code("AutoLocation.java -> int search ( GroupHandler thisHandler , Configuration.GMNShost validLocations [ ] )");
    int ret = NO_VALID_HANDLER;
    int i = validLocations.length;

    while ((ret!=VALID_HANDLER) && (i > 0))
    {
      Configuration.GMNShost hostLocation = validLocations[--i];
      GroupHandler handler = null;
      if (hostLocation.socketSpecified())
        handler = readSocket(hostLocation.host, hostLocation.port);
      else
        handler= readURL(hostLocation.url);
      if (handler != null)
        try
        {
          if (handler.isValidGroup())
          {
            //a valid, activated handler has been found; return
            ret=VALID_HANDLER;
            groupHandler = handler;
          }
          else if (ret != ACTIVATING_HANDLER_WAIT)
          {
            //has been found another one, check which has priority, but only if
            //this has some priority over others!
            if (hasHigherId(thisHandler, handler))
            {
              ret = ACTIVATING_HANDLER;
              groupHandler = handler;
            }
            else
            {
              ret = ACTIVATING_HANDLER_WAIT;
            }
          }
        }
        catch(Exception ex)
        {
          Trace.handledException(ex);
        }
    }

    return ret;
  }


//*************************************************************************************//
//**************************** READ URL ***********************************************//
//*************************************************************************************//

  /**
    * Returns the GroupHandler stored in the specified URL. If the URL can not be reached
    * or there is no valid GMLS, it returns null. Otherwise, it returns the read reference
    **/
  GroupHandler readURL(URL location)
  {
    Trace.code("AutoLocation.java -> GroupHandler readURL ( URL location )");
    GroupHandler ret = null;
    InputStream input = null;
    try
    {
      input = location.openStream();
      ret = GMSnarrower.toGroupHandler(ObjectsHandling.readObject(input));
    }
    catch (Exception ex)
    {
      Trace.handledException(ex);
    }
    finally
    {
      if (input!=null)
        try
        {
          input.close();
        }
        catch (IOException ex)
        {
          Trace.handledException(ex);
        }
      input=null;
    }

    return ret;
  }

//*************************************************************************************//
//**************************** READ SOCKET ********************************************//
//*************************************************************************************//

  /**
    * Returns the GroupHandler published in the specified socket. If the socket can not be reached
    * or there is no valid GMLS, it returns null. Otherwise, it returns the read reference
    **/
  GroupHandler readSocket(String host, int port)
  {
    Trace.code("AutoLocation.java -> GroupHandler readSocket ( String host , int port )");
    GMNSreferenceListener listener = new GMNSreferenceListener(host,port);
    return listener.getGroup();
  }

//*************************************************************************************//
//**************************** HAS HIGHER ID ******************************************//
//*************************************************************************************//

  /**
    * Checks if the first groupHandler specified has higher rank than the second one,
    * returning true in that case.
    **/
  boolean hasHigherId(GroupHandler first, GroupHandler second) throws Exception
  {
    Trace.code("AutoLocation.java -> boolean hasHigherId ( GroupHandler first , GroupHandler second )");
    int firstId = first.getGroupMemberId();
    int secondId = second.getGroupMemberId();
    boolean ret = firstId > secondId;
    if (firstId == secondId)
    {
      //perhaps is the same handler!
      if (ObjectsHandling.areEquivalent(first, second))
        ret = true;
      else
      {
        //almost impossible case!!! Two members have exactly the same random number.
        //wait for some random time and return false.
        int random = (new java.util.Random()).nextInt(4*PERIOD_BETWEEN_SEARCHS);
        Thread.currentThread().sleep(random);
        ret=false;
      }
    }
    return ret;
  }

//*************************************************************************************//
//**************************** DATA MEMBERS *******************************************//
//*************************************************************************************//

  GroupHandler groupHandler;

  final static int NO_VALID_HANDLER        = 0;
  final static int VALID_HANDLER           = 1;
  final static int ACTIVATING_HANDLER      = 2;
  final static int ACTIVATING_HANDLER_WAIT = 3;

  final static int PERIOD_BETWEEN_SEARCHS = ftda.util.Configuration.getSingleton().getGMNSCollisionTimeout();

}
