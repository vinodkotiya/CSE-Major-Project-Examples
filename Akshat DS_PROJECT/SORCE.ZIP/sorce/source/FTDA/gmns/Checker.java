package ftda.gmns;

import ftda.middleware.gms.GroupHandler;
import ftda.middleware.gmns.MapStringSet;
import ftda.middleware.gmns.MemberInfo;
import ftda.middleware.gmns.SetMemberInfo;
import ftda.middleware.domains.MemberStateException;
import ftda.util.Error;

import java.util.TimerTask;

class Checker extends TimerTask
{
  //*************************************************************************************//
  //**************************** CONSTRUCTOR ********************************************//
  //*************************************************************************************//

  public Checker(MapStringSet toCheck)
  {
    Trace.code("Checker.java -> Checker ( MapStringSet toCheck )");
    this.map=toCheck;
  }

  public void run()
  {
    Trace.code("Checker.java -> void run ( )");
    try
    {
      String groups[] = map.getKeys();
      int size=groups.length;
      for(int i=0; i<size; i++)
      {
        if (!checkSet(map.get(groups[i])))
        {
          map.remove(groups[i]);
        }
      }
    }
    catch(NullPointerException npx){}
    catch(MemberStateException mex){}
    catch(Exception ex){Error.unhandledException(Consts.AREA,ex);}
  }

  boolean checkSet(SetMemberInfo set) throws MemberStateException, Exception
  {
    Trace.code("Checker.java -> boolean checkSet ( SetMemberInfo set )");
    MemberInfo member = set.get();
    while(member!=null)
    {
      GroupHandler handler = member.handler;
      try
      {
        if (handler.isValidGroup())
          return true;
      }
      catch(Exception ex){}
      set.remove(member);
      member=set.get();
    }
    return false;
  }

  //*************************************************************************************
  //**************************** DATA MEMBERS *******************************************
  //*************************************************************************************

  MapStringSet map;
};
