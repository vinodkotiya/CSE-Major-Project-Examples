package ftda.gmns;

import ftda.middleware.gmns.MapStringSet;
import ftda.middleware.gms.GroupHandler;
import ftda.middleware.gms.GroupMember;
import ftda.middleware.gms.Message;
import ftda.middleware.gms.View;
import ftda.middleware.gmns.GroupsCheckerState;
import ftda.middleware.domains.DomainGroupHandler;
import ftda.middleware.domains.ExtendedCheckpointableBaseImpl;
import ftda.middleware.domains.State;

import ftda.util.Configuration;
import ftda.util.Error;

import java.util.Timer;

class CheckerActivator extends ExtendedCheckpointableBaseImpl
{
  //*************************************************************************************//
  //**************************** CONSTRUCTOR ********************************************//
  //*************************************************************************************//

  public CheckerActivator(DomainGroupHandler groupHandler, MapStringSet toCheck, GMNSAutoObserver observer) throws Exception
  {
    Trace.code("CheckerActivator.java -> CheckerActivator ( DomainGroupHandler groupHandler , MapStringSet toCheck , GMNSAutoObserver observer )");
    this.groupHandler=groupHandler;
    this.map=toCheck;
    this.observer=observer;
    factory = new GMNSFactory(groupHandler);
    groupHandler.registerSubgroup(Consts.CHECKER_SUBGROUP, thisExtendedCheckpointable);
  }

  void startChecking()
  {
    Trace.code("CheckerActivator.java -> void startChecking ( )");
    int period=Configuration.getSingleton().getGMNSCheckPeriod()*1000;
    new Timer(true).schedule(new Checker(map),period,period);
  }

  //*************************************************************************************
  //**************************** 'PRIVATE' STATE INTERFACE ******************************
  //*************************************************************************************

  public State getState()
  {
    Trace.code("CheckerActivator.java -> State getState ( )");
    return factory.createGroupsCheckerState(checker);
  }

  public void setState(State state)
  {
    Trace.code("CheckerActivator.java -> void setState ( State state )");
    assert state instanceof GroupsCheckerState;
    checker=((GroupsCheckerState)state).checker;
  }

  public void assumeState()
  {
    Trace.code("CheckerActivator.java -> void assumeState ( )");
    checker=thisMemberId;
    startChecking();
  }

  //*************************************************************************************
  //**************************** 'PRIVATE' GROUP MEMBER INTERFACE ***********************
  //*************************************************************************************

  public void processPTPMessage(int parm1, Message parm2){}
  public void processCastMessage(int sender, Message message){}
  public void changingView(){}
  public void excludedFromGroup()
  {
    Trace.code("CheckerActivator.java -> void excludedFromGroup ( )");
    factory=null;
    groupHandler=null;
    map=null;
  }

  public void memberAccepted(int id, GroupHandler parm2, View view)
  {
    Trace.code("CheckerActivator.java -> void memberAccepted ( int id , GroupHandler parm2 , View view )");
    thisMemberId=id;
    observer.joined(view.members.length);
  }

  public void installView(View view)
  {
    Trace.code("CheckerActivator.java -> void installView ( View view )");
    int out[]=view.expulsedMembers;
    int size=out.length;
    while(size-->0)
      if(out[size]==checker)
      {
        try
        {
          int withState[]=groupHandler.getStatefulMembers();
          if(withState.length>0)
          {
            checker=withState[0];
            if (checker==thisMemberId)
            {
              startChecking();
            }
          }
        }
        catch(Exception ex)
        {
          Error.unhandledException(Consts.AREA,ex);
        }
      }
    observer.changedReplicaNumber(view.members.length);
  }

  //*************************************************************************************
  //**************************** DATA MEMBERS *******************************************
  //*************************************************************************************

  int checker;
  int thisMemberId;
  GMNSFactory factory;
  GMNSAutoObserver observer;
  DomainGroupHandler groupHandler;
  MapStringSet map;
};
