package sensei.gmns;

import javax.swing.JDialog;
import javax.swing.JFrame;

import sensei.util.SenseiConf;

class ConfigurationWindow extends JDialog
{
  public ConfigurationWindow(JFrame parent)
  {
    super(parent, "GMNS configuration");
    Trace.code("ConfigurationWindow.java -> ConfigurationWindow ( JFrame parent )");
    getContentPane().add(SenseiConf.createGMNSPanel());
    pack();
    setLocation(parent.getLocation().x+10,parent.getLocation().y+10);
  }
}
