package FTDA.gmns;

import FTDA.domains.DynamicSubgroupInfoImpl;

/**
  * Internal GMNS constants
  **/
public class Consts
{
  public static final int MAX_EXIT_DELAY = 3000; //max number of milliseconds to quit the GMNS
  public static final String AREA = "GMNS";
  public static final int MONITOR_SUBGROUP = 4738;
  public static final int MAP_SUBGROUP = 7488;
  public static final int CHECKER_SUBGROUP = 21921;
  public static final int INVALID_SUBGROUP = FTDA.domains.Consts.EVERY_SUBGROUP;
  static final DynamicSubgroupInfoImpl noInfo = new DynamicSubgroupInfoImpl();
}
