package FTDA.gmns;

import FTDA.domains.utils.ExitHandler;

import FTDA.middleware.domains.DomainExpulsionReason;
import FTDA.middleware.domains.DomainGroupHandler;
import FTDA.middleware.domains.DomainGroupUserBaseImpl;
import FTDA.middleware.gmns.MapStringSet;

import FTDA.util.Error;

/**
  * Creates domainGroupHandler instances, to be used in the GMNS
  **/
class DomainGroupHandlerFactory extends DomainGroupUserBaseImpl
{
  public DomainGroupHandlerFactory(DomainGroupHandler handler, MapStringSet map, GMNSAutoObserver observer,
      ExitHandler exitHandler)
    throws Exception
  {
    Trace.code("DomainGroupHandlerFactory.java -> DomainGroupHandlerFactory ( DomainGroupHandler handler , MapStringSet map , GMNSAutoObserver observer , ExitHandler exitHandler )");
    this.handler=handler;
    this.map=map;
    this.observer=observer;
    this.exitHandler = exitHandler;
  }

  public void domainAccepted(int id)
  {
    Trace.code("DomainGroupHandlerFactory.java -> void domainAccepted ( int id )");
    if (exitHandler!=null)
      exitHandler.acceptedInGroup(handler);
  }
  public void stateObtained(boolean assumed)
  {
    Trace.code("DomainGroupHandlerFactory.java -> void stateObtained ( boolean assumed )");
    new PersistenceHandler(handler, map, assumed, observer);
  }
  public void offendingSubgroup(int id, String reason)
  {
    Trace.code("DomainGroupHandlerFactory.java -> void offendingSubgroup ( int id , String reason )");
    observer.message("Offending subgroup "+id+": "+reason);
  }
  public void domainExpulsed(DomainExpulsionReason reason)
  {
    Trace.code("DomainGroupHandlerFactory.java -> void domainExpulsed ( DomainExpulsionReason reason )");
    if (exitHandler==null)
      observer.excluded();
    else
      exitHandler.excludedFromGroup(reason);
  }
  DomainGroupHandler handler;
  MapStringSet map;
  GMNSAutoObserver observer;
  ExitHandler exitHandler;
}
