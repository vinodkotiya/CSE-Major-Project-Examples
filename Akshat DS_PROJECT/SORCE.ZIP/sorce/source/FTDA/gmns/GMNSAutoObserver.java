package FTDA.gmns;

public interface GMNSAutoObserver
{
  public void joined(int replicas);
  public void changedReplicaNumber(int replicas);
  public void excluded();
  public void receivingState();
  public void readingStateFromBackup();
  public void stateReceived(PersistenceHandler handler);

  public void message(String s);
}
