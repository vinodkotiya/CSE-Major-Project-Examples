package FTDA.gmns;

import FTDA.middleware.domains.DomainGroupHandler;
import FTDA.middleware.domains.MemberStateException;
import FTDA.middleware.gms.GroupHandler;
import FTDA.middleware.gmns.GroupsCheckerState;
import FTDA.middleware.gmns.MapStringSetEntry;
import FTDA.middleware.gmns.MapStringSetPutMessage;
import FTDA.middleware.gmns.MapStringSetRemoveMessage;
import FTDA.middleware.gmns.MapStringSetState;
import FTDA.middleware.gmns.MemberInfo;
import FTDA.middleware.gmns.SetMemberInfoChangedMessage;
import FTDA.middleware.gmns.SetMemberInfoState;

/**
  * Central point to create messages and state instances
  **/
class GMNSFactory
{

//*************************************************************************************//
//**************************** CONSTRUCTOR ********************************************//
//*************************************************************************************//

  /**
    * It is required the groupHandler to use to cast the messages, and the subgroupId
    * assigned to the GMNSdata.
    **/
  public GMNSFactory(DomainGroupHandler group)
  {
    Trace.code("GMNSFactory.java -> GMNSFactory ( DomainGroupHandler group )");
    this.group = group;
    this.subgroupId = Consts.INVALID_SUBGROUP;
  }

  public void setSubgroupId(int subgroupId)
  {
    Trace.code("GMNSFactory.java -> void setSubgroupId ( int subgroupId )");
    this.subgroupId = subgroupId;
  }

  public void castSetMessage(MemberInfo info, boolean add) throws MemberStateException, Exception
  {
    Trace.code("GMNSFactory.java -> void castSetMessage ( MemberInfo info , boolean add )");
    group.syncCastDomainMessage(new SetMemberInfoChangedMessageImpl(info, add, subgroupId), false);
  }

  public void castMapPutMessage(String groupName, int setSubgroupId) throws MemberStateException, Exception
  {
    Trace.code("GMNSFactory.java -> void castMapPutMessage ( String groupName , int setSubgroupId )");
    group.syncCastDomainMessage(new MapStringSetPutMessageImpl(groupName, setSubgroupId, subgroupId), false);
  }

  public void castMapRemoveMessage(String groupName) throws MemberStateException, Exception
  {
    Trace.code("GMNSFactory.java -> void castMapRemoveMessage ( String groupName )");
    group.syncCastDomainMessage(new MapStringSetRemoveMessageImpl(groupName, subgroupId), false);
  }

  public void syncMessageCompleted() throws MemberStateException, Exception
  {
    Trace.code("GMNSFactory.java -> void syncMessageCompleted ( )");
    group.syncCastDomainMessageProcessed();
  }

  public static SetMemberInfoState createSetState(final MemberInfo members[])
  {
    Trace.code("GMNSFactory.java -> SetMemberInfoState createSetState ( final MemberInfo members [ ] )");
    return new SetMemberInfoStateImpl(members);
  }

  public static MapStringSetState createMapState(final MapStringSetEntry groups[])
  {
    Trace.code("GMNSFactory.java -> MapStringSetState createMapState ( final MapStringSetEntry groups [ ] )");
    return new MapStringSetStateImpl(groups);
  }
  public static GroupsCheckerState createGroupsCheckerState(final int checker)
  {
    Trace.code("GMNSFactory.java -> GroupsCheckerState createGroupsCheckerState ( final int checker )");
    return new GroupsCheckerStateImpl(checker);
  }

//*************************************************************************************//
//**************************** INNER CLASSES *******************************************//
//*************************************************************************************//

  static class SetMemberInfoChangedMessageImpl extends SetMemberInfoChangedMessage
  {
    public SetMemberInfoChangedMessageImpl (MemberInfo info, boolean add, int subgroupId)
    {
      this.add=add;
      this.info=info;
      this.subgroup=subgroupId;
    }
  }
  static class SetMemberInfoStateImpl extends SetMemberInfoState
  {
    public SetMemberInfoStateImpl(MemberInfo members[])
    {
      this.members=members;
    }
  }
  static class MapStringSetPutMessageImpl extends MapStringSetPutMessage
  {
    public MapStringSetPutMessageImpl (String key, int value, int subgroupId)
    {
      this.key=key;
      this.value=value;
      this.subgroup=subgroupId;
    }
  }
  static class MapStringSetRemoveMessageImpl extends MapStringSetRemoveMessage
  {
    public MapStringSetRemoveMessageImpl (String key, int subgroupId)
    {
      this.key=key;
      this.subgroup=subgroupId;
    }
  }
  static class MapStringSetStateImpl extends MapStringSetState
  {
    public MapStringSetStateImpl(MapStringSetEntry groups[])
    {
      this.groups=groups;
    }
  }
  static class GroupsCheckerStateImpl extends GroupsCheckerState
  {
    public GroupsCheckerStateImpl(int checker)
    {
      this.checker=checker;
    }
  }

  //*************************************************************************************
  //**************************** DATA MEMBERS *******************************************
  //*************************************************************************************

  DomainGroupHandler group;
  int subgroupId;
}

