package FTDA.gmns;

import FTDA.util.Error;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;

import FTDA.middleware.domains.DomainExpulsionReason;
import FTDA.domains.utils.ExitHandler;
import FTDA.domains.utils.ExitHandlerUser;

/**
  * Output for the GMLS, based on JFrame
  **/
class GMNSGraphic extends JFrame implements GMNSObserver, ActionListener, ExitHandlerUser
{
  /**
    * @param name The name of the current GMLS instance
    * @model
    **/
  public GMNSGraphic(String name)
  {
    super(name);
    Trace.code("GMNSGraphic.java -> GMNSGraphic ( String name )");

    this.exitHandler = new ExitHandler(this);
    Box mainbox = Box.createVerticalBox();
    mainbox.add(createDataPanel());
    mainbox.add(createGroupBox());
    getContentPane().add(mainbox, BorderLayout.CENTER);
    setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    initMenus();

    addWindowListener
      (
        new WindowAdapter() {public void windowClosing(WindowEvent e){initExit();}}
      );

    pack();
    int x = (int) getGraphicsConfiguration().getBounds().getWidth();
    int y = (int) getGraphicsConfiguration().getBounds().getHeight();
    setLocation(x/10+new java.util.Random().nextInt(2*(x/5)),
                y/10+new java.util.Random().nextInt(2*(y/5)));
    setVisible(true);
  }

  public ExitHandler getExitHandler()
  {
    Trace.code("GMNSGraphic.java -> ExitHandler getExitHandler ( )");
    return exitHandler;
  }

  public Dimension getPreferredSize()
  {
    Trace.code("GMNSGraphic.java -> Dimension getPreferredSize ( )");
    return new Dimension(300, 350);
  }

  void initMenus()
  {
    Trace.code("GMNSGraphic.java -> void initMenus ( )");
    JMenuBar menuBar = new JMenuBar();
    setJMenuBar(menuBar);
    {
      JMenu menuFile = new JMenu("File");
      menuFile.setMnemonic(KeyEvent.VK_F);
      menuBar.add(menuFile);
      {
        menuConfiguration = new JMenuItem("Show configuration", KeyEvent.VK_C);
        menuFile.add(menuConfiguration);
        menuConfiguration.addActionListener(this);
        menuFile.addSeparator();
        menuBackup = new JMenuItem("Save backup now", KeyEvent.VK_B);
        menuFile.add(menuBackup);
        menuBackup.addActionListener(this);
        menuFile.addSeparator();
        menuExit = new JMenuItem("Exit", KeyEvent.VK_X);
        menuFile.add(menuExit);
        menuExit.addActionListener(this);
      }
      JMenu menuHelp = new JMenu("Help");
      menuHelp.setMnemonic(KeyEvent.VK_H);
      menuBar.add(Box.createHorizontalGlue());
      menuBar.add(menuHelp);
      {
        menuAbout = new JMenuItem("About", KeyEvent.VK_A);
        menuHelp.add(menuAbout);
        menuAbout.addActionListener(this);
      }
    }
    menuBackup.setEnabled(false);
  }

  //*************************************************************************************//
  //**************************** EXIT HANDLER USER **************************************//
  //*************************************************************************************//

  public void initExit()
  {
    Trace.code("GMNSGraphic.java -> void initExit ( )");
    try
    {
      exitHandler.initExitProcedure(Consts.MAX_EXIT_DELAY);
    }
    catch (Exception ex)
    {
      System.exit(0);
    }
  }

  public void performExit(boolean memberCorrectlyExcluded)
  {
    Trace.code("GMNSGraphic.java -> void performExit ( boolean memberCorrectlyExcluded )");
    System.exit(0);
  }

  public void unsolicitedExclusion(DomainExpulsionReason reason)
  {
    Trace.code("GMNSGraphic.java -> void unsolicitedExclusion ( DomainExpulsionReason reason )");
    excluded();
  }

//*************************************************************************************//
//**************************** CREATE GROUP BOX ***************************************//
//*************************************************************************************//

  Box createGroupBox()
  {
    Trace.code("GMNSGraphic.java -> Box createGroupBox ( )");
    Box box = Box.createHorizontalBox();
    box.add(new JLabel("State: "));
    state = new JLabel("Joining group");
    box.add(state);
    return box;
  }

  //*************************************************************************************//
  //**************************** CREATE DATA PANEL **************************************//
  //*************************************************************************************//

  JPanel createDataPanel()
  {
    Trace.code("GMNSGraphic.java -> JPanel createDataPanel ( )");
    JPanel ret = new JPanel(new BorderLayout());
    root   = new MyNode(ROOT);

    treeModel = new DefaultTreeModel(root, true);

    JTree tree = new JTree(treeModel);
    tree.setRootVisible(false);
    tree.setCellRenderer(new MyRenderer());

    //Create the scroll pane and add the tree to it.
    JScrollPane treeView = new JScrollPane(tree);

    ret.add(treeView, BorderLayout.CENTER);

    ret.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),ROOT));

    return ret;
  }

  //*************************************************************************************//
  //**************************** CREATE GROUP *******************************************//
  //*************************************************************************************//

  public void addGroup(String name)
  {
    Trace.code("GMNSGraphic.java -> void addGroup ( String name )");
    treeModel.insertNodeInto(new MyNode(name), root, findGroupPosition(name));
  }

  //*************************************************************************************//
  //**************************** REMOVE GROUP *******************************************//
  //*************************************************************************************//

  public void removeGroup(String name)
  {
    Trace.code("GMNSGraphic.java -> void removeGroup ( String name )");
    treeModel.removeNodeFromParent(findGroup(name));
  }

  //*************************************************************************************//
  //**************************** CREATE MEMBER ******************************************//
  //*************************************************************************************//

  public void addGroupMember(String groupName, String member, boolean withReference)
  {
    Trace.code("GMNSGraphic.java -> void addGroupMember ( String groupName , String member , boolean withReference )");
    DefaultMutableTreeNode group = findGroup(groupName);
    treeModel.insertNodeInto(new MyNode(member,withReference), group, findMemberPosition(group, member));
  }

  //*************************************************************************************//
  //**************************** REMOVE MEMBER ******************************************//
  //*************************************************************************************//

  public void removedGroupMember(String groupName, String member)
  {
    Trace.code("GMNSGraphic.java -> void removedGroupMember ( String groupName , String member )");
    treeModel.removeNodeFromParent(findMember(findGroup(groupName), member));
  }

  //*************************************************************************************//
  //**************************** GMNS AUTO OBSERVER INTERFACE ***************************//
  //*************************************************************************************//

  public void joined(int replicas)
  {
    Trace.code("GMNSGraphic.java -> void joined ( int replicas )");
    this.replicas=replicas;
    changeText("Joined GMNS group");
  }

  public void excluded()
  {
    Trace.code("GMNSGraphic.java -> void excluded ( )");
    enableMenuBackup(false);
    changeText("Inactive, excluded from GMNS group");
    message("Instance has been exluded from the GMNS group, getting inactive");
  }

  public void receivingState()
  {
    Trace.code("GMNSGraphic.java -> void receivingState ( )");
    changeText("Receiving GMNS state");
  }

  public void readingStateFromBackup()
  {
    Trace.code("GMNSGraphic.java -> void readingStateFromBackup ( )");
    changeText("Reading state from backup");
  }

  public void stateReceived(PersistenceHandler handler)
  {
    Trace.code("GMNSGraphic.java -> void stateReceived ( PersistenceHandler handler )");
    enableMenuBackup(true);
    this.persistenceHandler = handler;
    changeText("Active, "+String.valueOf(replicas)+" GMNS replicas");
  }

  public void changedReplicaNumber(int members)
  {
    Trace.code("GMNSGraphic.java -> void changedReplicaNumber ( int members )");
    this.replicas=members;
    if (persistenceHandler!=null)
      stateReceived(persistenceHandler);
  }

  public void message(String s)
  {
    Trace.code("GMNSGraphic.java -> void message ( String s )");
    JOptionPane.showMessageDialog(this, s);
  }

  public void changeText(final String stateText)
  {
    Trace.code("GMNSGraphic.java -> void changeInfo(String stateText)");
    SwingUtilities.invokeLater(new Runnable(){
      public void run()
      {
        state.setText(stateText);
      }
    });
  }

  public void enableMenuBackup(final boolean menuMackupEnable)
  {
    Trace.code("GMNSGraphic.java -> void enableMenuBackup(final boolean menuMackupEnable)");
    SwingUtilities.invokeLater(new Runnable(){
      public void run()
      {
        menuBackup.setEnabled(menuMackupEnable);
      }
    });
  }

  //*************************************************************************************//
  //**************************** FIND GROUP POSITION ************************************//
  //*************************************************************************************//

  /**
    * Finds the group position to insert a group.
    **/
  int findGroupPosition(String groupName)
  {
    Trace.code("GMNSGraphic.java -> int findGroupPosition ( String groupName )");
    int len = root.getChildCount();
    for (int i=0; i<len ; i++)
    {
      int cmp = groupName.compareTo(root.getChildAt(i).toString());
      if (cmp==0)	//already exists!
        Error.error(Consts.AREA,"GMNSGraphic:findGroupPosition:1");
      else if (cmp<0)
        return i;
    }
    return len;
  }


  //*************************************************************************************//
  //**************************** FIND GROUP  ********************************************//
  //*************************************************************************************//

  /**
    * Finds a group in the tree
    **/
  DefaultMutableTreeNode findGroup(String groupName)
  {
    Trace.code("GMNSGraphic.java -> DefaultMutableTreeNode findGroup ( String groupName )");
    int len = root.getChildCount();
    for (int i=0; i<len ; i++)
    {
      DefaultMutableTreeNode group = (DefaultMutableTreeNode) root.getChildAt(i);
      int cmp = groupName.compareTo(group.toString());
      if (cmp==0)
        return group;
      else if (cmp<0)	//not found
        break;
    }
    Error.error(Consts.AREA,"GMNSGraphic:findGroup:1");
    return null;
  }


  //*************************************************************************************//
  //**************************** FIND MEMBER POSITION ***********************************//
  //*************************************************************************************//

  /**
    * Finds the member position to insert a member.
    **/
  int findMemberPosition(DefaultMutableTreeNode group, String member)
  {
    Trace.code("GMNSGraphic.java -> int findMemberPosition ( DefaultMutableTreeNode group , String member )");
    int len = group.getChildCount();
    for (int i=0; i<len ; i++)
    {
      DefaultMutableTreeNode node = (DefaultMutableTreeNode) group.getChildAt(i);
      int compare = member.compareTo(node.getUserObject());
      if (compare>0)
        return i;
    }
    return len;
  }


  //*************************************************************************************//
  //**************************** FIND MEMBER ********************************************//
  //*************************************************************************************//

  /**
    * Finds a group in the tree
    **/
  DefaultMutableTreeNode findMember(DefaultMutableTreeNode group, String member)
  {
    Trace.code("GMNSGraphic.java -> DefaultMutableTreeNode findMember ( DefaultMutableTreeNode group , String member )");
    int len = group.getChildCount();
    for (int i=0; i<len ; i++)
    {
      DefaultMutableTreeNode node = (DefaultMutableTreeNode) group.getChildAt(i);
      if (member.equals(node.getUserObject()))
        return node;
    }
    Error.error(Consts.AREA,"GMNSGraphic:findMember:1");
    return null;
  }

  public void actionPerformed(ActionEvent event)
  {
    Trace.code("GMNSGraphic.java -> void actionPerformed ( ActionEvent event )");
    Object obj = event.getSource();
    if (obj==menuConfiguration)
    {
      if (configuration==null)
        configuration = new ConfigurationWindow(this);
      configuration.show();
    }
    else if (obj==menuBackup)
    {
      if (persistenceHandler!=null)
        persistenceHandler.writeFile();
    }
    else if (obj==menuExit)
    {
      initExit();
    }
    else if (obj==menuAbout)
      message("GMNS(GroupMembershipNamingService), (c)LuisM Pena, November 2000, v0.29, December 2001");
  }


  //*************************************************************************************//
  //**************************** INNER CLASS ********************************************//
  //*************************************************************************************//

  class MyNode extends DefaultMutableTreeNode
  {
    public MyNode(String groupName){super(groupName,true);isPrivate=false;}
    public MyNode(String memberName, boolean isPublic){super(memberName,false);isPrivate=!isPublic;}
    boolean isPrivate;
  }

  //*************************************************************************************//
  //**************************** INNER CLASS ********************************************//
  //*************************************************************************************//

  class MyRenderer extends DefaultTreeCellRenderer
  {
    public Component getTreeCellRendererComponent( JTree tree, Object value, boolean sel, boolean expanded,
        boolean leaf, int row, boolean hasFocus)
    {
      super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
      if (((MyNode)value).isPrivate)
      {
        if (normal==null)
        {
          normal=getFont();
          if (normal!=null)
            italic=normal.deriveFont(Font.ITALIC);
        }
        if (italic!=null)
          setFont(italic);
      }
      else if (normal!=null)
        setFont(normal);
      return this;
    }
    Font normal=null, italic=null;
  }
  //*************************************************************************************//
  //**************************** DATA MEMBERS *******************************************//
  //*************************************************************************************//

  static final String ROOT = "List of groups and members";

  DefaultMutableTreeNode root;
  DefaultTreeModel treeModel;

  ConfigurationWindow configuration;
  JMenuItem menuConfiguration, menuBackup, menuExit, menuAbout;
  JLabel state;
  int replicas;
  PersistenceHandler persistenceHandler;
  final ExitHandler exitHandler;
}
