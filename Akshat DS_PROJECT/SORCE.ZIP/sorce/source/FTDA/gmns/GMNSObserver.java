package FTDA.gmns;

public interface GMNSObserver extends GMNSAutoObserver
{
  public void addGroup(String group);
  public void removeGroup(String group);
  public void addGroupMember(String group, String member, boolean withReference);
  public void removedGroupMember(String group, String member);
}
