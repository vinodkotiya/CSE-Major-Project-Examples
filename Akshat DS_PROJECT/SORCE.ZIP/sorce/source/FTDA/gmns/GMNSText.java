package FTDA.gmns;

import FTDA.util.Error;

/**
  * Output for the GMNS, based on text
  **/
class GMNSText implements GMNSObserver
{
  public GMNSText()
  {
    Trace.code("GMNSText.java -> GMNSText ( )");
  }

  //*************************************************************************************//
  //**************************** CREATE GROUP *******************************************//
  //*************************************************************************************//

  public void addGroup(String name)
  {
    Trace.code("GMNSText.java -> void addGroup ( String name )");
    System.out.println(":==> +"+name);
  }

  //*************************************************************************************//
  //**************************** REMOVE GROUP *******************************************//
  //*************************************************************************************//

  public void removeGroup(String name)
  {
    Trace.code("GMNSText.java -> void removeGroup ( String name )");
    System.out.println(":==> -"+name);
  }

  //*************************************************************************************//
  //**************************** CREATE MEMBER ******************************************//
  //*************************************************************************************//

  public void addGroupMember(String groupName, String member, boolean withReference)
  {
    Trace.code("GMNSText.java -> void addGroupMember ( String groupName , String member , boolean withReference )");
    System.out.println(":------> ["+groupName+"]+"+member+(withReference? "(*)" : ""));
  }

  //*************************************************************************************//
  //**************************** REMOVE MEMBER ******************************************//
  //*************************************************************************************//

  public void removedGroupMember(String groupName, String member)
  {
    Trace.code("GMNSText.java -> void removedGroupMember ( String groupName , String member )");
    System.out.println(":------> ["+groupName+"]-"+member);
  }


  public void joined(int members)
  {
    Trace.code("GMNSText.java -> void joined ( int members )");
    System.out.println("Joined GMNS group, "+members+" replicas");
  }

  public void excluded()
  {
    Trace.code("GMNSText.java -> void excluded ( )");
    System.out.println("Inactive, excluded from GMNS group");
    System.exit(0);
  }

  public void receivingState()
  {
    Trace.code("GMNSText.java -> void receivingState ( )");
    System.out.println("Receiving GMNS state");
  }

  public void readingStateFromBackup()
  {
    Trace.code("GMNSText.java -> void readingStateFromBackup ( )");
    System.out.println("Reading state from backup");
  }

  public void stateReceived(PersistenceHandler handler)
  {
    Trace.code("GMNSText.java -> void stateReceived ( PersistenceHandler handler )");
    System.out.println("State received, active!");
  }

  public void changedReplicaNumber(int members)
  {
    Trace.code("GMNSText.java -> void changedReplicaNumber ( int members )");
    System.out.println("Changed number of GMNS replicas to "+String.valueOf(members));
  }

  public void message(String s)
  {
    Trace.code("GMNSText.java -> void message ( String s )");
    System.out.println(s);
  }

}
