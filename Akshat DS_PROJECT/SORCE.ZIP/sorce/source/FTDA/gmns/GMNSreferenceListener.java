package FTDA.gmns;

import FTDA.middleware.gms.FTDAGMSMember;
import FTDA.middleware.gms.GMSnarrower;
import FTDA.middleware.gmns.GroupMembershipNamingService;
import FTDA.middleware.gmns.GMNSnarrower;
import FTDA.middleware.util.ObjectsHandling;

import java.io.IOException;
import java.io.InputStream;

import java.net.Socket;

/**
  * A client can access the GMNS published references throught this class
  **/
class GMNSreferenceListener
{

//*************************************************************************************//
//**************************** CONSTRUCTOR ********************************************//
//*************************************************************************************//

  public GMNSreferenceListener(String host, int port)
  {
    Trace.code("GMNSreferenceListener.java -> GMNSreferenceListener ( String host , int port )");
    Socket access = null;
    group=null;
    gmsn=null;
    try
    {
      access = new Socket(host,port);
      getInfo(access.getInputStream());
    }
    catch(Exception ex)	//java.net.UnknownHostException, java.io.IOException
    {
      group=null;
      gmsn=null;
      Trace.handledException(ex);
    }
    finally
    {
      if (access!=null)
        try{access.close();}catch(Exception ex){}
    }
  }

//*************************************************************************************//
//**************************** GET INFO ***********************************************//
//*************************************************************************************//

  /**
    * Get the references from the socket stream
    **/
  void getInfo(InputStream stream) throws IOException, ClassNotFoundException
  {
    Trace.code("GMNSreferenceListener.java -> void getInfo ( InputStream stream )");
    group=GMSnarrower.toFTDAGMSMember(ObjectsHandling.readObject(stream));
    gmsn=GMNSnarrower.toGroupMembershipNamingService(ObjectsHandling.readObject(stream));
  }

//*************************************************************************************//
//**************************** GET GROUP **********************************************//
//*************************************************************************************//

  /**
    * Returns null if nothing read, or an error ocurred
    **/
  public FTDAGMSMember getGroup()
  {
    Trace.code("GMNSreferenceListener.java -> FTDAGMSMember getGroup ( )");
    return group;
  }

//*************************************************************************************//
//**************************** GET GMSN ***********************************************//
//*************************************************************************************//

  /**
    * Returns null if nothing read, or an error ocurred
    **/
  public GroupMembershipNamingService getGMSN()
  {
    Trace.code("GMNSreferenceListener.java -> GroupMembershipNamingService getGMSN ( )");
    return gmsn;
  }


//*************************************************************************************//
//**************************** DATA MEMBERS *******************************************//
//*************************************************************************************//

  FTDAGMSMember group;
  GroupMembershipNamingService gmsn;
}
