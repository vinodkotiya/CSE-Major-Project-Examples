package FTDA.gmns;

import FTDA.util.Error;

import FTDA.middleware.gms.FTDAGMSMember;
import FTDA.middleware.gmns.GroupMembershipNamingService;
import FTDA.middleware.util.ObjectsHandling;

import java.io.IOException;
import java.io.OutputStream;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/**
  * The GMNS publish its references through this socket server
  **/
class GMNSreferencePublisher extends Thread
{

//*************************************************************************************//
//**************************** CONSTRUCTOR ********************************************//
//*************************************************************************************//

  public GMNSreferencePublisher(FTDAGMSMember group, GroupMembershipNamingService gmsn, int port)
    throws IOException
  {
    Trace.code("GMNSreferencePublisher.java -> GMNSreferencePublisher ( FTDAGMSMember group , GroupMembershipNamingService gmsn , int port )");
    this.group = group;
    this.gmsn = gmsn;
    this.port = port;
    serverSocket = new ServerSocket(port);
    start();
  }

//*************************************************************************************//
//**************************** STOP SERVING *******************************************//
//*************************************************************************************//

  /**
    * This method must be called to stop the server
    **/
  public void stopServing()
  {
    Trace.code("GMNSreferencePublisher.java -> void stopServing ( )");
    try
    {
      if (running)
      {
        running = false;
        new Socket(InetAddress.getLocalHost(),port).close();
      }
    }
    catch (Exception ex)
    {
      Error.unhandledException(Consts.AREA, ex);
    }
  }

//*************************************************************************************//
//**************************** THREAD : RUN *******************************************//
//*************************************************************************************//

  public void run()
  {
    Trace.code("GMNSreferencePublisher.java -> void run ( )");
    running = true;
    try
    {
      while (running)
      {
        Socket socket = serverSocket.accept();
        if (running)
          sendReferences(socket);
        socket.close();
      }
    }
    catch(IOException ioex)
    {
      Error.unhandledException(Consts.AREA, ioex);
    }
    try{serverSocket.close();}catch(Exception ex){}
  }

//*************************************************************************************//
//**************************** SEND REFERENCES ****************************************//
//*************************************************************************************//

  void sendReferences(Socket socket)
  {
    Trace.code("GMNSreferencePublisher.java -> void sendReferences ( Socket socket )");
    OutputStream stream = null;
    try
    {
      stream = socket.getOutputStream();
      ObjectsHandling.writeObject(group, stream);
      ObjectsHandling.writeObject(gmsn, stream);
    }
    catch(IOException ioex)
    {
      Error.unhandledException(Consts.AREA, ioex);
    }
    finally
    {
      if (stream!=null)
        try{stream.close();}catch(Exception ex){}
    }
  }

//*************************************************************************************//
//**************************** DATA MEMBERS *******************************************//
//*************************************************************************************//

  FTDAGMSMember group;
  GroupMembershipNamingService gmsn;
  ServerSocket serverSocket;
  int port;
  boolean running;
}
