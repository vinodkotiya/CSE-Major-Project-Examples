package FTDA.gmns;

import java.io.IOException;
/**
  * Exception thrown by the GMNS under several circustances, when it cannot
  *						complete it registration
  **/
public class GMNSregistrationException extends Exception
{
  public GMNSregistrationException(String fileName)
  {
    super("File " + fileName + " already contains a valid GroupMembeNamingService. Use a differente file / configuration file");
    Trace.code("GMNSregistrationException.java -> GMNSregistrationException ( String fileName )");
  }
  public GMNSregistrationException(IOException ioex)
  {
    super("IOException reading/creating GroupMembeNamingService file or registering the socket: " + ioex.getMessage());
    Trace.code("GMNSregistrationException.java -> GMNSregistrationException ( IOException ioex )");
  }
}
