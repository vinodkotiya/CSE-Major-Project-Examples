package FTDA.gmns;

import FTDA.util.Error;

import FTDA.middleware.gms.GroupHandler;
import FTDA.middleware.gmns.GroupHandlerFactory;
import FTDA.middleware.gmns.GroupHandlerFactoryException;
import FTDA.middleware.gmns.InvalidGroupHandlerFactoryException;
import FTDA.middleware.gmns.MapStringSet;
import FTDA.middleware.gmns.MemberInfo;
import FTDA.middleware.gmns.ReplicatedServer;
import FTDA.middleware.gmns.SetMemberInfo;
import FTDA.middleware.domains.DomainGroupHandler;
import FTDA.middleware.domains.DynamicSubgroupInfo;
import FTDA.middleware.domains.MemberStateException;
import FTDA.middleware.domains.Monitor;
import FTDA.middleware.domains.MonitorException;
import FTDA.middleware.domains.TransactionException;

/**
  * Handles the creation of a group
  **/
class GroupCreator
{

  /***********************************************************************************************/
  /********************** CONSTRUCTOR ************************************************************/
  /***********************************************************************************************/

  public GroupCreator(DomainGroupHandler domainHandler, MapStringSet map, Monitor monitor)
  {
    Trace.code("GroupCreator.java -> GroupCreator ( DomainGroupHandler domainHandler , MapStringSet map , Monitor monitor )");
    this.domainHandler=domainHandler;
    this.map=map;
    this.monitor=monitor;
  }


  /***********************************************************************************************/
  /********************** CREATE GROUP *************************************************************/
  /***********************************************************************************************/

  public boolean errorDueToClient()
  {
    Trace.code("GroupCreator.java -> boolean errorDueToClient ( )");
    return memberError;
  }

  /**
    * Creates a group with the given factory. It returns null if there is such a group with at
    * least one member
    **/
  GroupHandler createGroup(String groupName, GroupHandlerFactory factory, String memberId, ReplicatedServer reference)
    throws GroupHandlerFactoryException, InvalidGroupHandlerFactoryException, MemberStateException
  {
    Trace.code("GroupCreator.java -> GroupHandler createGroup ( String groupName , GroupHandlerFactory factory , String memberId , ReplicatedServer reference )");
    GroupHandler ret=null;
    memberError=false;
    try
    {
      domainHandler.startTransaction(monitor);
      SetMemberInfo group = map.get(groupName);
      try
      {
        //the member creates its own group if it doesn't exist or it's empty
        if (group==null)
          ret=createGroupSafely(groupName, factory, memberId, reference);
        else if (group.get()==null)
          ret=addMemberSafely(group, factory, memberId, reference);
      }
      finally
      {
        domainHandler.endTransaction();
      }
    }
    catch(MemberStateException ex){throw ex;}
    catch(GroupHandlerFactoryException ex){throw ex;}
    catch(InvalidGroupHandlerFactoryException ex){throw ex;}
    catch(Exception ex)
    {
      Error.unhandledException(Consts.AREA, ex);
      return null;
    }
    return ret;
  }

  GroupHandler createGroupSafely(String groupName, GroupHandlerFactory factory, String memberId,
      ReplicatedServer reference)
    throws GroupHandlerFactoryException, InvalidGroupHandlerFactoryException, MemberStateException, Exception
  {
    Trace.code("GroupCreator.java -> GroupHandler createGroupSafely ( String groupName , GroupHandlerFactory factory , String memberId , ReplicatedServer reference )");
    SetMemberInfoImpl setImpl = new SetMemberInfoImpl(Consts.noInfo, domainHandler);
    SetMemberInfo set =setImpl.theSetMemberInfo();
    map.put(groupName, set);
    return addMemberSafely(set, factory, memberId, reference);
  }

  GroupHandler addMemberSafely(SetMemberInfo set, GroupHandlerFactory factory, String memberId,
      ReplicatedServer reference)
    throws GroupHandlerFactoryException, InvalidGroupHandlerFactoryException, MemberStateException
  {
    Trace.code("GroupCreator.java -> GroupHandler addMemberSafely ( SetMemberInfo set , GroupHandlerFactory factory , String memberId , ReplicatedServer reference )");
    GroupHandler ret = GroupMembershipBasicServiceImpl.utilCreateGroup(factory);
    if (ret==null)
      memberError=true;
    else
      try
      {
        set.add(new MemberInfo(ret,memberId, reference));
      }
      catch(Exception ex)
      {
        Error.unhandledException(Consts.AREA, ex);
      }
    return ret;
  }

  //*************************************************************************************//
  //**************************** DATA MEMBERS *******************************************//
  //*************************************************************************************//

  DomainGroupHandler domainHandler;
  MapStringSet map;
  Monitor monitor;
  boolean memberError;
}
