package FTDA.gmns;

import FTDA.util.Error;

import FTDA.middleware.gms.GroupHandler;
import FTDA.middleware.gmns.GroupHandlerFactory;
import FTDA.middleware.gmns.GroupHandlerFactoryException;
import FTDA.middleware.gmns.InvalidGroupHandlerException;
import FTDA.middleware.gmns.InvalidGroupHandlerFactoryException;
import FTDA.middleware.gmns.MapStringSet;
import FTDA.middleware.gmns.MemberInfo;
import FTDA.middleware.gmns.ReplicatedServer;
import FTDA.middleware.gmns.SetMemberInfo;
import FTDA.middleware.domains.DomainGroupHandler;
import FTDA.middleware.domains.DomainsNarrower;
import FTDA.middleware.domains.MemberStateException;

/**
  * handles the joining to a group
  **/
class GroupJoiner
{

  /***********************************************************************************************/
  /********************** CONSTRUCTOR ************************************************************/
  /***********************************************************************************************/

  public GroupJoiner(DomainGroupHandler domainHandler, MapStringSet map)
  {
    Trace.code("GroupJoiner.java -> GroupJoiner ( DomainGroupHandler domainHandler , MapStringSet map )");
    this.domainHandler=domainHandler;
    this.map=map;
  }


  /***********************************************************************************************/
  /********************** JOIN GROUP *************************************************************/
  /***********************************************************************************************/

  public boolean errorDueToClient()
  {
    Trace.code("GroupJoiner.java -> boolean errorDueToClient ( )");
    return memberError;
  }

  /**
    * Finds a group with the name specified and includes the member with the given name.
    * Returns null if it couldn't find a group
    **/
  GroupHandler joinGroup(String groupName, GroupHandlerFactory factory, String memberId, ReplicatedServer reference)
    throws MemberStateException, GroupHandlerFactoryException, InvalidGroupHandlerFactoryException
  {
    Trace.code("GroupJoiner.java -> GroupHandler joinGroup ( String groupName , GroupHandlerFactory factory , String memberId , ReplicatedServer reference )");
    GroupHandler ret=null;
    memberError=false;
    try
    {
      SetMemberInfo group=map.get(groupName);
      if (group!=null)
      {
        boolean joined=false, exit=false;
        while(!joined&&!exit)
        {
          MemberInfo toJoin = group.get();
          if (toJoin==null)
            exit=true;  //empty group
          else
          {
            //join the group
            boolean wrongMember=false;
            try
            {
              ret = GroupMembershipBasicServiceImpl.utilJoinGroup(toJoin.handler, factory);
              if (ret==null)
              {
                //the another one perhaps is wrong!
                try{wrongMember=!toJoin.handler.isValidGroup();}catch(Exception ex){wrongMember=true;}
                if (!wrongMember)	//the problem is on the given factory
                {
                  memberError=true;
                  exit=true;
                }
              }
              else
              {
                group.add(new MemberInfo(ret,memberId,reference));
                joined=true;
              }
            }
            catch (InvalidGroupHandlerException ige)
            {
              wrongMember=true;
            }
            if (wrongMember)
              group.remove(toJoin);
          }
        }
      }
    }
    catch(MemberStateException ex){throw ex;}
    catch(InvalidGroupHandlerFactoryException ex){throw ex;}
    catch(GroupHandlerFactoryException ex){throw ex;}
    catch(Exception ex)
    {
      if (DomainsNarrower.isObjectNotExistException(ex))
        ret=null;
      else
        Error.unhandledException(Consts.AREA, ex);
    }
    return ret;
  }

  //*************************************************************************************//
  //**************************** DATA MEMBERS *******************************************//
  //*************************************************************************************//

  DomainGroupHandler domainHandler;
  MapStringSet map;
  boolean memberError;
}
