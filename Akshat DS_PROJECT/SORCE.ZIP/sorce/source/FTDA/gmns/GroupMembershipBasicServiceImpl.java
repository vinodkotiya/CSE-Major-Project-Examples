package FTDA.gmns;

import FTDA.util.Error;

import FTDA.middleware.gms.GMSnarrower;
import FTDA.middleware.gms.GroupHandler;
import FTDA.middleware.gms.FTDAGMSMember;
import FTDA.middleware.gmns.GroupHandlerFactory;
import FTDA.middleware.gmns.GroupHandlerFactoryCreator;
import FTDA.middleware.gmns.GroupHandlerFactoryCreatorImpl;
import FTDA.middleware.gmns.GroupMembershipBasicServiceBaseImpl;
import FTDA.middleware.gmns.GroupHandlerFactoryException;
import FTDA.middleware.gmns.InvalidGroupHandlerException;
import FTDA.middleware.gmns.InvalidGroupHandlerFactoryException;

/**
  * Implementation FTDA-based of a GroupMembershipService.
  * It defines static methods as well as the GroupMembershipBasicService interface, to
  *  be used as utility class.
  **/
public class GroupMembershipBasicServiceImpl extends GroupMembershipBasicServiceBaseImpl
{

  public GroupMembershipBasicServiceImpl() throws Exception
  {
    Trace.code("GroupMembershipBasicServiceImpl.java -> GroupMembershipBasicServiceImpl ( )");
  }

//*************************************************************************************//
//**************************** GET FACTORY CREATOR ************************************//
//*************************************************************************************//

  /**
    * Creates a GroupHandlerFactoryCreator
    **/
  public GroupHandlerFactoryCreator getFactoryCreator()
  {
    Trace.code("GroupMembershipBasicServiceImpl.java -> GroupHandlerFactoryCreator getFactoryCreator ( )");
    return utilGetFactoryCreator();
  }

//*************************************************************************************//
//**************************** CREATE GROUP *******************************************//
//*************************************************************************************//

  /**
    * Creates a new group. Returns the groupHandler created, that
    * can be invalid if the group cannot be created.
    * Under error conditions, null is also returned and the error catched through
    * the error class
    **/
  public GroupHandler createGroup(GroupHandlerFactory factory)
    throws InvalidGroupHandlerFactoryException, GroupHandlerFactoryException
  {
    Trace.code("GroupMembershipBasicServiceImpl.java -> GroupHandler createGroup ( GroupHandlerFactory factory )");
    return utilCreateGroup(factory);
  }


//*************************************************************************************//
//**************************** JOIN GROUP *********************************************//
//*************************************************************************************//

  /**
    * Joins the member to an existing group. This call doesn't
    * return until the member joins the group or until the
    * group handler used becomes invalid (because it belongs to
    * a member that is expulsed ot leaves its group). In that case, a null reference
    * is returned
    * Under error conditions, null is also returned and the error catched through
    * the error class
    **/
  public GroupHandler joinGroup(GroupHandler group, GroupHandlerFactory factory)
    throws InvalidGroupHandlerException, InvalidGroupHandlerFactoryException, GroupHandlerFactoryException
  {
    Trace.code("GroupMembershipBasicServiceImpl.java -> GroupHandler joinGroup ( GroupHandler group , GroupHandlerFactory factory )");
    return utilJoinGroup(group, factory);
  }

//*************************************************************************************//
//**************************** UTIL GET FACTORY CREATOR *******************************//
//*************************************************************************************//

  /**
    * Creates a GroupHandlerFactoryCreator
    **/
  public static GroupHandlerFactoryCreator utilGetFactoryCreator()
  {
    Trace.code("GroupMembershipBasicServiceImpl.java -> GroupHandlerFactoryCreator utilGetFactoryCreator ( )");
    return new GroupHandlerFactoryCreatorImpl();
  }

//*************************************************************************************//
//**************************** UTIL CREATE GROUP **************************************//
//*************************************************************************************//

  /**
    * Creates a new group. Returns the groupHandler created, that
    * can be invalid if the group cannot be created
    **/
  public static GroupHandler utilCreateGroup(GroupHandlerFactory factory)
    throws InvalidGroupHandlerFactoryException, GroupHandlerFactoryException
  {
    Trace.code("GroupMembershipBasicServiceImpl.java -> GroupHandler utilCreateGroup ( GroupHandlerFactory factory )");
    FTDAGMSMember member = getFTDAGMSMember(factory);

    try
    {
      member.createGroup();
    }
    catch(Exception ex)
    {
      throw new InvalidGroupHandlerFactoryException(ex.getMessage());
    }

    return member;
  }


//*************************************************************************************//
//**************************** UTIL JOIN GROUP ****************************************//
//*************************************************************************************//

  /**
    * Joins the member to an existing group. This call doesn't
    * return until the member joins the group or until the
    * group handler used becomes invalid (because it belongs to
    * a member that is expulsed ot leaves its group). In that case, a null reference
    * is returned
    **/
  public static GroupHandler utilJoinGroup(Object groupHandler, GroupHandlerFactory factory)
    throws InvalidGroupHandlerException, InvalidGroupHandlerFactoryException, GroupHandlerFactoryException
  {
    Trace.code("GroupMembershipBasicServiceImpl.java -> GroupHandler utilJoinGroup ( Object groupHandler , GroupHandlerFactory factory )");
    FTDAGMSMember member = getFTDAGMSMember(factory);

    //it must be a FTDAGMSMember!
    FTDAGMSMember castedGroup = GMSnarrower.toFTDAGMSMember(groupHandler);

    if (castedGroup==null)
    {
      throw new InvalidGroupHandlerException();
    }

    try
    {
      if (!member.joinGroup(castedGroup))
        member=null;
    }
    catch(Exception ex)
    {
      try
      {
        if (member.isValidGroup())
          throw new InvalidGroupHandlerFactoryException(ex.getMessage());
      }
      catch(Exception ex2)
      {
      }
    }

    return member;
  }

//*************************************************************************************//
//**************************** GET FTDA GMS MEMBER **********************************//
//*************************************************************************************//

  /**
    * Returns a handler from the GroupHandlerFactory
    **/
  static FTDAGMSMember getFTDAGMSMember(GroupHandlerFactory factory)
    throws InvalidGroupHandlerFactoryException, GroupHandlerFactoryException
  {
    Trace.code("GroupMembershipBasicServiceImpl.java -> FTDAGMSMember getFTDAGMSMember ( GroupHandlerFactory factory )");
    if (factory==null)
      throw new InvalidGroupHandlerFactoryException();

    GroupHandler handler = null;
    try
    {
      handler = factory.create();
    }
    catch(GroupHandlerFactoryException gex)
    {
      throw gex;
    }
    catch(Exception ex)//remote exception
    {
      throw new GroupHandlerFactoryException(ex.getMessage());
    }

    //it must be a FTDAGMSMember! If not: InvalidGroupHandler, or return just null+trace, or assertion?
    //in this case, referred to the factory
    FTDAGMSMember member = GMSnarrower.toFTDAGMSMember(handler);

    if (member==null)
    {
      throw new InvalidGroupHandlerFactoryException();
    }

    return member;
  }

}
