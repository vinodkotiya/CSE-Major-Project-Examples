package FTDA.gmns;

import FTDA.util.Configuration;
import FTDA.util.Error;
import FTDA.util.ErrorHandler;
import FTDA.util.Parameters;
import FTDA.util.ParameterException;
import FTDA.util.TraceInfo;
import FTDA.util.logging.Logger;

import FTDA.domains.utils.ExitHandler;

import FTDA.middleware.gmns.GMNSMain;
import FTDA.middleware.gmns.GMNSRegister;

import java.io.IOException;
import java.util.Vector;

import javax.swing.JOptionPane;

public class Main implements ErrorHandler, GMNSMain
{

//*************************************************************************************//
//**************************** CONSRUCTOR *********************************************//
//*************************************************************************************//

  public Main()
  {
    Trace.code("Main.java -> Main ( )");
    Error.setErrorHandler(this);
  }

  public void runGMNS(boolean graph)
  {
    Trace.code("Main.java -> void runGMNS ( boolean graph )");
    try
    {
      GMNSObserver observer = null;
      ExitHandler exitHandler = null;
      if (graph)
      {
        GMNSGraphic graphic = new GMNSGraphic("GMNS");
        exitHandler = graphic.getExitHandler();
        observer = graphic;
      }
      else
        observer = new GMNSText();
      new GroupMembershipNamingServiceImpl(new DataListener(observer).theMapStringSetObserver(),observer, exitHandler);
    }
    catch (Exception ex)
    {
      handleException(Consts.AREA, ex);
    }

  }

//*************************************************************************************//
//**************************** DEBUG OUTPUT OPERATIONS ********************************//
//*************************************************************************************//

  /**
    * Output the debug message
    **/
  public boolean handleError(String area, String debugMessage)
  {
    Trace.code("Main.java -> boolean handleError ( String area , String debugMessage )");
    JOptionPane.showMessageDialog(null, debugMessage, "Error",JOptionPane.INFORMATION_MESSAGE);
    return true;
  }

  /**
    * Output the debug message
    **/
  public boolean handleException(String area, Exception ex)
  {
    Trace.code("Main.java -> boolean handleException ( String area , Exception ex )");
    TraceInfo ti = new TraceInfo(ex);
    handleError(area, "Exception " + ti.getException() + " originated from " + ti);
    return true;
  }

//*************************************************************************************//
//**************************** READ ARGS **********************************************//
//*************************************************************************************//

  /**
    * Reads the command line arguments, and initializes the
    * Configuration singleton class
    * Returns the action to do (EXIT, GRAPH_VERSION...)
    **/
  public static int readArgs(String args[])
  {
    int ret=GRAPHIC_VERSION;
    try
    {
      Vector params=new Vector();
      params.add(CONFIGURATION);
      params.add(LOGFILE);
      params.add(NOGRAPHIC);
      params.add(HELP);

      Parameters parameters = new Parameters(args, params, null,0,0);
      if (parameters.hasParameter(HELP))
      {
        help();
        ret=EXIT;
      }
      else
      {
        if (parameters.hasParameter(NOGRAPHIC))
          ret=NON_GRAPHIC_VERSION;
        if (parameters.hasParameter(CONFIGURATION))
          Configuration.getSingleton(parameters.getParameter(CONFIGURATION), parameters.getDefinitions());
        else
          Configuration.getSingleton(parameters.getDefinitions());
        if (parameters.hasParameter(LOGFILE))
          Logger.setLogName(parameters.getParameter(LOGFILE));
      }
    }
    catch (ParameterException pex)
    {
      System.err.println("Arguments error: " + pex.getMessage());
      help();
      ret=EXIT;
    }
    catch (IOException ioex)
    {
      System.err.println("Error reading the configuration file: " + ioex.getMessage());
    }
    return ret;
  }

//*************************************************************************************//
//**************************** HELP ***************************************************//
//*************************************************************************************//

  static void help()
  {
    Trace.code("Main.java -> void help ( )");
      System.out.println("arguments: \n\t["
        + CONFIGURATION + "=configuration file] \n\t["
        + LOGFILE + "=log file] \n\t["
        + NOGRAPHIC + "] \n\t["
        + HELP + "]"
      );
  }

  public static void main(String args[])
  {
    int argAction = readArgs(args);
    if (argAction!=EXIT)
      new GMNSRegister(new Main(), args, argAction==GRAPHIC_VERSION);
  }

  final public static int EXIT=0;
  final public static int GRAPHIC_VERSION=1;
  final public static int NON_GRAPHIC_VERSION=2;

  final static String CONFIGURATION="conf";
  final static String NOGRAPHIC="nographic";
  final static String LOGFILE="log";
  final static String HELP="help";
}
