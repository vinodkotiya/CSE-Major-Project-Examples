package FTDA.gmns;

import FTDA.util.Configuration;
import FTDA.middleware.domains.DomainGroupHandler;
import FTDA.middleware.gmns.MapStringSet;
import FTDA.middleware.gmns.MapStringSetState;
import FTDA.middleware.gmns.SetMemberInfo;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Timer;
import java.util.TimerTask;


/**
  * Class to handle the persistence of the information. It keeps a simple logic, storing the
  * state at fixed intervals.
  **/
class PersistenceHandler extends TimerTask
{
  public PersistenceHandler(DomainGroupHandler handler,MapStringSet map, boolean readFirst, GMNSAutoObserver observer)
  {
    Trace.code("PersistenceHandler.java -> PersistenceHandler ( DomainGroupHandler handler , MapStringSet map , boolean readFirst , GMNSAutoObserver observer )");
    this.map=map;
    this.firstRead=readFirst;
    streamer = new StreamPersistence(handler);
    int first = readFirst? 1 : delay;
    this.observer=observer;
    if (readFirst)
      observer.readingStateFromBackup();
    else
      observer.stateReceived(this);
    new Timer(true).schedule(this,first,delay);
  }

  void readFile()
  {
    Trace.code("PersistenceHandler.java -> void readFile ( )");
    BufferedInputStream stream = null;
    try
    {
      stream = new BufferedInputStream(new FileInputStream(backupFile));
      SetMemberInfo sets[]=streamer.readMapState(map,stream);
      int size=sets.length;
      for (int i=0;i<size;i++)
        sets[i].setState(streamer.readSetState(stream));
    }
    catch(Exception ex)
    {
      System.err.println("Error reading the backup file: " + ex.toString());
    }
    finally
    {
      try{stream.close();}catch(Exception ex){}
    }
    observer.stateReceived(this);
  }

  public synchronized void writeFile()
  {
    Trace.code("PersistenceHandler.java -> synchronized void writeFile ( )");
    BufferedOutputStream stream = null;
    try
    {
      stream = new BufferedOutputStream(new FileOutputStream(backupFile));
      streamer.writeMapState((MapStringSetState) map.getState(),stream);
    }
    catch(Exception ex)
    {
      System.err.println("Error reading the backup file: " + ex.toString());
    }
    finally
    {
      try{stream.close();}catch(Exception ex){}
    }
  }

  public void run()
  {
    Trace.code("PersistenceHandler.java -> void run ( )");
    if (firstRead)
    {
      firstRead=false;
      readFile();
    }
    else
      writeFile();
  }

  boolean firstRead;
  StreamPersistence streamer;
  MapStringSet map;
  GMNSAutoObserver observer;
  static File backupFile = Configuration.getSingleton().getGMNSBackupFile();
  static int delay = Configuration.getSingleton().getGMNSBackupPeriod()*1000;
}

