package FTDA.gmns;

import FTDA.middleware.domains.DomainGroupHandler;
import FTDA.middleware.gms.GMSnarrower;
import FTDA.middleware.gms.GroupHandler;
import FTDA.middleware.gms.GroupMember;
import FTDA.middleware.gmns.GMNSnarrower;
import FTDA.middleware.gmns.MapStringSet;
import FTDA.middleware.gmns.MapStringSetEntry;
import FTDA.middleware.gmns.MapStringSetState;
import FTDA.middleware.gmns.MemberInfo;
import FTDA.middleware.gmns.ReplicatedServer;
import FTDA.middleware.gmns.SetMemberInfo;
import FTDA.middleware.gmns.SetMemberInfoState;
import FTDA.middleware.util.ObjectsHandling;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
  * Class to handle the persistence to an stream
  **/
class StreamPersistence
{

  public StreamPersistence(DomainGroupHandler handler)
  {
    Trace.code("StreamPersistence.java -> StreamPersistence ( DomainGroupHandler handler )");
    this.handler=handler;
  }

  public void writeMapState(MapStringSetState state, OutputStream os) throws IOException
  {
    Trace.code("StreamPersistence.java -> void writeMapState ( MapStringSetState state , OutputStream os )");
    //It's first written the group's state, and then the groups, following the right order
    MapStringSetEntry groups[] = state.groups;
    int size = groups.length;
    writeInt(size, os);
    for (int i=0;i<size;i++)
      writeString(groups[i].key,os);
    for (int i=0;i<size;i++)
      writeSet(GMNSnarrower.toSetMemberInfo(handler.getSubgroup(groups[i].value)), os);
  }

  public SetMemberInfo[] readMapState(MapStringSet map, InputStream is) throws IOException, Exception
  {
    Trace.code("StreamPersistence.java -> SetMemberInfo [ ] readMapState ( MapStringSet map , InputStream is )");
    int size=readInt(is);
    SetMemberInfo sets[] = new SetMemberInfo[size];
    MapStringSetEntry groups[] = new MapStringSetEntry[size];
    for (int i=0;i<size;i++)
    {
      String name = readString(is);
      SetMemberInfoImpl set = new SetMemberInfoImpl(Consts.noInfo,handler);
      groups[i]=new MapStringSetEntry(name, set.getSubgroupId());
      sets[i]=set.theSetMemberInfo();
    }
    map.setState(GMNSFactory.createMapState(groups));
    return sets;
  }

  void writeSet(SetMemberInfo set, OutputStream os) throws IOException
  {
    Trace.code("StreamPersistence.java -> void writeSet ( SetMemberInfo set , OutputStream os )");
    if(set==null)
      writeInt(0,os);
    else
    {
      SetMemberInfoState state = (SetMemberInfoState) set.getState();
      MemberInfo members[] = state.members;
      int size = members.length;
      writeInt(size,os);
      for (int i=0;i<size;i++)
        writeMemberInfo(members[i],os);
    }
  }

  public SetMemberInfoState readSetState(InputStream is) throws IOException, ClassNotFoundException
  {
    Trace.code("StreamPersistence.java -> SetMemberInfoState readSetState ( InputStream is )");
    int size = readInt(is);
    MemberInfo members[] = new MemberInfo[size];
    for (int i=0;i<size;i++)
      members[i]=readMemberInfo(is);
    return GMNSFactory.createSetState(members);
  }

  void writeMemberInfo(MemberInfo info, OutputStream os) throws IOException
  {
    Trace.code("StreamPersistence.java -> void writeMemberInfo ( MemberInfo info , OutputStream os )");
    ObjectsHandling.writeObject(info.handler,os);
    writeString(info.name, os);
    ObjectsHandling.writeObject(info.publicReference,os);
  }

  MemberInfo readMemberInfo(InputStream is) throws IOException, ClassNotFoundException
  {
    Trace.code("StreamPersistence.java -> MemberInfo readMemberInfo ( InputStream is )");
    GroupHandler gh = GMSnarrower.toGroupHandler(ObjectsHandling.readObject(is));
    String name = readString(is);
    ReplicatedServer rs = GMNSnarrower.toReplicatedServer(ObjectsHandling.readObject(is));
    return new MemberInfo(gh,name,rs);
  }

  void writeString(String str, OutputStream os) throws IOException
  {
    Trace.code("StreamPersistence.java -> void writeString ( String str , OutputStream os )");
    DataOutputStream dos = new DataOutputStream(os);
    dos.writeUTF(str);
  }

  String readString(InputStream is) throws IOException
  {
    Trace.code("StreamPersistence.java -> String readString ( InputStream is )");
    DataInputStream dis = new DataInputStream(is);
    return dis.readUTF();
  }

  void writeInt(int number, OutputStream os) throws IOException
  {
    Trace.code("StreamPersistence.java -> void writeInt ( int number , OutputStream os )");
    DataOutputStream dos = new DataOutputStream(os);
    dos.writeInt(number);
  }

  int readInt(InputStream is) throws IOException
  {
    Trace.code("StreamPersistence.java -> int readInt ( InputStream is )");
    DataInputStream dis = new DataInputStream(is);
    return dis.readInt();
  }

  DomainGroupHandler handler;
}

