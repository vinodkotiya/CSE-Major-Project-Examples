package FTDA.gms;

import FTDA.middleware.gms.AllowTokenRecoveryAnswer;
import FTDA.middleware.gms.GroupMember;
import FTDA.middleware.gms.InternalView;
import FTDA.middleware.gms.InternalViewId;
import FTDA.middleware.gms.Message;
import FTDA.middleware.gms.MessageId;
import FTDA.middleware.gms.FTDAGMSMember;
import FTDA.middleware.gms.FTDAGMSMemberImpl;
import FTDA.middleware.gms.Token;

import FTDA.util.Error;
import FTDA.util.Rerunnable;
import FTDA.util.RestartableThread;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

/**
  * ActiveGroupMember is the part of the FTDAGMSMember that handles
  * all the logic of the group.
  * It's a thread object, activated each time that the token is received,
  * or automatically to recover a lost token
  * There is a biunivoc relation between a FTDAGMSMember and an ActiveGroupMember,
  * the FTDAGMSMember belongs to the group through the ActiveGroupMember, and this
  * one represents to the FTDAGMSMember, which must pass every group event received
  * to the ActiveGroupMember.
  **/
public class ActiveGroupMember extends FTDAGMSMemberImpl implements Rerunnable
{

//*************************************************************************************//
//**************************** CONSTRUCTOR ********************************************//
//*************************************************************************************//

  /**
    * This constructor creates a FTDAGMSMember inactive. To activate it, two options
    * are possible: to create by itself a group, or be attached to another member in
    * the ring, in which case it will automatically receive a view.
    * @param groupMember is the object receiving the FTDA GMS events.
    * @exception Exception. The object being constructed is a middleware object and
    *     the creation of such object can raise some specific exception. For example,
    *     in the case of RMI, a possibility is to have a RemoteException if the object
    *     cannot be exported
    **/
  public ActiveGroupMember(GroupMember groupMember) throws Exception
  {
    Trace.code("ActiveGroupMember.java -> ActiveGroupMember ( GroupMember groupMember )");
    this.groupMember = groupMember;
    thisFTDAGMSMember = theFTDAGMSMember();
    thisMemberId = -ViewHandler.generateFirstMemberId();
  }

//*************************************************************************************//
//**************************** CREATE GROUP *******************************************//
//*************************************************************************************//

  /**
    * This method starts a new group where the only member is this member. This member
    * cannot be part of any other group, or the creation will fail
    **/
  public boolean createGroup()
  {
    Trace.code("ActiveGroupMember.java -> boolean createGroup ( )");
    boolean validCreation = viewStatus == MEMBER_NOT_IN_VIEW;

    if (validCreation)
    {
      //Creation of a first ficticious view. view.installing must be differente of zero,
      //as the algorithm will make a simulation of a token reception upon which the member
      //really joins the view
      InternalViewId viewId = new InternalViewId(1,1);
      FTDAGMSMember[] members = new FTDAGMSMember[1];
      int memberIds[] = new int[1];
      members[0]=thisFTDAGMSMember;
      memberIds[0]=-thisMemberId;
      int newMembers[] = new int[1];
      newMembers[0] = memberIds[0];
      view = new InternalView(viewId, members, memberIds, newMembers);

      //shared constructor
      startGroupActivities (view, null);

      //view is considered to be installed
      viewInstalled();

      //a token is created and started.
      receiveToken(thisMemberId, tokenState.getToken());
    }

    return validCreation;
  }

//*************************************************************************************//
//**************************** JOIN GROUP *********************************************//
//*************************************************************************************//

  /**
    * This method joins an existing group. This joining can fail, and in that case
    * it is returned false and this object is invalidated, that is, cannot be used
    * to join another member. It can fail as well if the member belonged already to
    * other group; in that case, the member is not invalidated (it can be checked
    * previously using validObject())
    **/
  public boolean joinGroup(FTDAGMSMember group)
  {
    Trace.code("ActiveGroupMember.java -> boolean joinGroup ( FTDAGMSMember group )");
    boolean joined = viewStatus == MEMBER_NOT_IN_VIEW;

    if (joined)
    {
      try
      {
        //this methods blocks until the group includes this member in the group, buf before
        //this member is officially included. That is, it can be included in some temporal view,
        //but still expulsed before the first official view.
        joined = group.addGroupMember(thisFTDAGMSMember);
      }
      catch (Exception ex)
      {
        joined=false;
        Trace.handledException(ex);
      }
      synchronized(this)
      {
        //if addGroupMember has really returned false, next proof is harmless
        while(isValidGroup() && !memberAccepted)
          try
          {
            wait();
          }
          catch(InterruptedException ex)
          {
            Trace.handledException(ex);
          }
      }
      joined=isValidGroup();
      if (!joined)
        doLeaveGroup();	//assuring that everything is released!
    }

    return joined;
  }

//*************************************************************************************//
//**************************** GET GROUP MEMBER ID ************************************//
//*************************************************************************************//

  public int getGroupMemberId()
  {
    Trace.code("ActiveGroupMember.java -> int getGroupMemberId ( )");
    return thisMemberId;
  }

//*************************************************************************************//
//**************************** IS VALID GROUP *****************************************//
//*************************************************************************************//

  /**
    * Verifies if this object is still valid
    **/
  public boolean isValidGroup()
  {
    Trace.code("ActiveGroupMember.java -> boolean isValidGroup ( )");
    return viewStatus<MEMBER_NOT_IN_VIEW;
  }

//*************************************************************************************//
//**************************** LEAVE GROUP ********************************************//
//*************************************************************************************//

  public boolean leaveGroup()
  {
    Trace.code("ActiveGroupMember.java -> boolean leaveGroup ( )");
    boolean ret;
    synchronized (this)
    {
      ret = !leaving && viewStatus != MEMBER_NOT_IN_VIEW && viewStatus != MEMBER_EXPULSED;
      leaving=true;
      //cannot wait to really leave the group, as the call to leave can have been performed
      //after a call from the GMS!
    }
    return ret;
  }

  /**
    * leaves the group
    **/
  private void doLeaveGroup()
  {
    Trace.code("ActiveGroupMember.java -> void doLeaveGroup ( )");
    try
    {
      boolean performIt;
      synchronized (this)
      {
        performIt = viewStatus != MEMBER_NOT_IN_VIEW && viewStatus != MEMBER_EXPULSED;
        viewStatus = MEMBER_EXPULSED;
      }
      if (performIt)
      {
        deactivate();
        restartableThread.end();

        tokenRecoverer.stop();
        //eventsDispatcher.stopDispatching(); //if it's done here, it will block if leaveGroup is called while
        //an event is dispatched. It can be done on the freeResources, or directly later, on a separate thread
      }
    }
    catch(Exception ex)
    {
      Error.unhandledException(Consts.GMS, ex);
    }

    //freeResources waits for the restartableThread to finish, and also
    //for the GroupEventsDispatcher. But those threads can have called to
    //leaveGroup, and in that case the system would halt.
    new Thread(){public void run()
        {
            if (eventsDispatcher!=null)
              eventsDispatcher.stopDispatching();
            yield();
            freeResources();}
        }.start();
  }

//*************************************************************************************//
//**************************** FREE RESOURCES *****************************************//
//*************************************************************************************//

  /**
    * Releases any resource associated to this object (~destructor)
    **/
  void freeResources()
  {
    Trace.code("ActiveGroupMember.java -> void freeResources ( )");
    FTDAGMSMember temp;
    synchronized (this)
    {
      temp = thisFTDAGMSMember;
      thisFTDAGMSMember = null;
    }

    if (temp!=null)
    {
      try
      {
        if (restartableThread != null)
          restartableThread.join();
        if (viewHandler != null)
          viewHandler.freeResources();
        if (messageCenter != null)
          messageCenter.freeResources();
        if (joiningMembers != null)
          joiningMembers.freeResources();
        if (tokenRecoverer != null)
          tokenRecoverer.freeResources();
        if (tokenState != null)
          tokenState.freeResources();

        thisFTDAGMSMember		= null;
        viewHandler				= null;
        view									=	null;
        messageCenter					= null;
        joiningMembers				= null;
        tokenRecoverer				= null;
        eventsDispatcher      = null;
        tokenControl  				= null;
        groupMember      			= null;
        restartableThread    	= null;
        tokenState            = null;

        memberAccepted				= false;

        Trace.releaseObject("ActiveGroupMember");
      }
      catch(Exception ex)
      {
        Error.unhandledException(Consts.GMS, ex);
      }
    }
  }

//*************************************************************************************//
//**************************** ADD GROUP MEMBER ***************************************//
//*************************************************************************************//

  /**
    * Include other member in the group. This call blocks until the member is joined.
    * This task is a best-effort one; if it returns true means that the member is surely
    * joined. If it returns false, it cannot be guaranteed that it didn't join, and this
    * member or the member to join have been considered to be faulty.
    * @returns true if the member is joined
    **/
  public boolean addGroupMember(FTDAGMSMember joiningMember)
  {
    Trace.code("ActiveGroupMember.java -> boolean addGroupMember ( FTDAGMSMember joiningMember )");
    boolean validObject = isValidGroup();

    assert joiningMember != null;

    //The task is delegated to the joiningMembers object. It returns false if
    //this object is falling down. If it returns tue, is still not sure if the
    //member has joined
    return validObject && joiningMembers.addMember(joiningMember) &&  viewHandler.isValidMember(joiningMember);
  }

//*************************************************************************************//
//**************************** CAST MESSAGE *******************************************//
//*************************************************************************************//

  /**
    * Sends the message to the group
    * @param message the message to send
    * @returns true if the message is sent in this view. If the member doesn't belong
    *     to a group, it returns false as well
    **/
  public boolean castMessage(Message message)
  {
    Trace.code("ActiveGroupMember.java -> boolean castMessage ( Message message )");

    return (message!=null) && isValidGroup() && (!leaving) && messageCenter.castMessage(message);
  }

//*************************************************************************************//
//**************************** SEND MESSAGE *******************************************//
//*************************************************************************************//

  /**
    * Sends the message to the specified member
    * @param target The FTDAGMSMember receiving the message
    * @param message the message to send
    * @returns true if the message is sent in this view. If the member doesn't belong
    *     to a group, it returns false as well
    **/
  public boolean sendMessage(int target, Message message)
  {
    Trace.code("ActiveGroupMember.java -> boolean sendMessage ( int target , Message message )");

    return (message!=null) && isValidGroup() && (!leaving) && messageCenter.sendMessage(target, message);
  }

//*************************************************************************************//
//**************************** ALLOW TOKEN RECOVERY ***********************************//
//*************************************************************************************//

  /**
    * Part of the interface to recover a lost token; the sender communicates its viewId
    * and expects as answer to know if it has the allowance to recover the token.
    * The method returns false or true depending on this member considering excluded the
    * another one or not. If it's not excluded, the parameter recover contains the
    * answer to the request.
    * To answer 'yes', the viewId seen by this member must be lower to the one
    * seen by the sender, or, if it's equal, if the rank of this member is lower or equal
    * to the sender's. And, of course, this member must no be in possesion of the token.
    * Additionally, members being added should not recover the token
    *
    * @param sender The member trying to recover the token
    * @param itsViewId The viewId seen by that member
    * @returns two boolean values, one confirming that the request is accepted, and
	  *                                                                                                                                            	the second one allowing the recovery
    **/
  public AllowTokenRecoveryAnswer allowTokenRecovery(int sender, InternalViewId itsViewId)
  {
    Trace.code("ActiveGroupMember.java -> AllowTokenRecoveryAnswer allowTokenRecovery ( int sender , InternalViewId itsViewId )");
    boolean allowed=isValidGroupMember (sender);
    boolean recover=allowed;

    if (allowed)
    {
      if (tokenState.isTokenOwnedOrBeingSent())
      {
        //check if is being too slow
        if (messageCenter.isSlowOrStopped())
        {
          viewHandler.stopCommunications();
          viewStatus = MEMBER_EXPULSED;
          allowed=recover=false;
          Trace.requestedTokenRecovery(sender, true, "token owner or being sent, but this member is too slow");
        }
        else
        {
          recover = false;	//it has the token or it's already recovering it
          Trace.requestedTokenRecovery(sender, false, "token owner or being sent");
        }
      }
      else if (sender==thisMemberId)
      {
        recover = true;
        Trace.requestedTokenRecovery(sender, true, "request by itself");
      }
      else if (isBiggerViewId(itsViewId, view.viewId))
      {
        recover = true;		//it has a bigger viewId
        Trace.requestedTokenRecovery(sender, true, "its view id (" + itsViewId.id + "," + itsViewId.installing + ") is bigger than this vied id (" + view.viewId.id + "," + view.viewId.installing + ")");
      }
      else if (isBiggerViewId(view.viewId, itsViewId))
      {
        recover = false;	//it has a smaller viewId
        Trace.requestedTokenRecovery(sender, false, "this view id  (" + view.viewId.id + "," + view.viewId.installing + ") is bigger than its vied id (" + itsViewId.id + "," + itsViewId.installing + ")");
      }
      else if (!memberAccepted)
      {
        recover = true;
        Trace.requestedTokenRecovery(sender, true, "member is not accepted");
      }
      else if (viewHandler.isValidInstalledMember(sender))
      {
        recover = sender > thisMemberId;
        Trace.requestedTokenRecovery(sender, recover, "comparison bertween ids");
      }
      else
      {
        recover = false;
        Trace.requestedTokenRecovery(sender, false, "requested is not a valid installed member");
      }

      //stop the tokenRecoverer only if the communication is accepted.
      if (recover  && sender!=thisMemberId)
        tokenRecoverer.communicationReceived();
    }
    else
        Trace.requestedTokenRecovery(sender, false, "requested is not a valid group member");

    AllowTokenRecoveryAnswer answer;
    if (allowed)
      answer = new AllowTokenRecoveryAnswer(allowed, recover, messageCenter.getLastMessageIdProcessed());
    else
      answer = new AllowTokenRecoveryAnswer(allowed, recover, new MessageId(0,0));

    Trace.code("ActiveGroupMember.java -> AllowTokenRecoveryAnswer allowTokenRecovery " + allowed + " - " + recover);
//    Trace.requestedTokenRecovery(sender, answer);

    return answer;
  }

//*************************************************************************************//
//**************************** RECOVER TOKEN ******************************************//
//*************************************************************************************//

  /**
    * Part of the interface to recover a lost token.
    * @param sender The member trying to recover the token
    * @returns True if this member allows to the sender to recover the token
    **/
  public boolean recoverToken(int sender)
  {
    Trace.code("ActiveGroupMember.java -> boolean recoverToken ( int sender )");
    //is allowed if the token is not here and the sender is a valid Group member
    boolean allowed= (sender==thisMemberId) || (!tokenState.isTokenOwnedOrBeingSent() && isValidGroupMember (sender));

    if (allowed)
    {
      //Only that member can send a view, and no tokens or messages can be received on the meanwhile
      memberRecoveringToken = sender;

      //communicate to the TokenRecoverer that a valid communication has been received
      boolean check = tokenRecoverer.communicationReceived();
      assert check || (sender==thisMemberId);
    }

    Trace.groupCommunication(sender, "recoverToken", allowed);
    return allowed;
  }

//*************************************************************************************//
//**************************** RECEIVE PTP MESSAGES ***********************************//
//*************************************************************************************//

  /**
    * This method must be called when PTP messages are received in the group member
    * @param sender The GroupMemberId sending the messages
    * @param messages the messages received
    * @param messageId its messageId. It's only required its viewId
    * @returns true if the messages are accepted
    **/
  public boolean receivePTPMessages(int sender, Message[] messages, MessageId messageId)
  {
    Trace.code("ActiveGroupMember.java -> boolean receivePTPMessages ( int sender , Message [ ] messages , MessageId messageId )");
    //if the token is being recovered, it's not possible to accept messages.
    //it's neither possible if the member is not valid
    boolean messagesAccepted = (memberRecoveringToken==Consts.INVALID_MEMBER_ID) && isValidGroupMember (sender);

    if (messagesAccepted)
    {

      //The tokenRecoverer is accessed to give him notice that a new communication has been
      //received. It can return false and then the message can not be accepted, or it would
      //be colliding with the token recovery. In fact, it means that every member has agreed
      //on allow the token recovery, then no messages should be received!
      if (!tokenRecoverer.communicationReceived())
        messagesAccepted = false;
      else
      {
        //view status can be changed: if before receiving the token that confirms a view as installed,
        //is received a message from a member that has already confirmed it, the view can be
        //considered installed
        changeViewStatus(messageId);

        //The messages are transferred to the MessageCenter, that can still refuse them
        messagesAccepted = messageCenter.messagesPTPReceived(sender, messages);

        if (messagesAccepted)
        {
          //the tokenControl must be aware of the new group communication
          tokenControl.groupCommunication();
          Trace.messagePTPReceived(sender);
        }
      }
    }

    Trace.groupCommunication(sender, "receivePTPMessages", messagesAccepted);
    return messagesAccepted;
  }

//*************************************************************************************//
//**************************** RECEIVE MESSAGES ***************************************//
//*************************************************************************************//

  /**
    * This method must be called when messages are received in the group member
    * @param sender The GroupMemberId sending the messages
    * @param messages the messages received
    * @param messageId its messageId
    * @returns true if the messages are accepted
    **/
  public boolean receiveMessages(int sender, Message[] messages, MessageId messageId)
  {
    Trace.code("ActiveGroupMember.java -> boolean receiveMessages ( int sender , Message [ ] messages , MessageId messageId )");
    //if the token is being recovered, it's not possible to accept messages.
    //it's neither possible if the member is not valid
    boolean messagesAccepted = (memberRecoveringToken==Consts.INVALID_MEMBER_ID) && isValidGroupMember (sender);

    if (messagesAccepted)
    {

      //The tokenRecoverer is accessed to give him notice that a new communication has been
      //received. It can return false and then the message can not be accepted, or it would
      //be colliding with the token recovery. In fact, it means that every member has agreed
      //on allow the token recovery, then no messages should be received!
      if (!tokenRecoverer.communicationReceived())
        messagesAccepted = false;
      else
      {

        //view status can be changed: if before receiving the token that confirms a view as installed,
        //is received a message from a member that has already confirmed it, the view can be
        //considered installed
        changeViewStatus(messageId);

        //the new members don't process messages, they belong to the flushing on the previous view
        if (memberAccepted)
        {
          //The messages are transferred to the MessageCenter, that can still refuse them
          //Note that it could be refused, but the recoverer has already been said that a
          //communication was good. This means that a member could be sending messages,
          //avoiding to recover the token. But the algorithm cannot avoid wrong members!
          //It could avoid a member who would retaing the token, but not one that would
          //destroy the group just sending different views to each member.
          //Therefore, it's only returned false (this or that member will be disconnected),
          //and a trace is generated
          messagesAccepted = messageCenter.messagesReceived(sender, messages, messageId);
        }
      }
    }

    if (messagesAccepted)
    {
      //the tokenControl must be aware of the new group communication
      tokenControl.groupCommunication();
      Trace.messageReceived(messageId, false);
    }
    else
      Trace.wrongMessage(sender, messageId, false);

    return messagesAccepted;
  }

//*************************************************************************************//
//**************************** CONFIRM MESSAGES ***************************************//
//*************************************************************************************//

  /**
    * This method must be called when messages are confirmed
    * @param sender The GroupMemberId sending the confirmation
    * @param messageId its messageId
    * @returns true if the messages are accepted
    **/
  public boolean confirmMessages(int sender, MessageId messageId)
  {
    Trace.code("ActiveGroupMember.java -> boolean confirmMessages ( int sender , MessageId messageId )");
    //if the token is being recovered, it's not possible to accept messages.
    //it's neither possible if the member is not valid
    boolean messagesAccepted = (memberRecoveringToken==Consts.INVALID_MEMBER_ID) && isValidGroupMember (sender);

    if (messagesAccepted)
    {

      //The tokenRecoverer is accessed to give him notice that a new communication has been
      //received. It can return false and then the message can not be accepted, or it would
      //be colliding with the token recovery
      if (!tokenRecoverer.communicationReceived())
        messagesAccepted = false;
      else
      {
        //the new members don't process messages, they belong to the flushing on the previous view
        if (memberAccepted)
        {
          //The messages are transferred to the MessageCenter, that can still refuse them
          //Note that it could be refused, but the recoverer has already been said that a
          //communication was good. This means that a member could be sending messages,
          //avoiding to recover the token. But the algorithm cannot avoid wrong members!
          //It could avoid a member who would retaing the token, but not one that would
          //destroy the group just sending different views to each member.
          //Therefore, it's only returned false (this or that member will be disconnected),
          //and a trace is generated
          messagesAccepted = messageCenter.messagesConfirmed(sender, messageId);

        }
      }
    }

    if (messagesAccepted)
    {
      //the tokenControl must be aware of the new group communication
      tokenControl.groupCommunication();
      Trace.messageReceived(messageId, true);
    }
    else
      Trace.wrongMessage(sender, messageId, true);

    return messagesAccepted;
  }

//*************************************************************************************//
//**************************** RECEIVE VIEW *******************************************//
//*************************************************************************************//

  /**
    * This method must be called when a view is received in the Group Member
    * @param sender The GroupMember sending the token
    * @param receivedView The view to install
    * @param viewToken the token to be used during the view
    * @returns true if the view is accepted
    **/
  public boolean receiveView(int sender, InternalView receivedView, Token viewToken)
  {
    Trace.code("ActiveGroupMember.java -> boolean receiveView ( int sender , InternalView receivedView , Token viewToken )");
    boolean viewAccepted=true;
    memberAutoExcluding=Consts.INVALID_MEMBER_ID;

    if (viewStatus == MEMBER_NOT_IN_VIEW)
      viewAccepted = startGroupActivities(receivedView, viewToken);
    else if (viewStatus == MEMBER_EXPULSED)
      viewAccepted = false;
    else
    {

      Trace.viewReceived(receivedView);

      //if the token is being recovered, it's only possible to accept the view from
      //the member recovering it. After receiving the view, it's considered to be recovered
      //(Additionally, the token received must be different from the existing one)
      if (memberRecoveringToken!=Consts.INVALID_MEMBER_ID)
        if ((memberRecoveringToken==sender) && !tokenState.isSameToken(viewToken))
          memberRecoveringToken = Consts.INVALID_MEMBER_ID;
        else
          viewAccepted = false;

      if (viewAccepted)
      {

        if (sender!=thisMemberId)
        {
          //a view is only accepted is bigger than the current one
          //and the sender is a valid group member and the change in the viewStatus is
          //considered valid, and this member doesn't have the token or is recovering it!
          if (isBiggerViewId (receivedView.viewId, view.viewId) && isValidGroupMember (sender) &&
                         !tokenState.isTokenOwned() && changeViewStatus(receivedView.viewId))
          {
            if (viewHandler.changeMembers(sender, receivedView, true))
              memberAutoExcluding = sender;
          }
          else
          {
            viewAccepted = false;
          }
        }

        if (viewAccepted)
        {
          //copy the view data
          view.viewId.id          = receivedView.viewId.id;
          view.viewId.installing  = receivedView.viewId.installing;
          view.members            = receivedView.members;
          view.memberIds          = receivedView.memberIds;
          view.newMembers         = receivedView.newMembers;

          tokenState.changeToken(viewToken);

          //communicate the new view to the TokenRecoverer. No problem with its answer
          tokenRecoverer.communicationReceived(view);

          //communicate to the messageCenter that there is a new temporal view
          messageCenter.newTemporalView (sender);

          //the tokenControl must be aware of the new group communication
          tokenControl.groupCommunication();

          Trace.viewAccepted(view, thisMemberId);
        }

      }
    }

    Trace.groupCommunication(sender, "receiveView", viewAccepted);
    return viewAccepted;
  }

//*************************************************************************************//
//**************************** RECEIVE TOKEN ******************************************//
//*************************************************************************************//

  /**
    * This method must be called when the token is received, to
    * activate the FTDAGMSMember
    * @param sender The GroupMember  sending the token
    * @param token the token received
    * @returns true if the token is accepted
    **/
  public boolean receiveToken(int sender, Token token)
  {
    Trace.code("ActiveGroupMember.java -> boolean receiveToken ( int sender , Token token )");
    //the token is accepted if the sender belongs to the group and there is no member recovering
    //the token, and it's the same one known in the group
    boolean tokenAccepted = isValidGroup() && (memberRecoveringToken==Consts.INVALID_MEMBER_ID)
                            && tokenState.isSameToken(token) &&
                            ((sender == memberAutoExcluding)  || viewHandler.isPrevMemberInView(sender));
    memberAutoExcluding=Consts.INVALID_MEMBER_ID;
    if (tokenAccepted)
      try
      {
        tokenState.tokenReceived();
        //TokenRecoverer is not accessed, that will be done in the activated method,
        //called after activate()
        restartableThread.activate(0, token);
      }
      catch(Exception ex)
      {
        Error.unhandledException(Consts.GMS, ex);
      }

    return tokenAccepted ;
  }


//*************************************************************************************//
//**************************** TOKEN LOST *********************************************//
//*************************************************************************************//

  /**
    * This method is the interface to the TokenRecoverer class to receive the notification
    * of a token lost
    * @param ccm The CommunicationChannelManager used to verify that the token is lost
    * @return false if the TokenRecoverer should stop any activity
    **/
  public boolean tokenLost(CommunicationChannelsManager ccm)
  {
    Trace.code("ActiveGroupMember.java -> boolean tokenLost ( CommunicationChannelsManager ccm )");
    boolean ret = isValidGroup();

    if (ret)
    {
      //it is considered as being received the token, although the internal operations
      //will be different than from just recovering the token
      try
      {
        restartableThread.activate(0, ccm);
      }
      catch(Exception ex)
      {
        Error.unhandledException(Consts.GMS, ex);
      }
    }
    return ret;
  }


//*************************************************************************************//
//**************************** ACTIVATED **********************************************//
//*************************************************************************************//

  /**
    * RestartableThread method, called after receiving the token, or when the token
    * get lost
    * @param taskParam is the token received if the activation is due to the reception
    *        of the token, or the communicationChannelManager used by the TokenRecoverer
    *        to recover the token when the activations is due to a token lost
    * @returns false if the member looses the consensus
    **/
  public boolean activated(Object taskParam)
  {
    Trace.code("ActiveGroupMember.java -> boolean activated ( Object taskParam )");
    boolean sentOk=true;

    if (taskParam instanceof Token)
    {
      //the token must be valid, or the activation would be due to a previous token
      //(it was received when a new one was being generated by this member).
      if (tokenState.isSameToken((Token)taskParam))
        sentOk = tokenActive(false, null);
      else
        ;//the token is just discarded, the consensus is not lost, return true
    }
    else
    {
      assert taskParam instanceof CommunicationChannelsManager;
      sentOk = startTokenRecovery((CommunicationChannelsManager) taskParam);
    }

    if (!sentOk)
      consensusLost();

    Trace.code("ActiveGroupMember.java -> boolean activated ( Object taskParam ) ENDED, sentOk="+sentOk);
    return sentOk;
  }

//*************************************************************************************//
//**************************** TOKEN ACTIVE *******************************************//
//*************************************************************************************//

  /**
    * Method called when the member obtains the token
    * @param sendViewAnyway set to true if the view must be sent even when there are
    *        no new members or faulty members.
    * @param confirmation the identity of the message that must be confirmed. Null if
    *          no messages must be confirmed
    **/
  boolean tokenActive(boolean sendViewAnyway, MessageId confirmation)
  {
    Trace.code("ActiveGroupMember.java -> boolean tokenActive ( boolean sendViewAnyway , MessageId confirmation )");
    boolean sentOk=true;

    //stop the token recoverer, the token is here!
    tokenRecoverer.stop();

    Trace.token(true);

    //check and change the view status
    changeViewStatus();

    //send a new view if it's needed
    sentOk = sendViewIfNeeded (sendViewAnyway);

    //if can be needed to send first the confirmation to a previous message, only
    //when a token has been recovered
    if (sentOk && confirmation!=null)
      sentOk = sendMessageConfirmation(confirmation);

    //send message if it's needed
    sentOk = sentOk && sendMessages();

    if (sentOk)
    {
      //speed down the token if required
      tokenControl.toPassToken();
      boolean loop=true;
      while(loop)
      {
        //this is the place to leave
        if (leaving)
        {
          sendAutoExclusionViewAndToken();
          sentOk=loop=false;
        }
        else if (tokenState.sendToken())
          loop=false;
        else
        {
          //if the sent has failed, a new view must be installed, and a new token sent
          //if the consensus is kept.
          //It's also needed to send the messages, as otherwise they could be unsent on
          //the right view
          loop = sentOk = sentOk && sendView() && sendMessages();
        }
      }
    }

    if (sentOk)
    {
      tokenRecoverer.resume();
      Trace.token(false);
    }

    return sentOk;
  }

//*************************************************************************************//
//**************************** START TOKEN RECOVERY ***********************************//
//*************************************************************************************//

  /**
    * Method called when the member is activated to recover the token
    * @param communicationChannelsManager The CommunicationChannelsManager used by the
    *        tokenRecoverer to verify that the token was lost
    * @returns false if the member looses the consensus
    **/
  boolean startTokenRecovery(CommunicationChannelsManager communicationChannelsManager)
  {
    Trace.code("ActiveGroupMember.java -> boolean startTokenRecovery ( CommunicationChannelsManager communicationChannelsManager )");

    assert communicationChannelsManager!=null;

    boolean consensusKept=true;

    //The TokenRecoverer is accesed to check that there has been no new communications
    //during the activation (the activation can be delayed if the token arrived and
    //the Thread was activated, for example)
    if (tokenRecoverer.verifyTokenIsLost(communicationChannelsManager))
    {
      //the channels manager must be verified as to be a valid object, otherwise
      //it could contain no valid information!
      if (communicationChannelsManager.isValidObject())
      {
        //the token is considered to be owned
        tokenState.tokenReceived();

        //regenerate the token.
        Trace.tokenRecovery(Trace.TokenRecoveryStarted);

        //the wrong members in the received communicationChannelsManager must be removed
        //from the current manager
        InternalView newView = new InternalView();
        viewHandler.changeMembers(thisMemberId, communicationChannelsManager.getView(newView,false), false);

        //consensus could be lost!
        //if not, it's send the signal to recover the token
        consensusKept=viewHandler.consensus() && viewHandler.sendTokenRegeneration();

        if (consensusKept)
        {
          //unfroze the recovererToken and consider the token owned, then call to tokenActive
          MessageId confirmingMessageId = tokenRecoverer.getMessageToConfirm();
          tokenRecoverer.tokenIsLostVerified();
          viewStatus = RECEIVED_TEMPORAL_VIEW;
          consensusKept = tokenActive(true, confirmingMessageId);
        }
      }
      else
        consensusKept=false;

    }

    return consensusKept;
  }

//*************************************************************************************//
//**************************** SEND MESSAGE CONFIRMATION ******************************//
//*************************************************************************************//

  /**
    * Sends the confirmation to process the message specified
    * @returns true if the consensus is kept
    **/
  boolean sendMessageConfirmation(MessageId messageId)
  {
    Trace.code("ActiveGroupMember.java -> boolean sendMessageConfirmation ( MessageId messageId )");
    assert messageId!=null;

    //1- The confirmation to the message is sent
    boolean sentOk = viewHandler.confirmMessages(messageId);

    //2. If there are problems sending the messages, it must be checked if there
    //		is consensus and install a new view
    if (!sentOk)
      sentOk = sendView();

    return sentOk;
  }

//*************************************************************************************//
//**************************** SEND MESSAGES ******************************************//
//*************************************************************************************//

  /**
    * Sends the messages, if there are messages to be sent
    * @returns true if the consensus is kept
    **/
  boolean sendMessages()
  {
    Trace.code("ActiveGroupMember.java -> boolean sendMessages ( )");
    boolean sentOk=true;

    MessageId confirmMessageId = null;

    while (sentOk && messageCenter.hasMessagesToSend())
    {
      int targetMember = messageCenter.getMessagesTarget();
      Message[] messages = messageCenter.getMessagesToSend();

      if (targetMember==Consts.EVERY_MEMBER_ID)
      {
        //cast
        if (confirmMessageId == null)
          confirmMessageId = messageCenter.getNextMessageId();
        else
          confirmMessageId.id++;

        Trace.messageSent(confirmMessageId,false);

        //Messages are sent
        sentOk = viewHandler.castMessages(messages, confirmMessageId);

      }
      else
      {
        //ptp message
        MessageId messageId = messageCenter.getPTPMessageId();

        Trace.messagePTPSent(targetMember);

        //Messages are sent
        sentOk = viewHandler.sendMessages(targetMember, messages, messageId);

      }

      // If there are problems sending the messages, it must be checked if there
      // is consensus and install a new view
      if (!sentOk)
        sentOk = sendView();

    }

    //if the sent has been all right and there were cast messages to send, they must be confirmed
    if (sentOk && confirmMessageId!=null)
    {
      Trace.messageSent(confirmMessageId,true);
      sentOk = sendMessageConfirmation (confirmMessageId);

      // If there are problems sending the messages, it must be checked if there
      // is consensus and install a new view
      if (!sentOk)
        sentOk = sendView();

    }

    return sentOk;
  }

//*************************************************************************************//
//**************************** SEND VIEW IF NEEDED ************************************//
//*************************************************************************************//

  /**
    * Checks if it's needed to send a view, because there are new members to add or
    * faulty members; if it's needed, the view is sent.
    * It returns false if there have been problems sending the view, in which case
    * this member must be considered excluded!
    * @param sendViewAnyway set to true if the view must be sent even when there are
    *        no new members or faulty members.
    **/
  boolean sendViewIfNeeded(boolean sendViewAnyway)
  {
    Trace.code("ActiveGroupMember.java -> boolean sendViewIfNeeded ( boolean sendViewAnyway )");
    boolean sentOk			=	true;
    boolean sendNeeded 	= sendViewAnyway;

    FTDAGMSMember[] newMembers = joiningMembers.getMembers();

    //it's needed to send a new view if there are new members or faulty ones
    if (newMembers!=null)
    {
      viewHandler.addNewChannels(newMembers);
      sendNeeded = true;
    }
    else
      sendNeeded = viewHandler.faultyMembersToCommunicate();

    if (sendNeeded || sendViewAnyway)
      sentOk = sendView ();

    if (newMembers!=null)
      //this call wakes up the members waiting to be joined
      joiningMembers.removeMembers(newMembers);

    return sentOk;
  }

//*************************************************************************************//
//**************************** SEND VIEW **********************************************//
//*************************************************************************************//

  /**
    * Sends the view seen by this member to every communication channel but to this own
    * member, incrementing the viewId.
    * It keeps sending new views while there are problems sending each view, until the
    * view is rightly sent or the consensus is lost
    **/
  boolean sendView()
  {
    Trace.code("ActiveGroupMember.java -> boolean sendView ( )");
    boolean sentOk=false;

    while (!sentOk && viewHandler.consensus())
    {
      setNextViewId(true);	//produce the next view Id
      viewHandler.getView(view, true);	//members to be sent
      Trace.viewSent(view);
      sentOk = viewHandler.sendView(view, tokenState.generateNewToken());	//new token generated
    }

    //The member sending the new view doesn't go into 'Received Temporal' view,
    //but directly into Temporal.
    if (sentOk)
      viewStatus=TEMPORAL_VIEW;

    return sentOk;
  }

//*************************************************************************************//
//**************************** SEND AUTO EXCLUSION VIEW AND TOKEN *********************//
//*************************************************************************************//

  /**
    * Sends the autoexclusion view to the members. If it does not fail, it sends the token
    * Anyway, it just stops, cannot repeat any operation in case of failure
    **/
  void sendAutoExclusionViewAndToken()
  {
    Trace.code("ActiveGroupMember.java -> void sendAutoExclusionViewAndToken ( )");

    setNextViewId(true);	//produce the next view Id

    if (viewHandler.getAutoExclusionView(view)) //if returns false, there are no more members!
    {
      Trace.viewExclusionSent(view);
      if (viewHandler.sendView(view, tokenState.generateNewToken()))	//new token generated
        tokenState.sendToken();
    }
  }

//*************************************************************************************//
//**************************** IS BIGGER VIEW ID **************************************//
//*************************************************************************************//

  /**
    * returns true if the first view parameter is bigger than the second one
    **/
  boolean isBiggerViewId(InternalViewId first, InternalViewId second)
  {
    Trace.code("ActiveGroupMember.java -> boolean isBiggerViewId ( InternalViewId first , InternalViewId second )");
    if (first.id > second.id)
      return true;
    else if (first.id == second.id)
      if ((first.installing == second.installing) || (second.installing == 0))
        return false;
      else
        return (first.installing > second.installing) || (first.installing == 0);
    return false;
  }

//*************************************************************************************//
//**************************** IS VALID GROUP MEMBER **********************************//
//*************************************************************************************//

  /**
    * returns true if the member specified belongs to the view
    * @param gMember the GMS member to be checked
    **/
  boolean isValidGroupMember(int gMember)
  {
    Trace.code("ActiveGroupMember.java -> boolean isValidGroupMember ( int gMember )");
    return isValidGroup() && viewHandler.isValidMember(gMember);
  }

//*************************************************************************************//
//**************************** SET NEXT VIEW ID ***************************************//
//*************************************************************************************//

  /**
    * Modifies view.viewId to be the view after the current one.
    * If it's temporal and the current is (x,0) it's converted into (x+1,1)
    * If it's temporal and the current is (x,y!=0), it's converted into (x,y+1)
    * If it's not temporal, it must be (x,y!=0) and it's converted into (x,0)
    * @param temporal if the new view is a temporal one
    **/
  void setNextViewId(boolean temporal)
  {
    Trace.code("ActiveGroupMember.java -> void setNextViewId ( boolean temporal )");
    if (temporal)
      if (view.viewId.installing==0)
      {
        view.viewId.id++;
        view.viewId.installing=1;
      }
      else
        view.viewId.installing++;
    else
    {
      assert view.viewId.installing!=0;
      view.viewId.installing=0;
    }
  }

//*************************************************************************************//
//**************************** CHANGE VIEW STATUS *************************************//
//*************************************************************************************//

  /**
    * Change the view status after the reception of a token
    * Status can have three values: view installed, temporal view, and 'received temporal
    * view'. The two last ones mean that the view is temporal, the last value is just
    * needed to mean that any member must wait two token receptions before considering
    * installed the view
    **/
  void changeViewStatus()
  {
    Trace.code("ActiveGroupMember.java -> void changeViewStatus ( )");
    //Change the view status by the pass of the token. In this case,
    // - If the status is Received Temmporal InternalView, status changes to Temporal
    // - If it's temporal, it changes to installed, and the channels Manager must
    //		be aware of it
    // - Finally, if the view is installed, no change happens
    if (viewStatus==RECEIVED_TEMPORAL_VIEW)
      viewStatus=TEMPORAL_VIEW;
    else if (viewStatus==TEMPORAL_VIEW)
      viewInstalled();
  }

//*************************************************************************************//
//**************************** CHANGE VIEW STATUS *************************************//
//*************************************************************************************//

  /**
    * Change the view status after the reception of a message
    **/
  void changeViewStatus(MessageId messageId)
  {
    Trace.code("ActiveGroupMember.java -> void changeViewStatus ( MessageId messageId )");
    //Change the view status by the pass of the message. It only envolves the case
    // where the member is in TEMPORAL_VIEW state and the message is the first one of
    // the installed view (or just a PTP message in the next view, and then id=0)
    if (viewStatus==TEMPORAL_VIEW && messageId.view==view.viewId.id && messageId.id<=1)
      viewInstalled();
  }

//*************************************************************************************//
//**************************** CHANGE VIEW STATUS *************************************//
//*************************************************************************************//

  /**
    * Change the view status after the reception of a view
    * Status can have three values: view installed, temporal view, and 'received temporal
    * view'. The two last ones mean that the view is temporal, the last value is just
    * needed to mean that any member must wait two token receptions before considering
    * installed the view
    * @return true if the viewId received is valid
    **/
  boolean changeViewStatus(InternalViewId viewId)
  {
    Trace.code("ActiveGroupMember.java -> boolean changeViewStatus ( InternalViewId viewId )");

    boolean ret;
    //Change the status due to the reception of a view:
    // -If status is installed, it changes to 'received temporal' and it must wait
    //    to two receptions of the token to consider installed the view
    // -If status is Received Temporal, it means that another member has disagreed with
    //    the view: status remains as Received temporal
    // -If it's 'temporal', the reception can come due to a new view or just a change in
    //    the current view. That is, it must change to 'received temporal view', but
    //    it can be needed to consolidate the intermediate one
    if (viewStatus == TEMPORAL_VIEW)
    {

      //it can have been an intermediate consolidated view! This can happen if the
      //member who sent the last view received by this member considers that one as
      //installed, but before receiving again the token another member installs
      //another view
      if (viewId.id==view.viewId.id+1 && view.viewId.installing!=0)
      {
        viewInstalled();
        ret=true;
      }
      else
        ret = (viewId.id==view.viewId.id && viewId.installing>view.viewId.installing)
                    || (viewId.id==view.viewId.id+1);

      //any case, view status change to Received_temporal_view
      if (ret)
        viewStatus = RECEIVED_TEMPORAL_VIEW;
    }

    else if (viewStatus == RECEIVED_TEMPORAL_VIEW)
      ret=viewId.id==view.viewId.id && viewId.installing>view.viewId.installing;

    else //VIEW_INSTALLED
    {
      viewStatus = RECEIVED_TEMPORAL_VIEW;
      ret=viewId.id==(view.viewId.id+1);
    }

    return ret;
  }

//*************************************************************************************//
//**************************** VIEW INSTALLED *****************************************//
//*************************************************************************************//

  /**
    * To be called when a view is considered installed
    **/
  void viewInstalled()
  {
    Trace.code("ActiveGroupMember.java -> void viewInstalled ( )");
    if (!memberAccepted)
    {
      synchronized(this)
      {
        memberAccepted=true;
        notifyAll();
      }
    }
    viewStatus=VIEW_INSTALLED;

    setNextViewId(false);	//produce new view id, no temporal
    messageCenter.newView(view, viewHandler.getExcludedMembers());
    viewHandler.consolidateView();

    tokenRecoverer.communicationReceived(view); //bug.version 0.90
    Trace.viewInstalled (view, thisMemberId);
  }

//*************************************************************************************//
//**************************** CONSENSUS LOST *****************************************//
//*************************************************************************************//

  /**
    * Cleaning to perform if the consensus is lost
    **/
  void consensusLost()
  {
    Trace.code("ActiveGroupMember.java -> void consensusLost ( )");
    doLeaveGroup();
  }

//*************************************************************************************//
//**************************** START GROUP ACTIVITIES *********************************//
//*************************************************************************************//

  /**
    * Start the activities of the member, which creates a new group (if initialToken)
    * is null, or joins other.
    * @param initialView the first view seen by the member
    * @param initialToken the initial token (can be null if the group is being created)
    * @returns true if the activities can be started (can only fail when joining groups)
    **/
  boolean startGroupActivities(InternalView initialView, Token initialToken)
  {
    Trace.code("ActiveGroupMember.java -> boolean startGroupActivities ( InternalView initialView , Token initialToken )");
    boolean started = false;
    synchronized (this)
    {
      started = !leaving && (viewStatus == MEMBER_NOT_IN_VIEW);
      if (started)
      {
        view                		  = new InternalView(
                                      new InternalViewId(initialView.viewId.id, initialView.viewId.installing),
                                      initialView.members,
                                      initialView.memberIds,
                                      initialView.newMembers
                                    );
        memberRecoveringToken			=	Consts.INVALID_MEMBER_ID;
        viewStatus								= RECEIVED_TEMPORAL_VIEW;
        memberAccepted						= false;

        restartableThread 				= new RestartableThread(this);
        viewHandler			 					= new ViewHandler(thisFTDAGMSMember, initialView);
        thisMemberId              = viewHandler.getMyId();
        tokenState								= new TokenState(thisMemberId, viewHandler, initialToken);
        eventsDispatcher					= new GroupEventsDispatcher(thisMemberId, thisFTDAGMSMember, groupMember);
        messageCenter							= new MessageCenter(eventsDispatcher);
        joiningMembers						=	new JoiningMembersHandler ();
        tokenRecoverer						= new TokenRecoverer(this, thisFTDAGMSMember, initialView);
        tokenControl              = new TokenPassControl();

        Trace.viewReceived(view);
        Trace.viewAccepted(view, thisMemberId);
      }
    }
    return started;
  }

//*************************************************************************************//
//**************************** DATA MEMBERS *******************************************//
//*************************************************************************************//

  FTDAGMSMember thisFTDAGMSMember=null;
  int thisMemberId;
  InternalView view=null;														//current view

  ViewHandler viewHandler=null;	//manager of channels
  MessageCenter messageCenter=null;									//to handle the messages
  JoiningMembersHandler joiningMembers=null;				//to handle joining members
  TokenRecoverer tokenRecoverer=null;								//to handle tokens lost
  TokenPassControl tokenControl=null;								//to handle the pass of the token
  TokenState tokenState=null;												//keeps the token state

  boolean memberAccepted=false;											//true when a view has been totally installed

  int memberRecoveringToken=Consts.INVALID_MEMBER_ID;				//member recovering the token
  int memberAutoExcluding=Consts.INVALID_MEMBER_ID;				//member excluding to himself
  GroupEventsDispatcher eventsDispatcher=null;			//object dispatching the events to the consumer

  GroupMember groupMember;
  RestartableThread restartableThread=null;

  int viewStatus=MEMBER_NOT_IN_VIEW;
  static final int VIEW_INSTALLED 				= 0;
  static final int TEMPORAL_VIEW 					= 1;
  static final int RECEIVED_TEMPORAL_VIEW = 2;
  static final int MEMBER_NOT_IN_VIEW 		= 3;
  static final int MEMBER_EXPULSED    		= 4;

  boolean leaving=false;
}
