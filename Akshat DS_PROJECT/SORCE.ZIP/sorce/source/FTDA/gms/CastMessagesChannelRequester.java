package FTDA.gms;

import FTDA.middleware.gms.Message;
import FTDA.middleware.gms.MessageId;
import FTDA.middleware.gms.FTDAGMSMember;


//*************************************************************************************//
//**************************** CAST MESSAGES CHANNEL REQUESTER ************************//
//*************************************************************************************//

/**
  * Channel Requester used to cast messages
  **/
class CastMessagesChannelRequester implements ChannelRequester
{

  public CastMessagesChannelRequester(int thisMember)
  {
    Trace.code("CastMessagesChannelRequester.java -> CastMessagesChannelRequester ( int thisMember )");
    this.thisMember 	= thisMember;
    messages					=	null;
    messageId 				= null;
  }

  public void setMessagesToSend(Message[] messages, MessageId messageId)
  {
    Trace.code("CastMessagesChannelRequester.java -> void setMessagesToSend ( Message [ ] messages , MessageId messageId )");
    this.messages  = messages;
    this.messageId = messageId;
  }

  public boolean invokeMember(CommunicationChannel channel)
  {
    Trace.code("CastMessagesChannelRequester.java -> boolean invokeMember ( CommunicationChannel channel )");
    assert messages !=null && messageId!=null && channel!=null;

    boolean ret;

    FTDAGMSMember channelMember = channel.getLink();

    assert channelMember!=null;

    try
    {
      ret=channelMember.receiveMessages(thisMember, messages, messageId) && channel.isReliable();
    }
    catch(Exception ex)
    {
      ret=false;
      Trace.handledException(ex);
    }
    return ret;
  }

  int 				thisMember;
  Message[]		messages;
  MessageId		messageId;
}
