*
package FTDA.gms;

import FTDA.middleware.gms.GroupHandler;
import FTDA.middleware.gms.GroupMember;
import FTDA.middleware.gms.InternalView;
import FTDA.middleware.gms.Message;
import FTDA.middleware.gms.View;

import FTDA.util.Error;

class GroupEventsDispatcher
{

  //*************************************************************************************//
  //**************************** CONSTRUCTOR ********************************************//
  //*************************************************************************************//

  /**
    * The GroupEventsDispatcher must know the consumer that will receive the events
    * It's also needed the identity of this member
    **/
  public GroupEventsDispatcher(int thisMember, GroupHandler theHandler, GroupMember groupMember)
  {
    Trace.code("GroupEventsDispatcher.java -> GroupEventsDispatcher ( int thisMember , GroupHandler theHandler , GroupMember groupMember )");
    this.eventConsumer	=	groupMember;
    this.thisMember     = thisMember;
    this.theHandler     = theHandler;
    firstViewAlreadyDispatched = false;
    validApplication=true;
    onOperation=false;
    lastOperationTimed=0;
  }

  //*************************************************************************************//
  //**************************** STOP DISPATCHING ***************************************//
  //*************************************************************************************//

  /**
    * Stops the dispatching.
    * Releases any kept resources (like monitors and the thread itself)
    **/
  public void stopDispatching()
  {
    Trace.code("GroupEventsDispatcher.java -> void stopDispatching ( )");
    synchronized(this)
    {
      try
      {
        if (firstViewAlreadyDispatched)
          if (eventConsumer!=null)
          {
            Trace.memberExitGroup();
            eventConsumer.excludedFromGroup();
          }
      }
      catch(Exception ex)
      {
        Error.unhandledException(Consts.GMS, ex);
      }
      finally
      {
        Trace.releaseObject("GroupEventDispatcher");
        eventConsumer = null;
        theHandler    = null;
      }
    }
  }

  //*************************************************************************************//
  //**************************** IS SLOW OR STOPPED *************************************//
  //*************************************************************************************//

  /**
    * Returns true if the dispatching has stopped or is too slow
    **/
  public boolean isSlowOrStopped()
  {
    Trace.code("GroupEventsDispatcher.java -> boolean isSlowOrStopped ( )");
    boolean ret=false;
    if (eventConsumer==null)
      ret=true;
    else if (onOperation)
    {
      long currentTime = System.currentTimeMillis();
      if (lastOperationTimed==0)
        lastOperationTimed = currentTime;
      else if ((currentTime - lastOperationTimed) > Consts.TIMEOUT)
      {
        ret=onOperation;
        validApplication=!ret;
      }
    }
    return ret;
  }

  //*************************************************************************************//
  //**************************** DISPATCH CAST MESSAGES *********************************//
  //*************************************************************************************//

  /**
    * Dispatch synchronously the messages to the registered consumer
    * @param messages The messages to dispatch
    * @returns true if the messages can be dispatched.
    **/
  public synchronized boolean dispatchCastMessages(int sender, Message[] messages)
  {
    Trace.code("GroupEventsDispatcher.java -> synchronized boolean dispatchCastMessages ( int sender , Message [ ] messages )");
    GroupMember target = eventConsumer;
    boolean ret=target!=null && sendingEvent();
    if (ret)
    {
      try
      {
        int l=messages.length;
        for(int i=0;i<l;i++)
          eventConsumer.processCastMessage(sender, messages[i]);
        eventSent();
      }
      catch(Exception ex)
      {
        ret=false;
        Error.unhandledException(Consts.GMS, ex);
      }
    }
    return ret;
  }

  //*************************************************************************************//
  //**************************** DISPATCH PTP MESSAGE ***********************************//
  //*************************************************************************************//

  /**
    * Dispatch synchronously the messages to the registered consumer
    * @param messages The messages to dispatch
    * @returns true if the messages can be dispatched.
    **/
  public synchronized boolean dispatchPTPMessages(int sender, Message[] messages)
  {
    Trace.code("GroupEventsDispatcher.java -> synchronized boolean dispatchPTPMessages ( int sender , Message [ ] messages )");
    GroupMember target = eventConsumer;
    boolean ret=target!=null && sendingEvent();
    if (ret)
    {
      try
      {
        int l=messages.length;
        for(int i=0;i<l;i++)
          eventConsumer.processPTPMessage(sender, messages[i]);
        eventSent();
      }
      catch(Exception ex)
      {
        ret=false;
        Error.unhandledException(Consts.GMS, ex);
      }
    }
    return ret;
  }

  //*************************************************************************************//
  //**************************** DISPATCH VIEW ******************************************//
  //*************************************************************************************//

  /**
    * Dispatch synchronously the view to the registered consumer.
    * @param view The view to dispatch
    * @return true if the view can be dispatched
    **/
  public synchronized boolean dispatchView(InternalView view, int leavingMembers[])
  {
    Trace.code("GroupEventsDispatcher.java -> synchronized boolean dispatchView ( InternalView view , int leavingMembers [ ] )");
    GroupMember target = eventConsumer;
    boolean ret=target!=null && sendingEvent();
    if (ret)
    {
      try
      {
        View publicView = new View(view.viewId.id, view.memberIds, view.newMembers, leavingMembers);
        if (firstViewAlreadyDispatched)
          eventConsumer.installView(publicView);
        else
        {
          firstViewAlreadyDispatched=true;
          eventConsumer.memberAccepted(thisMember, theHandler, publicView);
        }
        eventSent();
      }
      catch(Exception ex)
      {
        ret=false;
        Error.unhandledException(Consts.GMS, ex);
      }
    }
    return ret;
  }

  //*************************************************************************************//
  //**************************** DISPATCH CHANGE VIEW EVENT *****************************//
  //*************************************************************************************//

  /**
    * Dispatch synchronously the event of the view change to the registered consumer.
    * @return true if the event can be dispatched
    **/
  public synchronized boolean dispatchChangeViewEvent()
  {
    Trace.code("GroupEventsDispatcher.java -> synchronized boolean dispatchChangeViewEvent ( )");
    GroupMember target = eventConsumer;
    boolean ret=target!=null && sendingEvent();
    if (ret)
    {
      try
      {
        Trace.changingViewEventSent();
        eventConsumer.changingView();
        eventSent();
      }
      catch(Exception ex)
      {
        ret=false;
        Error.unhandledException(Consts.GMS, ex);
      }
    }
    return ret;
  }

  //*************************************************************************************//
  //**************************** SENDING EVENT / EVENT SENT *****************************//
  //*************************************************************************************//

  boolean sendingEvent()
  {
    Trace.code("GroupEventsDispatcher.java -> boolean sendingEvent ( )");
    onOperation = validApplication;
    return validApplication;
  }

  void eventSent()
  {
    Trace.code("GroupEventsDispatcher.java -> void eventSent ( )");
    onOperation = false;
    lastOperationTimed = 0;
  }

  //*************************************************************************************//
  //**************************** DATA MEMBERS *******************************************//
  //*************************************************************************************//

  GroupMember eventConsumer;			//member receiving the events
  int thisMember;
  GroupHandler theHandler;
  boolean firstViewAlreadyDispatched;
  boolean onOperation;
  long lastOperationTimed;
  boolean validApplication;
}
