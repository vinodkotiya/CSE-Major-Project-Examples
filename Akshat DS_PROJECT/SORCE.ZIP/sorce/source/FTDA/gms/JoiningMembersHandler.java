package FTDA.gms;

import FTDA.middleware.gms.FTDAGMSMember;


import java.util.Arrays;
import java.util.HashSet;

/**
  * class handling exclusively the members wishing to join a specific member
  **/
class JoiningMembersHandler
{

//*************************************************************************************//
//**************************** CONSTRUCTOR ********************************************//
//*************************************************************************************//

  public JoiningMembersHandler()
  {
    Trace.code("JoiningMembersHandler.java -> JoiningMembersHandler ( )");
    newMembers 	= new HashSet();
  }


//*************************************************************************************//
//**************************** FREE RESOURCES *****************************************//
//*************************************************************************************//

  public synchronized void freeResources()
  {
    Trace.code("JoiningMembersHandler.java -> synchronized void freeResources ( )");
    if (newMembers!=null)
    {
      newMembers.clear();
      newMembers 	= null;
      notifyAll();
      Trace.releaseObject("JoiningMembersHandler");
    }
  }


//*************************************************************************************//
//**************************** ADD MEMBER *********************************************//
//*************************************************************************************//

  /**
    * Include other member in the list to be joined. It only returns after trying to
    * join the group or when this coordinator falls down. In the last case, it returns
    * false, otherwise it returns true, but the caller must verify if the object has
    * joined succesfully the group or not
    * @param groupMember The member to include
    * @returns false if this member falls down
    **/
  public synchronized boolean addMember(FTDAGMSMember other)
  {
    Trace.code("JoiningMembersHandler.java -> synchronized boolean addMember ( FTDAGMSMember other )");
    assert newMembers!=null;

    boolean ret=newMembers!=null;
    if (ret)
    {
      newMembers.add(other);
      while(newMembers.contains(other))
        try
        {
          wait();
          if (newMembers==null)	//task could have finished by calling freeResources
          {
            ret=false;
            break;
          }
        }
        catch(Exception ex)
        {
          ret=false;
          Trace.handledException(ex);
          break;
        }
    }
    return ret;
  }

//*************************************************************************************//
//**************************** REMOVE MEMBERS *****************************************//
//*************************************************************************************//

  /**
    * Removes a list of members; the matching calls to add member are unblocked
    * @param members The members to remove
    **/
  public synchronized void removeMembers(FTDAGMSMember[] members)
  {
    Trace.code("JoiningMembersHandler.java -> synchronized void removeMembers ( FTDAGMSMember [ ] members )");
    assert newMembers!=null;

    newMembers.removeAll(Arrays.asList(members));
    notifyAll();
  }

//*************************************************************************************//
//**************************** GET MEMBERS ********************************************//
//*************************************************************************************//

  /**
    * Returns the members in the list, or null if there are no members waiting to join
    * @returns the members waiting to join
    **/
  public synchronized FTDAGMSMember[] getMembers()
  {
    Trace.code("JoiningMembersHandler.java -> synchronized FTDAGMSMember [ ] getMembers ( )");
    assert newMembers!=null;

    FTDAGMSMember[] ret = null;
    if (!newMembers.isEmpty())
    {
      ret = new FTDAGMSMember [newMembers.size()];
      newMembers.toArray(ret);
    }
    return ret;
  }


//*************************************************************************************//
//**************************** DATA MEMBERS *******************************************//
//*************************************************************************************//

  HashSet newMembers; //of FTDAGMSMembers
}
