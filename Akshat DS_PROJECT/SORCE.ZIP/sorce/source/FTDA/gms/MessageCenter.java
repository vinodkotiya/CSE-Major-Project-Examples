package FTDA.gms;

import FTDA.middleware.gms.InternalView;
import FTDA.middleware.gms.InternalViewId;
import FTDA.middleware.gms.Message;
import FTDA.middleware.gms.MessageId;


import java.util.LinkedList;

/**
  * MessageCenter is the main class to deal with the messages reception and dispatching.
  *			It features the interaction object between GroupMemberImpl and ActiveGroupMember
  *			(to make looser their coupling) and it's also the interface to the 'external world'.
  **/
class MessageCenter
{

//*************************************************************************************//
//**************************** CONSTRUCTOR ********************************************//
//*************************************************************************************//

  /**
    * The MessageCenter must know the FTDAGMSMember that will receive the events
    **/
  public MessageCenter(GroupEventsDispatcher eventDispatcher)
  {
    Trace.code("MessageCenter.java -> MessageCenter ( GroupEventsDispatcher eventDispatcher )");
    messagesQueue								= new LinkedList();
    messagesToFlush							=	new LinkedList();
    temporalList                = new LinkedList();
    installingView							=	true;
    lastMessageIdProcessed			=	new MessageId(0,0);
    lastMessageIdNotConfirmed		= new MessageId(0,0);
    messagesNotConfirmed				=	null;
    messagesSender              = 0;
    confirmingMember						=	0;
    canDropUnconfirmedMessages	=	false;
    lastConfirmationWasExplicit	= false;
    this.eventDispatcher				= eventDispatcher;
  }

//*************************************************************************************//
//**************************** FREE RESOURCES *****************************************//
//*************************************************************************************//

  /**
    * Releases any resources associated to this object
    **/
  public void freeResources()
  {
    Trace.code("MessageCenter.java -> void freeResources ( )");
    if (isValidMessageCenter())
    {
      messagesQueue.clear();
      messagesToFlush.clear();
      temporalList.clear();
      eventDispatcher.stopDispatching();

      messagesQueue								= null;
      messagesToFlush							=	null;
      temporalList                = null;
      lastMessageIdProcessed			=	null;
      lastMessageIdNotConfirmed		= null;
      messagesNotConfirmed				=	null;
      eventDispatcher							= null;

      Trace.releaseObject("MessageCenter");
    }
  }

//*************************************************************************************//
//**************************** IS SLOW OR STOPPED *************************************//
//*************************************************************************************//

  /**
    * Returns true if the dispatching has stopped or is too slow
    **/
  public boolean isSlowOrStopped()
  {
    Trace.code("MessageCenter.java -> boolean isSlowOrStopped ( )");
    return eventDispatcher.isSlowOrStopped();
  }

//*************************************************************************************//
//**************************** SEND MESSAGE *******************************************//
//*************************************************************************************//

  /**
    * Sends the message (it will be received as well). The message will be sent
    * into the specified member. It returns true if the message is sent in this view.
    * @param target The FTDAGMSMember to receive the message
    * @param message The message to be sent
    * @returns true if the message is sent on the current view
    **/
  public synchronized boolean sendMessage(int target, Message message)
  {
    Trace.code("MessageCenter.java -> synchronized boolean sendMessage ( int target , Message message )");
    if (isValidMessageCenter())
    {
      messagesQueue.add(new PTPMessage(target, message));
      return !(installingView || eventDispatcher.isSlowOrStopped());
    }
    return false;
  }

//*************************************************************************************//
//**************************** CAST MESSAGE *******************************************//
//*************************************************************************************//

  /**
    * Cast the message (it will be received as well). The message will be sent
    * into the group. It returns true if the message is sent in this view.
    * @param message The message to be sent
    * @returns true if the message is sent on the current view
    **/
  public synchronized boolean castMessage(Message message)
  {
    Trace.code("MessageCenter.java -> synchronized boolean castMessage ( Message message )");
    if (isValidMessageCenter())
    {
      assert message!=null;
      messagesQueue.add(message);
      return !(installingView || eventDispatcher.isSlowOrStopped());
    }
    return false;
  }

//*************************************************************************************//
//**************************** NEW VIEW ***********************************************//
//*************************************************************************************//

  /**
    * Notifies to the message center that a new view is installed.
    * @returns true if the view can be delivered. A false value means that
    *   the GroupEventsDispatcher cannot handle any more events
    **/
  public boolean newView(InternalView view, int faultyMembers[])
  {
    Trace.code("MessageCenter.java -> boolean newView ( InternalView view , int faultyMembers [ ] )");
    assert isValidMessageCenter();

    assert installingView;
    assert messagesToFlush.size()==0;

    boolean toCheck = messagesNotConfirmed==null || dropUnconfirmedMessages();

    assert toCheck;

    synchronized (this)
    {
      installingView = false;
    }

    acceptMessageId (view.viewId);
    canDropUnconfirmedMessages	= false;
    messagesNotConfirmed        = null;

    //dispatch the view
    return eventDispatcher.dispatchView(view, faultyMembers);
  }

//*************************************************************************************//
//**************************** IN TEMPORAL VIEW ***************************************//
//*************************************************************************************//

  /**
    * Notifies to the message center that the view is going to change
    **/
  public boolean newTemporalView(int installer)
  {
    Trace.code("MessageCenter.java -> boolean newTemporalView ( int installer )");
    assert isValidMessageCenter();

    canDropUnconfirmedMessages		= true;
    confirmingMember							= installer;
    if (!installingView)
    {
      synchronized(this)
      {
        assert messagesToFlush.size()==0;
        LinkedList temp             = messagesQueue;
        messagesQueue               = messagesToFlush;
        messagesToFlush 						= temp;
        temp												= null;
        installingView 							= true;
      }
      eventDispatcher.dispatchChangeViewEvent();
    }
    return !eventDispatcher.isSlowOrStopped();
  }

//*************************************************************************************//
//**************************** MESSAGE PTP RECEIVED ***********************************//
//*************************************************************************************//

  /**
    * Notifies the messageCenter that a point to point message has been received.
    * @param sender The FTDAGMSMember sending the message
    * @param messages The messages received
    * @returns true if the message can be accepted and delivered
    **/
  public boolean messagesPTPReceived(int sender, Message[] messages)
  {
    Trace.code("MessageCenter.java -> boolean messagesPTPReceived ( int sender , Message [ ] messages )");
    assert isValidMessageCenter();

    boolean ret=true;

    //if there are messages to confirm, they should be first confirmed.
    //This is only the case when the member sending this message is the same that
    //sent the previous messages. Otherwise, there must have been a view excluding
    //the previous message.
    if (messagesNotConfirmed != null)
      if (sender==messagesSender)
        ret=confirmMessages(false);
      else
        ret=dropUnconfirmedMessages();

    //point to point messages are directly dispatched
    if (ret)
      ret=eventDispatcher.dispatchPTPMessages(sender, messages);

    return ret;
  }

//*************************************************************************************//
//**************************** MESSAGES RECEIVED **************************************//
//*************************************************************************************//

  /**
    * Notifies the messageCenter that a group of messages has been received.
    * @param sender The FTDAGMSMember sending the messages
    * @param messages The messages received
    * @param messageId message's messageId
    * @returns true if the messages can be accepted (right messageId) and the event dispatcher
	  *                                                    	is working properly
    **/
  public boolean messagesReceived(int sender, Message[] messages, MessageId messageId)
  {
    Trace.code("MessageCenter.java -> boolean messagesReceived ( int sender , Message [ ] messages , MessageId messageId )");
    boolean ret = true;

    //if there are messages not confirmed, several cases are possible:
    //1- these messages are coming from the same member, and the previous must be first confirmed.
    //		The messageId must be the previous one + 1 (same view)
    //2- these messages are coming from a different member. A new view must have been installed on
    //    the meanwhile, excluding the previous one. The messageId is the same or it's the first on
    //    a new view
    //If messages are confirmed, this messageId must follow the previous one.
    if (messagesNotConfirmed == null)
      ret = isNextMessageId(messageId, lastMessageIdProcessed);
    else
    {
      if (sender==messagesSender)
      {
        if (isNextMessageId(messageId, lastMessageIdNotConfirmed))
          ret = confirmMessages(false);
        else
          ret = false;
      }
      else
        ret	=	isSameMessageId(messageId, lastMessageIdNotConfirmed) && dropUnconfirmedMessages();
    }

    if (ret)
    {
      lastMessageIdNotConfirmed.id    = messageId.id;
      lastMessageIdNotConfirmed.view  = messageId.view;
      canDropUnconfirmedMessages			= false;
      confirmingMember								= sender;
      messagesSender              		= sender;
      messagesNotConfirmed 						= messages;
    }
    return ret && !eventDispatcher.isSlowOrStopped();
  }

//*************************************************************************************//
//**************************** MESSAGES CONFIRMED *************************************//
//*************************************************************************************//

  /**
    * Notifies the messageCenter that a message already received can be processed
    * @param sender The FTDAGMSMember confirming the messages
    * @param messageId message's messageId
    * @returns true if the message can be accepted (right messageId) and delivered
    **/
  public boolean messagesConfirmed(int sender, MessageId messageId)
  {
    Trace.code("MessageCenter.java -> boolean messagesConfirmed ( int sender , MessageId messageId )");

    //confirmation is accepted if it comes from a valid confirming member and,
    // is the confirmation to a received message or the reconfirmation of a just
    // confirmed message (it's allowed to reconfirm a message if it has been
    // installed a new temporal view or they have been unexplicitely confirmed with a PTP messages)
    boolean ret = sender==confirmingMember;
    if (ret)
      if (messagesNotConfirmed == null)
      {
        if (isSameMessageId(messageId, lastMessageIdProcessed) && (canDropUnconfirmedMessages || !lastConfirmationWasExplicit))
        {
          canDropUnconfirmedMessages = false;
          lastConfirmationWasExplicit= true;
        }
        else
          ret = false;
      }
      else
      {
        if (isSameMessageId(messageId, lastMessageIdNotConfirmed))
          ret=confirmMessages(true);
        else
          ret=false;
      }
    return ret && !eventDispatcher.isSlowOrStopped();
  }

//*************************************************************************************//
//**************************** GET NEXT MESSAGE ID ************************************//
//*************************************************************************************//

  /**
    * Returns the next MessageId
    **/
  public MessageId getNextMessageId()
  {
    Trace.code("MessageCenter.java -> MessageId getNextMessageId ( )");
    assert isValidMessageCenter();

    return new MessageId(lastMessageIdProcessed.view,lastMessageIdProcessed.id+1);
  }

//*************************************************************************************//
//**************************** GET PTP MESSAGE ID *************************************//
//*************************************************************************************//

  /**
    * Returns a valid PTP MessageId (right view Id, null messageId)
    **/
  public MessageId getPTPMessageId()
  {
    Trace.code("MessageCenter.java -> MessageId getPTPMessageId ( )");
    assert isValidMessageCenter();

    return new MessageId(lastMessageIdProcessed.view,0);
  }

//*************************************************************************************//
//**************************** GET LAST MESSAGE ID PROCESSED **************************//
//*************************************************************************************//

  /**
    * Returns the last MessageId processed
    **/
  public MessageId getLastMessageIdProcessed()
  {
    Trace.code("MessageCenter.java -> MessageId getLastMessageIdProcessed ( )");
    assert isValidMessageCenter();

    return new MessageId(lastMessageIdProcessed.view,lastMessageIdProcessed.id);
  }

//*************************************************************************************//
//**************************** HAS MESSAGES TO SEND ***********************************//
//*************************************************************************************//

  /**
    * Returns true if there are messages to send
    **/
  public synchronized boolean hasMessagesToSend()
  {
    Trace.code("MessageCenter.java -> boolean hasMessagesToSend ( )");
    return rightMessageList().size()>0;
  }

//*************************************************************************************//
//**************************** GET MESSAGES TARGET ************************************//
//*************************************************************************************//

  /**
    * Returns the target of the next message[s], or EVERY_MEMBER_ID if it's a cast message.
    * It's an error if there are no messages to send
    **/
  public synchronized int getMessagesTarget()
  {
    Trace.code("MessageCenter.java -> int getMessagesTarget ( )");
    assert hasMessagesToSend();

    int ret;
    Object next = rightMessageList().getFirst();

    assert next!=null;

    if (next instanceof Message)
      ret = Consts.EVERY_MEMBER_ID;
    else
      ret = ((PTPMessage) next).member;

    return ret;
  }

//*************************************************************************************//
//**************************** GET MESSAGES TO SEND ***********************************//
//*************************************************************************************//

  /**
    * Returns the messages stored to be sent. They're removed, that is,
    * a second call to this method won't return the same messages. It's an error if there
    * are no messages to send
    **/
  public synchronized Message[] getMessagesToSend()
  {
    Trace.code("MessageCenter.java -> Message [ ] getMessagesToSend ( )");
    assert isValidMessageCenter();
    assert hasMessagesToSend();
    assert temporalList.size()==0;

    //messages will be inserted into a temporal list, and then retrieved to the caller

    LinkedList messagesList = rightMessageList();

    int target  = getMessagesTarget();
    int current = target;
    boolean cast = (target == Consts.EVERY_MEMBER_ID);

    do
    {
      Message message;
      Object next = messagesList.removeFirst();
      if (cast)
        message = (Message)(next);
      else
        message = ((PTPMessage)next).message;

      temporalList.add(message);

      if (hasMessagesToSend())
        current = getMessagesTarget();
      else
        break;
    }
    while ((cast && current==Consts.EVERY_MEMBER_ID) || (!cast && target==current));

    Message[] ret = new Message[temporalList.size()];
    temporalList.toArray(ret);
    temporalList.clear();

    return ret;
  }

//*************************************************************************************//
//**************************** IS NEXT MESSAGE ID *************************************//
//*************************************************************************************//

  /**
    * Returns true if the messageId follows the specified one.
    **/
  boolean isNextMessageId(MessageId messageId, MessageId related)
  {
    Trace.code("MessageCenter.java -> boolean isNextMessageId ( MessageId messageId , MessageId related )");
    assert isValidMessageCenter();

    return  	(related.view == 0)
            ||
              (
                ((messageId.view == related.view) && 	(messageId.id 	== related.id+1))
              );
  }

//*************************************************************************************//
//**************************** IS SAME MESSAGE ID ***************************//
//*************************************************************************************//

  /**
    * Returns true if both messageIds match
    **/
  boolean isSameMessageId(MessageId left, MessageId right)
  {
    Trace.code("MessageCenter.java -> boolean isSameMessageId ( MessageId left , MessageId right )");
    assert left!=null;
    assert right!=null;

    return left.view == right.view && left.id == right.id;
  }

//*************************************************************************************//
//**************************** ACCEPT MESSAGE ID **************************************//
//*************************************************************************************//

  /**
    * Changes lastMessageIdProcessed
    **/
  void acceptMessageId(MessageId messageId)
  {
    Trace.code("MessageCenter.java -> void acceptMessageId ( MessageId messageId )");
    assert isValidMessageCenter();

    lastMessageIdProcessed.view 	= messageId.view;
    lastMessageIdProcessed.id 		= messageId.id;
  }

//*************************************************************************************//
//**************************** ACCEPT MESSAGE ID **************************************//
//*************************************************************************************//

  /**
    * Changes lastMessageIdProcessed
    **/
  void acceptMessageId(InternalViewId viewId)
  {
    Trace.code("MessageCenter.java -> void acceptMessageId ( InternalViewId viewId )");
    assert viewId!=null;
    assert isValidMessageCenter();

    lastMessageIdProcessed.view 	= viewId.id;
    lastMessageIdProcessed.id 		= 0;
  }

//*************************************************************************************//
//**************************** CONFIRM MESSAGES ***************************************//
//*************************************************************************************//

  /**
    * Confirm that the unconfirmed messages can be processed
    * @param explicitConfirmation set to true if messages are being confirmed explicitely
    * @return false if the GroupEventsDispatcher cannnot send them
    **/
  boolean confirmMessages(boolean explicitConfirmation)
  {
    Trace.code("MessageCenter.java -> boolean confirmMessages ( boolean explicitConfirmation )");
    assert isValidMessageCenter();

    acceptMessageId(lastMessageIdNotConfirmed);
    canDropUnconfirmedMessages	= false;

    boolean ret = eventDispatcher.dispatchCastMessages(messagesSender, messagesNotConfirmed);

    messagesNotConfirmed 				= null;
    lastConfirmationWasExplicit	= explicitConfirmation;

    return ret;
  }

//*************************************************************************************//
//**************************** DROP UNCONFIRMED MESSAGES ******************************//
//*************************************************************************************//

  /**
    * Verifies if messages unconfirmed can be dropped and, if so, they considered dropped
    **/
  boolean dropUnconfirmedMessages()
  {
    Trace.code("MessageCenter.java -> boolean dropUnconfirmedMessages ( )");
    boolean ret =	canDropUnconfirmedMessages;

    if (ret)
    {
      messagesNotConfirmed 				= null;
      canDropUnconfirmedMessages	= false;
    }

    return ret;
  }

//*************************************************************************************//
//**************************** RIGHT MESSAGE LIST *************************************//
//*************************************************************************************//

  /**
    * Returns the message list containing the messages to send
    **/
  LinkedList rightMessageList()
  {
    Trace.code("MessageCenter.java -> LinkedList rightMessageList ( )");
    assert isValidMessageCenter();

    return installingView? messagesToFlush : messagesQueue;
  }

//*************************************************************************************//
//**************************** IS VALID MESSAGE CENTER ********************************//
//*************************************************************************************//

  /**
    * Checks that this object is still valid (free Resources not called)
    **/
  boolean isValidMessageCenter()
  {
    Trace.code("MessageCenter.java -> boolean isValidMessageCenter ( )");
    return eventDispatcher!=null;
  }

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//++++++++++++++++++++++++++++ PTP MESSAGE  +++++++++++++++++++++++++++++++++++++++++++//
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//

  /**
    * Inner class, just a simple struct
    **/
  class PTPMessage
  {
    public PTPMessage(int gm, Message m) {member = gm; message = m;}
    public int member;
    public Message     message;
  }

//*************************************************************************************//
//**************************** DATA MEMBERS *******************************************//
//*************************************************************************************//

  //messages contains the messages to be sent on the present view; if a temporal view is
  //installed, the messages to be sent before the view is really installed are stored in
  //messagesToFlush instead of here
  LinkedList messagesQueue; //of PTPMessages

  //When a view is temporarily installed, messages still not sent are transferred to this
  //object from the list 'messages'. These messages must be delivered before the view is
  //really installed
  LinkedList messagesToFlush;

  //This object is used on getMessagesToSend; it's declared at class level to avoid its
  //creation each time that the method is used.
  LinkedList temporalList;

  //While a view is being installed, since the event 'new temporal view' until the even
  //'view installed', this variable must be set to true
  boolean installingView;

  //Next variable contains the identity of the last message id succesfully processed
  MessageId lastMessageIdProcessed;

  //This variable contains the identity of the last message received and not yet confirmed.
  //If there are no such messages, this variable contains nonsense values!
  MessageId lastMessageIdNotConfirmed;//last message received

  //Messages received but not confirmed are stored temporarily in this variable, which is
  //null if there are not unconfirmed messages
  Message[]	 messagesNotConfirmed;

  //confirmingMember contains the identity of the member which can confirm messages. This
  //member is usually the member who sent them, but can change if it falls down. In this
  //case, another member must install a temporal view, and it's this member which can
  //confirm those messages.
  int confirmingMember;

  //messagesSender contains the identity of the member who has sent the messages not yet
  //confirmed
  int messagesSender;

  //Once that a group of messages have been received, they must be confirmed. This can be
  //not the case if a new view (temporay one) is installed, as therefore it can be needed
  //to drop the messages, if no member has confirmed them.
  boolean canDropUnconfirmedMessages;

  //messages can be confirmed explicitely or when a member sends a new group of messages
  //next variable is set to true only when the last messages were explicitely confirmed
  boolean lastConfirmationWasExplicit;

  GroupEventsDispatcher eventDispatcher;
}
