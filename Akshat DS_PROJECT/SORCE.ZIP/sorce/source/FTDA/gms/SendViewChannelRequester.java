package FTDA.gms;

import FTDA.middleware.gms.InternalView;
import FTDA.middleware.gms.InternalViewId;
import FTDA.middleware.gms.FTDAGMSMember;
import FTDA.middleware.gms.Token;


//*************************************************************************************//
//**************************** SEND VIEW CHANNEL REQUESTER ****************************//
//*************************************************************************************//

/**
  * Channel Requester used to send views
  **/
class SendViewChannelRequester implements ChannelRequester
{

  public SendViewChannelRequester(int thisMember)
  {
    Trace.code("SendViewChannelRequester.java -> SendViewChannelRequester ( int thisMember )");
    this.thisMember = thisMember;
  }

  public void setInfoToSend(InternalView view, Token token)
  {
    Trace.code("SendViewChannelRequester.java -> void setInfoToSend ( InternalView view , Token token )");
    this.view = view;
    this.token = token;
  }

  public boolean invokeMember(CommunicationChannel channel)
  {
    Trace.code("SendViewChannelRequester.java -> boolean invokeMember ( CommunicationChannel channel )");
    assert view!=null && token!=null && channel!=null;
    boolean ret;

    FTDAGMSMember channelMember = channel.getLink();

    assert channelMember!=null;

    try
    {
      ret=channelMember.receiveView(thisMember, view, token) && channel.isReliable();
    }
    catch(Exception ex)
    {
      ret=false;
      Trace.handledException(ex);
    }
    return ret;
  }

  int thisMember;
  Token token;
  InternalView view;
}
