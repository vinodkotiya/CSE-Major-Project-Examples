package FTDA.gms;

import FTDA.middleware.gms.InternalView;
import FTDA.middleware.gms.InternalViewId;
import FTDA.middleware.gms.Message;
import FTDA.middleware.gms.MessageId;
import FTDA.middleware.gms.FTDAGMSMember;
import FTDA.middleware.gms.Token;

import FTDA.util.Error;

import java.util.Random;

/**
  * CommunicationChannelsManager specifying tasks to perform by an
  * ViewHandler; defines therefore the CommunicationChannelsManager
  * used actively.
  **/
class ViewHandler extends CommunicationChannelsManager
{
  /**
    * The manager is built defining from first moment the channels
    * to be included in the ActiveGroupMember
    * @param thisFTDAGMSMember the FTDAGMSMember owning this channel
    * @param members The members to which is needed to create channels
    **/
  public ViewHandler(FTDAGMSMember thisFTDAGMSMember, InternalView initialView)
  {
    super (thisFTDAGMSMember,initialView);
    Trace.code("ViewHandler.java -> ViewHandler ( FTDAGMSMember thisFTDAGMSMember , InternalView initialView )");

    memberGeneration				= thisMember/RANDOM_VIEW;

    //requesters are already created, to avoid their creation each time that
    //they're needed. When there is a communication problem, the requester is
    //regenerated
    sendTokenChannelRequester 					= new SendTokenChannelRequester(thisMember);
    sendViewChannelRequester						= new SendViewChannelRequester(thisMember);						;
    recoverTokenChannelRequester				=	new RecoverTokenChannelRequester(thisMember);
    sendMessagesChannelRequester				= new SendMessagesChannelRequester(thisMember);
    castMessagesChannelRequester				= new CastMessagesChannelRequester(thisMember);
    confirmMessagesChannelRequester			=	new ConfirmMessagesChannelRequester(thisMember);
  }


//*************************************************************************************//
//**************************** SEND TOKEN *********************************************//
//*************************************************************************************//

  /**
    * Sends the token to the next member in the view (to the next channel),
    * returning true if the operation is successful
    * @param viewId the viewId associated to the token
    * @returns true if the next member is alive and accepts the token
    **/
  public synchronized boolean sendToken(Token token)
  {
    Trace.code("ViewHandler.java -> synchronized boolean sendToken ( Token token )");
    boolean ret = isValidObject();

    if (ret)
    {

      assert nextChannel!=-1;

      CommunicationChannel channel = (CommunicationChannel) channels.get(nextChannel);

      assert channel.isReliable();

      sendTokenChannelRequester.setTokenToSend(token);
      ret = channel.invoke(sendTokenChannelRequester);

      //if the sender and received is not the same, wait for the answer
      if (nextChannel==rank)
      {
        if (!ret)
          invalidateObject();
      }
      else
      {
        if (!ret || !channel.waitChannel())
        {
          //error on requester, it must be regenerated; resources can't be released
          sendTokenChannelRequester = new SendTokenChannelRequester(thisMember);

          Trace.wrongCommunication(channel.getLinkId(), ret? 2 : 1, sendTokenChannelRequester.getClass().getName().substring(sendTokenChannelRequester.getClass().getPackage().getName().length()+1));

          faultyMember(nextChannel);
          ret = false;
        }
      }

    }

    return ret;
  }

//*************************************************************************************//
//**************************** SEND VIEW **********************************************//
//*************************************************************************************//

  /**
    * Sends the view to every communication channel
    * returning true if the operation is successful
    * @returns true if every contacted member is alive and accepts the view
    **/
  public boolean sendView(InternalView view, Token viewToken)
  {
    Trace.code("ViewHandler.java -> boolean sendView ( InternalView view , Token viewToken )");
    sendViewChannelRequester.setInfoToSend(view, viewToken);
    boolean ret = makeRequestToEveryChannel (sendViewChannelRequester);

    //if there is an error on requester, it must be regenerated; resources can't be released
    if (!ret)
      sendViewChannelRequester = new SendViewChannelRequester(thisMember);
    return ret;
  }

//*************************************************************************************//
//**************************** SEND MESSAGES ******************************************//
//*************************************************************************************//

  /**
    * Sends the messages to the specified member
    * returning true if the operation is successful
    * @returns true if the member is alive and accepts the message
    **/
  public boolean sendMessages(int target, Message[] messages, MessageId messageId)
  {
    Trace.code("ViewHandler.java -> boolean sendMessages ( int target , Message [ ] messages , MessageId messageId )");
    int channelNumber = getRank(target);

    boolean ret = isValidObject() && channelNumber!=-1;

    if (ret)
    {

      CommunicationChannel channel = (CommunicationChannel) channels.get(channelNumber);

      assert channel.isReliable();

      sendMessagesChannelRequester.setMessagesToSend(messages, messageId);
      ret = channel.invoke(sendMessagesChannelRequester);

      if (!ret || !channel.waitChannel())
      {
        //error on requester, it must be regenerated; resources can't be released
        sendMessagesChannelRequester = new SendMessagesChannelRequester(thisMember);

        Trace.wrongCommunication(channel.getLinkId(), ret? 2 : 1, sendMessagesChannelRequester.getClass().getName().substring(sendMessagesChannelRequester.getClass().getPackage().getName().length()+1));

        if (channelNumber == rank)
          invalidateObject();
        else
          faultyMember(channelNumber);
        ret = false;
      }

    }

    return ret;
  }

//*************************************************************************************//
//**************************** CAST MESSAGES ******************************************//
//*************************************************************************************//

  /**
    * Sends the messages to every communication channel,
    * returning true if the operation is successful
    * @returns true if every contacted member is alive and accepts the messages
    **/
  public boolean castMessages(Message[] messages, MessageId messageId)
  {
    Trace.code("ViewHandler.java -> boolean castMessages ( Message [ ] messages , MessageId messageId )");
    castMessagesChannelRequester.setMessagesToSend(messages, messageId);
    boolean ret = makeRequestToEveryChannel (castMessagesChannelRequester);

    //if there is an error on requester, it must be regenerated; resources can't be released
    if (!ret)
      castMessagesChannelRequester = new CastMessagesChannelRequester(thisMember);
    return ret;
  }

//*************************************************************************************//
//**************************** CONFIRM MESSAGES ***************************************//
//*************************************************************************************//

  /**
    * Sends the message's confirmation to every communication channel,
    * returning true if the operation is successful
    * @returns true if every contacted member is alive and accepts the message's confirmation
    **/
  public boolean confirmMessages(MessageId messageId)
  {
    Trace.code("ViewHandler.java -> boolean confirmMessages ( MessageId messageId )");
    confirmMessagesChannelRequester.setMessageIdToConfirm(messageId);
    boolean ret = makeRequestToEveryChannel (confirmMessagesChannelRequester);

    //if there is an error on requester, it must be regenerated; resources can't be released
    if (!ret)
      confirmMessagesChannelRequester = new ConfirmMessagesChannelRequester(thisMember);
    return ret;
  }

//*************************************************************************************//
//**************************** SEND TOKEN REGENERATION ********************************//
//*************************************************************************************//

  /**
    * Sends the token regeneration to every member
    * @param token The token to send
    * @returns true if there is consensus on the recovery
    **/
  public boolean sendTokenRegeneration()
  {
    Trace.code("ViewHandler.java -> boolean sendTokenRegeneration ( )");
    boolean ret = makeRequestToEveryChannel (recoverTokenChannelRequester);

    //if there us an error on requester, it must be regenerated; resources can't be released
    if (!ret)
      recoverTokenChannelRequester = new RecoverTokenChannelRequester(thisMember);
    return ret;
  }

//*************************************************************************************//
//**************************** FREE RESOURCES *****************************************//
//*************************************************************************************//

  /**
    * Releases any resource associated to this object (~destructor)
    **/
  public void freeResources()
  {
    Trace.code("ViewHandler.java -> void freeResources ( )");
    super.freeResources();

    sendTokenChannelRequester=null;
    sendViewChannelRequester=null;
    recoverTokenChannelRequester=null;
    sendMessagesChannelRequester=null;
    castMessagesChannelRequester=null;
    confirmMessagesChannelRequester=null;

  }

//*************************************************************************************//
//**************************** CONSOLIDATE VIEW ***************************************//
//*************************************************************************************//

  /**
    * Sets the current members as the consolidated ones in a installed view
    **/
  public void consolidateView()
  {
    Trace.code("ViewHandler.java -> void consolidateView ( )");
    super.consolidateView();

    if (++memberGeneration>=RANDOM_VIEW_PERIODICITY)
      memberGeneration=0;
  }

//*************************************************************************************//
//**************************** ADD NEW CHANNELS ***************************************//
//*************************************************************************************//

  /**
    * Creates new communication channels for the new members. Only those members not yet
    * included will obtains a channel.
    * New channels are created just after the one belonging to this member
    * @param newMembers the groupMembers that must have a new channel associated
    **/
  public void addNewChannels(FTDAGMSMember newMembers[])
  {
    Trace.code("ViewHandler.java -> void addNewChannels ( FTDAGMSMember newMembers [ ] )");
    if (isValidObject())
    {
      nextChannel = rank + 1;
      int i = newMembers.length;
      while (i-- > 0)
      {
        FTDAGMSMember newMember = newMembers[i];
        if (!isValidMember(newMember))
          addNewChannel(newMember, getNewGroupMemberId(), nextChannel);
      }
    }
  }

//*************************************************************************************//
//**************************** GET NEW GROUP MEMBER ID ********************************//
//*************************************************************************************//

  /**
    * Calculates a new random member id.
    * The algorithm is the follow:
    *    try = random(100);
    *      from = (view % 10000000) * 100
    *    number = try + from.
    *    If already assigned in the current view,
	  *                          	number = from + (++try rem 100), until one is not found
    * Therefore, on a given view can be added up to 100 members, and every 10.000.000 views
    * a member Id could be repeated.
    * 0 is not a valid member id
    **/
  int getNewGroupMemberId()
  {
    Trace.code("ViewHandler.java -> int getNewGroupMemberId ( )");
    int r = random.nextInt(RANDOM_VIEW);
    int from = memberGeneration * RANDOM_VIEW + 1;
    for (int i=0;i<RANDOM_VIEW;i++)
    {
      int memberId = from + ((r+i)%RANDOM_VIEW);
      if (!isValidMember(memberId))
        return memberId;
    }
    Error.error(Consts.GMS, "ActiveCommunicationChannelsManager:getNewGroupMemberId:no free numbers");
    return Consts.INVALID_MEMBER_ID;
  }

//*************************************************************************************//
//**************************** GENERATE FIRST MEMBER ID *******************************//
//*************************************************************************************//

  static public int generateFirstMemberId()
  {
    Trace.code("ViewHandler.java -> int generateFirstMemberId ( )");
    return 1+random.nextInt(RANDOM_VIEW*RANDOM_VIEW_PERIODICITY);
  }

//*************************************************************************************//
//**************************** DATA MEMBERS *******************************************//
//*************************************************************************************//

  SendTokenChannelRequester						sendTokenChannelRequester;
  SendViewChannelRequester						sendViewChannelRequester;
  RecoverTokenChannelRequester				recoverTokenChannelRequester;
  SendMessagesChannelRequester				sendMessagesChannelRequester;
  CastMessagesChannelRequester				castMessagesChannelRequester;
  ConfirmMessagesChannelRequester			confirmMessagesChannelRequester;

  int memberGeneration;							//It is used to assign new GroupMember identities
  static Random random=new Random();										//used to assign groupMember identities
  //RANDOM_VIEW * RANDOM_VIEW_PERIODICITY < MAX_INT!
  static final int RANDOM_VIEW = 100;
  static final int RANDOM_VIEW_PERIODICITY = 10000000;
}
