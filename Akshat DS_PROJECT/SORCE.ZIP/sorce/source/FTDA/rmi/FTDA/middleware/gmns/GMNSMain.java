package FTDA.middleware.gmns;

/**
  * Interface to be implemented by the middleware-independent main class
  **/
public interface GMNSMain
{
  public void runGMNS(boolean graphical);
}

