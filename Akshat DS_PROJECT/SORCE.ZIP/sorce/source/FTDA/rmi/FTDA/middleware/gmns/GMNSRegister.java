package FTDA.middleware.gmns;

import java.util.Properties;

/**
  * Class to register the valuetypes on the ORB
  **/
public class GMNSRegister
{
  //*************************************************************************************
  //**************************** ORB REGISTERING ****************************************
  //*************************************************************************************

  public GMNSRegister(GMNSMain mainClass, String args[], boolean graphicalMode)
  {
    try
    {
      mainClass.runGMNS(graphicalMode);
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
    }
  }
}

