package FTDA.middleware.gmns;

/**
  * Utility class performing narrow operations for GMNS middleware objects
  **/
public class GMNSnarrower
{

  public final static SetMemberInfo toSetMemberInfo(Object object)
  {
    return object instanceof SetMemberInfo? (SetMemberInfo) object : null;
  }

  public final static GroupHandlerFactory toGroupHandlerFactory(Object object)
  {
    return object instanceof GroupHandlerFactory? (GroupHandlerFactory) object : null;
  }

  public final static GroupMembershipBasicService toGroupMembershipBasicService(Object object)
  {
    return object instanceof GroupMembershipBasicService? (GroupMembershipBasicService) object : null;
  }

  public final static GroupMembershipNamingService toGroupMembershipNamingService(Object object)
  {
    return object instanceof GroupMembershipNamingService? (GroupMembershipNamingService) object : null;
  }

  public final static ReplicatedServer toReplicatedServer(Object object)
  {
    return object instanceof ReplicatedServer? (ReplicatedServer) object : null;
  }

};

