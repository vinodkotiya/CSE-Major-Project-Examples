package FTDA.middleware.gmns;

import FTDA.gms.ActiveGroupMember;
import FTDA.middleware.gms.GroupMember;
import FTDA.middleware.gms.GroupHandler;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
  * Implementation of the GroupHandlerFactory
  **/
public class GroupHandlerFactoryImpl extends UnicastRemoteObject implements GroupHandlerFactory
{
  public GroupHandlerFactoryImpl(GroupMember member) throws RemoteException
  {
    this.member = member;
    thisGroupHandlerFactory=this;
  }

  public void deactivate() throws Exception
  {
    synchronized (this)
    {
      if (thisGroupHandlerFactory!=null)
        unexportObject(thisGroupHandlerFactory,true);
      thisGroupHandlerFactory=null;
    }
  }

  public final GroupHandlerFactory theGroupHandlerFactory()
  {
    return thisGroupHandlerFactory;
  }

  /**
    * Creates a new handler. Returns null if no handle can be created
    **/
  public GroupHandler create() throws GroupHandlerFactoryException
  {
    GroupHandler ret = null;
    try
    {
      ret = new ActiveGroupMember(member).theFTDAGMSMember();
    }
    catch (Exception ex)
    {
      ret=null;
      throw new GroupHandlerFactoryException(ex.getMessage());
    }
    return ret;
  }

  GroupMember member;
  protected GroupHandlerFactory thisGroupHandlerFactory;
}
