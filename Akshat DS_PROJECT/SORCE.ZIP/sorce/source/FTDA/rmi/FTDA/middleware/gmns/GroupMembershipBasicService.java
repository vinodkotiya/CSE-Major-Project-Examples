
package FTDA.middleware.gmns;

import FTDA.middleware.gms.GroupHandler;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface GroupMembershipBasicService extends Remote
{
  /**
    * Creates a GroupHandlerFactoryCreator
    **/
  public GroupHandlerFactoryCreator getFactoryCreator() throws RemoteException;

  /**
    * Creates a new group.
    * @param factory A factory creating GroupHandlers on demand
    **/
  public GroupHandler createGroup(GroupHandlerFactory theFactory)
    throws InvalidGroupHandlerFactoryException, GroupHandlerFactoryException, RemoteException;

  /**
    * Extends a group with an additional member
    * @param group a valid handler on a existing group.
    * @returns the group handler created, which can be nil if the member
    *    could not join the group because was considered faulty or because
    *    the groupHandler used is not valid or has been expulsed from the group
    **/
  public GroupHandler joinGroup(GroupHandler group, GroupHandlerFactory theFactory)
    throws InvalidGroupHandlerException, InvalidGroupHandlerFactoryException,
      GroupHandlerFactoryException, RemoteException;
}
