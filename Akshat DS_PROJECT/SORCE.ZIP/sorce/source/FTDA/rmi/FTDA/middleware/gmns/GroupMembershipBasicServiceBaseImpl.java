package FTDA.middleware.gmns;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
  * Implementation of the GroupMembershipBasicService RMI interface.
  **/
public abstract class GroupMembershipBasicServiceBaseImpl extends UnicastRemoteObject
  implements GroupMembershipBasicService
{

  public GroupMembershipBasicServiceBaseImpl() throws Exception
  {
    thisGroupMembershipBasicService=this;
  }

  public GroupMembershipBasicServiceBaseImpl(boolean activate) throws Exception
  {
    if (!activate)
      deactivate();
  }

  public void activate() throws Exception
  {
    if (thisGroupMembershipBasicService==null)
    {
      thisGroupMembershipBasicService=this;
      exportObject(this);
    }
  }

  public void deactivate() throws RemoteException
  {
    synchronized (this)
    {
      if (thisGroupMembershipBasicService!=null)
        unexportObject(thisGroupMembershipBasicService,true);
      thisGroupMembershipBasicService=null;
    }
  }

  public final GroupMembershipBasicService theGroupMembershipBasicService()
  {
    return thisGroupMembershipBasicService;
  }

  protected GroupMembershipBasicService thisGroupMembershipBasicService;
}
