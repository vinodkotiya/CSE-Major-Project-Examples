
package FTDA.middleware.gmns;

import FTDA.middleware.domains.MemberStateException;
import FTDA.middleware.gms.GroupHandler;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface GroupMembershipNamingService extends Remote
{
  /**
    * Creates a GroupHandlerFactoryCreator
    **/
  public GroupHandlerFactoryCreator getFactoryCreator() throws RemoteException;

  /**
    * Finds a group with the name specified and includes the member with the given name
    * The reference can be null if the member is no accesible to clients
    * @returns the group handler created, or null if this member has been considered by
    *  the group.
    * @exception MemberStateException if the member defining the service cannot contact
    *  other members and decide surely about the joining
    **/
  public GroupHandler findAndJoinGroup(String groupName, GroupHandlerFactory theFactory, String memberName,
      ReplicatedServer clientsReference)
    throws MemberStateException, InvalidGroupHandlerFactoryException, GroupHandlerFactoryException, RemoteException;

  /**
    * Leaves a group. This method is not needed to be called, as the service can
    * discover by itself that a member has left the group, but it can speed up
    * other member's joining.
    **/
  public void leaveGroup(String groupName, GroupHandler member) throws RemoteException;

  /**
    * Returns the know references to a group, which can be still not valid. The list
    * is empty if there are no servers in the group or the group does not exist
    **/
  public ReplicatedServer[] getGroup(String groupName) throws MemberStateException, RemoteException;

  /**
    * Returns a specific reference of a member in the group. If
    * the group does not exist or it contains no such a member, null is returned
    **/
  public ReplicatedServer getGroupServer(String groupName, String memberName)
    throws MemberStateException, RemoteException;

  /**
    * Returns a reference to a member in the group, warrantied to be valid. Note that it can
    * get invalidated before the client received it.
    **/
  public ReplicatedServer getValidGroupServer(String groupName) throws MemberStateException, RemoteException;
}
