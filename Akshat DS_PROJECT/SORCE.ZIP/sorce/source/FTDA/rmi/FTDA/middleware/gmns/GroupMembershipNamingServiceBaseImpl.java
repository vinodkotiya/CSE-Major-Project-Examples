package FTDA.middleware.gmns;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
  * Implementation of the GroupMembershipNamingService RMI interface.
  **/
public abstract class GroupMembershipNamingServiceBaseImpl extends UnicastRemoteObject
  implements GroupMembershipNamingService
{

  public GroupMembershipNamingServiceBaseImpl() throws Exception
  {
    thisGroupMembershipNamingService=this;
  }

  public GroupMembershipNamingServiceBaseImpl(boolean activate) throws Exception
  {
    if (!activate)
      deactivate();
  }

  public void activate() throws Exception
  {
    if (thisGroupMembershipNamingService==null)
    {
      thisGroupMembershipNamingService=this;
      exportObject(this);
    }
  }

  public void deactivate() throws RemoteException
  {
    synchronized (this)
    {
      if (thisGroupMembershipNamingService!=null)
        unexportObject(thisGroupMembershipNamingService,true);
      thisGroupMembershipNamingService=null;
    }
  }

  public final GroupMembershipNamingService theGroupMembershipNamingService()
  {
    return thisGroupMembershipNamingService;
  }

  protected GroupMembershipNamingService thisGroupMembershipNamingService;
}
