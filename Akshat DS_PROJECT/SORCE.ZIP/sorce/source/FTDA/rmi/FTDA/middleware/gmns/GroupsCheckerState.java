package FTDA.middleware.gmns;

import FTDA.middleware.domains.State;

public class GroupsCheckerState implements State
{
  public int checker;
};
