
package FTDA.middleware.gmns;

import java.rmi.RemoteException;

final public class InvalidGroupHandlerException extends RemoteException
{
    public
    InvalidGroupHandlerException()
    {
        super();
    }

    public
    InvalidGroupHandlerException(String _reason)
    {
      super(_reason);
    }

}
