package FTDA.middleware.gms;

final public class AllowTokenRecoveryAnswer implements java.io.Serializable
{
    public
    AllowTokenRecoveryAnswer()
    {
    }

    public
    AllowTokenRecoveryAnswer(boolean validCommunication,
                             boolean recoveryAllowed,
                             MessageId lastMessage)
    {
        this.validCommunication = validCommunication;
        this.recoveryAllowed = recoveryAllowed;
        this.lastMessage = lastMessage;
    }

    public boolean validCommunication;
    public boolean recoveryAllowed;
    public MessageId lastMessage;
}
