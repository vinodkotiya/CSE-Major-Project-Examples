 
package FTDA.middleware.gms;

/**
  * Utility class performing narrow operations for GMS middleware objects
  **/
public class GMSnarrower
{
	
	public final static GroupHandler toGroupHandler(Object object)
	{
		return object instanceof GroupHandler? (GroupHandler) object : null;
	}
	
	public final static GroupMember toGroupMember(Object object)
	{
		return object instanceof GroupMember? (GroupMember) object : null;
	}
	
	public final static FTDAGMSMember toFTDAGMSMember(Object object)
	{
		return object instanceof FTDAGMSMember? (FTDAGMSMember) object : null;
	}
	
}
