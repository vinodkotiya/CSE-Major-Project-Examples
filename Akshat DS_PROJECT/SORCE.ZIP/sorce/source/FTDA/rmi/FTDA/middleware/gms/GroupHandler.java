package FTDA.middleware.gms;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
  * GroupHandler defines the interface that allows to the application to
  * make group communications.
  */
public interface GroupHandler extends Remote
{
  /**
    * Returns the GroupMemberId handled by this GroupHandler.
    * If the member is not active, the returned value is random - negative.
    **/
  public int getGroupMemberId() throws RemoteException;

  /**
    * Returns true if the member belong to a group
    **/
  public boolean isValidGroup() throws RemoteException;

  /**
    * Leaves the group
    * @returns true if the member was belonging to a group
    **/
  public boolean leaveGroup() throws RemoteException;

  /**
    * Sends a message to every member in the view, returning
    * true if the message is sent on this view
    * @param message The message to send
    * @returns true if the message is sent on the current view
    **/
  public boolean castMessage(Message message) throws RemoteException;

  /**
    * Sends a message to the specified member in the view, returning
    * true if the message is sent on this view. This call allows
    * to keep the order between cast and point-to-point messages
    * @param target The member receiving the message
    * @param message The message to send
    * @returns true if the message is sent on the current view
    **/
  public boolean sendMessage(int target, Message message) throws RemoteException;
}
