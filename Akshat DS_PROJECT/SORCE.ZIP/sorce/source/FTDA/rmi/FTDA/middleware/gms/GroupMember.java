package FTDA.middleware.gms;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
  * GroupMember specifies the interface to be implemented by group members
  */
public interface GroupMember extends Remote
{
  /**
    * The member receives a point to point message to be processed
    * @param message The message to process
    **/
  public void processPTPMessage(int sender, Message message) throws RemoteException;

  /**
    * The member receives a group message to be processed
    * @param message The message to process
    **/
  public void processCastMessage(int sender, Message message) throws RemoteException;

  /**
    * The member is accepted in the group, and receives the first view and its identity
    * It receives as well the GroupHandler to use for communications
    **/
  public void memberAccepted(int identity, GroupHandler handler, View view) throws RemoteException;

  /**
    * The group is going to change the view, any new message will be sent on the next view
    **/
  public void changingView() throws RemoteException;

  /**
    * The member receives a new view, including the list of members
    * @param message The message to process
    **/
  public void installView(View view) throws RemoteException;

  /**
    * The member is excluded from the group, because it has requested it or because
    * it's considered to be faulty.
    **/
  public void excludedFromGroup() throws RemoteException;
}
