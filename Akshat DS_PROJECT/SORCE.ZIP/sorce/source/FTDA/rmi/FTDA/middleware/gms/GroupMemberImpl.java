package FTDA.middleware.gms;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
  * Implementation of the GroupMember RMI interface.
  **/
public abstract class GroupMemberImpl extends UnicastRemoteObject implements GroupMember
{

  public GroupMemberImpl() throws Exception
  {
    thisGroupMember=this;
  }

  public GroupMemberImpl(boolean activate) throws Exception
  {
    if (!activate)
      deactivate();
  }

  public void activate() throws Exception
  {
    if (thisGroupMember==null)
    {
      thisGroupMember=this;
      exportObject(this);
    }
  }

  public void deactivate() throws RemoteException
  {
    synchronized (this)
    {
      if (thisGroupMember!=null)
        unexportObject(thisGroupMember,true);
      thisGroupMember=null;
    }
  }

  public final GroupMember theGroupMember()
  {
    return thisGroupMember;
  }

  protected GroupMember thisGroupMember;
}
