package FTDA.middleware.gms;

public interface INVALID_GROUP_MEMBER_ID
{
    public static final int value = 0;
}
