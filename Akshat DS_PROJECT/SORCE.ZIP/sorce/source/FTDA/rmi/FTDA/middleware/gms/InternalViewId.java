package FTDA.middleware.gms;

final public class InternalViewId implements java.io.Serializable
{
    public
    InternalViewId()
    {
    }

    public
    InternalViewId(int id,
                   int installing)
    {
        this.id = id;
        this.installing = installing;
    }

    public int id;
    public int installing;
}
