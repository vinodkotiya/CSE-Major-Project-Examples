package FTDA.middleware.gms;

public abstract class Message
  implements java.io.Serializable
{
}
