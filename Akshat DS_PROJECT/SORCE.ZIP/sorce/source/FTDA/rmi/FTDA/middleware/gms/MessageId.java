/**
  * File: MessageId.java
  * Content: part of the RMI specification of members with reliable multicast
  *          communications, based on the virtual synchronous model
  * Author: LuisM Pena
  * Date: 6th August 2000
  * Version: 0.80.00
  * Last change:
  *
  **/

package FTDA.middleware.gms;


final public class MessageId implements java.io.Serializable
{
    public
    MessageId()
    {
    }

    public
    MessageId(int view,
              int id)
    {
        this.view = view;
        this.id = id;
    }

    public int view;
    public int id;
}
