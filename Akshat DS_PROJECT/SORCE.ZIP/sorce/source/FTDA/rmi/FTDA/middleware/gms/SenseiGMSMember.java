package FTDA.middleware.gms;

import java.rmi.RemoteException;

/**
  * FTDAGMSMember specifies the interface that group members must
  * implement to enable the communications in the group
  * FTDAGMSMember stands for FTDA GroupMembershipService Member
	* The same member is a GroupHandler itself 
  */
public interface FTDAGMSMember extends GroupHandler
{
	/**
	  * The member receives the token. It is time to send any
	  * queued messages or to install new views, and, after that,
	  * transfer the token to the next member in the group.
	  * @param sender The FTDAGMSMember sending the token
	  * @param token  The token being passed
	  * @returns true if the token is accepted.
	  **/
	public boolean receiveToken(int sender, Token token) throws RemoteException;
	 
	/**
	  * The member receives a new view. If the member is joining
	  * the group, this view includes effectively the member in
	  * the group, and its call to join will eventually return
	  * with a succesfull flag
	  * @param sender The FTDAGMSMember sending the token
	  * @param view The new view to install
	  * @param viewToken The token to be used by the group during the
	  *        new view. If the new view has been generated after a
	  *        recovery of a lost token, this token must be differente
	  *        of the one used in the previous view
	  * @returns true if the view is accepted
	  **/
	public boolean receiveView(int sender, InternalView view, Token viewToken) throws RemoteException;

	/**
	  * The member receives new messages. They won't be processed immediately
	  * (it's a two phase commit process)
	  * @param sender The FTDAGMSMember sending the token
	  * @param messages The array of messages to process
	  * @param messageId an id for the group of messages
	  * @returns true if the messages are accepted
	  **/
	public boolean receiveMessages(int sender, Message[] messages, MessageId messageId) throws RemoteException;

	/**
	  * The member receives the confirmation to previous messages. 
	  * @param sender The FTDAGMSMember sending the token
	  * @param messageId an id for the group of messages
	  * @returns true if the confirmation is valid
	  **/
	public boolean confirmMessages(int sender, MessageId messageId) throws RemoteException;

	/**
	  * The member receives one or more point to point messages.
	  * @param sender The FTDAGMSMember sending the token
	  * @param messages The point to point messages to process
	  * @param messageId It's only required the view information in the message id. 
	  * 	The id itself must be zero.
	  * @return true if the message is accepted
	  **/
	public boolean receivePTPMessages(int sender, Message[] messages, MessageId messageId) throws RemoteException;

	/**
	  * This method is called by another member which thinks that
	  * the token is lost and it's trying to recover it. There are
	  * three possible answers, depending on the returning values and
	  * the recover parameter.
	  * @param sender The FTDAGMSMember trying to recover the token
	  * @param myViewId the view id currently seen by the sender
	  * @param recover includes the answer of this member to the
	  *    try to recover the token
	  * @returns true if it considers that the sender can recover the token
	  **/
	public AllowTokenRecoveryAnswer allowTokenRecovery(int sender, InternalViewId myViewId) throws RemoteException;
	  
	/**
	  * This method is called by another member which is recovering
	  * the token; after this message is received, the token is considered
	  * lost and no tokens or views will be accepted until a new view
	  * is installed by the member who has sent this message.
	  * @param sender The FTDAGMSMember trying to recover the token
	  * @returns false if it doesn't accept the token recovery or the sender
	  **/
	public boolean recoverToken(int sender) throws RemoteException;

	/**
	  * Joins the member to the current group where this member
	  * is included. It blocks until the member is effectively
	  * included in the group (it will also receive a view with
	  * the members in the group).
	  * @param other The FTDAGMSMember willing to join the group
	  * @returns false if the member can not be included because
	  *  the contacted GroupMember doesn't belong to any group
	  */
	public boolean addGroupMember(FTDAGMSMember other) throws RemoteException;

	/**
	  * This method starts a new group where the only member is this member. This member
	  * cannot be part of any other group, or the creation will fail
	  **/
	public boolean createGroup() throws RemoteException;

	/**
	  * This method joins an existing group. This joining can fail, and in that case
	  * it is returned false and this object is invalidated, that is, cannot be used
	  * to join another member. It can fail as well if the member belonged already to
	  * other group; in that case, the member is not invalidated (it can be checked
	  * previously using validObject()).
	  * This method will use addGroupMember on the specified goup, taking care of
	  * the possible exclusion conditions.
	  **/
	public boolean joinGroup(FTDAGMSMember group) throws RemoteException;
}
