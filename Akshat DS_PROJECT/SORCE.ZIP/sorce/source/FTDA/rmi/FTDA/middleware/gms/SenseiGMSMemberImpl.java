package FTDA.middleware.gms;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
  * Class implementing the RMI interface for the GroupMember. This implementation is intended
  * to allow to the application to define its GroupMember class directly inheriting
  *	from this class.
  **/
public abstract class FTDAGMSMemberImpl extends UnicastRemoteObject implements FTDAGMSMember
{

  public FTDAGMSMemberImpl() throws Exception
  {
    thisFTDAGMSMember=this;
  }

  public FTDAGMSMemberImpl(boolean activate) throws Exception
  {
    if (!activate)
      deactivate();
  }

  public void activate() throws Exception
  {
    if (thisFTDAGMSMember==null)
    {
      thisFTDAGMSMember=this;
      exportObject(this);
    }
  }

  public void deactivate() throws RemoteException
  {
    synchronized (this)
    {
      if (thisFTDAGMSMember!=null)
        unexportObject(thisFTDAGMSMember,true);
      thisFTDAGMSMember=null;
    }
  }

  public final FTDAGMSMember theFTDAGMSMember()
  {
    return thisFTDAGMSMember;
  }

  FTDAGMSMember thisFTDAGMSMember;
}
