package FTDA.middleware.gms;

final public class Token implements java.io.Serializable
{
    public
    Token()
    {
    }

    public
    Token(int creator,
          int id)
    {
        this.creator = creator;
        this.id = id;
    }

    public int creator;
    public int id;
}
