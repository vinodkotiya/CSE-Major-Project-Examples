package FTDA.middleware.gms;

final public class View implements java.io.Serializable
{
    public
    View()
    {
    }

    public
    View(int viewId,
         int[] members,
         int[] newMembers,
         int[] expulsedMembers)
    {
        this.viewId = viewId;
        this.members = members;
        this.newMembers = newMembers;
        this.expulsedMembers = expulsedMembers;
    }

    public int viewId;
    public int[] members;
    public int[] newMembers;
    public int[] expulsedMembers;
}
