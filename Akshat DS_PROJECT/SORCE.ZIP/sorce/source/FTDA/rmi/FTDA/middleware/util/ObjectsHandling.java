package FTDA.middleware.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import java.rmi.Remote;

/**
  * Implements object handling for RMI objects. The purpose of this
  *	file is to abstract differences between RMI and CORBA models.
  *	It includes operations to persist objects and to compare them
  **/
public class ObjectsHandling
{

//*************************************************************************************//
//**************************** WRITE OBJECT *******************************************//
//*************************************************************************************//

  /**
    * @param object the remote object to store, which must habe been previously exported
    * @param outputStream the stream to write the reference of this member.
    **/
  static public void writeObject(Remote object, OutputStream stream) throws IOException
  {
    ObjectOutputStream oo = new ObjectOutputStream(stream);
    oo.writeObject(object==null? object : java.rmi.server.RemoteObject.toStub(object));
  }

//*************************************************************************************//
//**************************** WRITE OBJECT *******************************************//
//*************************************************************************************//

  /**
    * @param object the remote object to store, which must habe been previously exported
    * @param fileName the name of the file where the reference is stored
    **/
  static public void writeObject(Remote object, String fileName) throws IOException
  {
    FileOutputStream file=null;
    try
    {
      file = new FileOutputStream(fileName);
      writeObject(object, file);
    }
    finally
    {
      if (file!=null)
        file.close();
    }
  }

//*************************************************************************************//
//**************************** READ OBJECT &&******************************************//
//*************************************************************************************//

  /**
    * @param inputStream the stream to write the reference of this member.
    * @returns the object read
    **/
  static public Object readObject(InputStream stream) throws IOException, ClassNotFoundException
  {
    ObjectInputStream oi = new ObjectInputStream(stream);
    return oi.readObject();
  }

//*************************************************************************************//
//**************************** READ OBJECT &&******************************************//
//*************************************************************************************//

  /**
    * @param fileName the name of the file where the reference is stored
    * @returns the object read
    **/
  static public Object readObject(String fileName) throws IOException, ClassNotFoundException
  {
    Object ret = null;
    FileInputStream file=null;
    try
    {
      file = new FileInputStream(fileName);
      ret = readObject(file);
    }
    finally
    {
      if (file!=null)
        file.close();
    }
    return ret;
  }

//*************************************************************************************//
//**************************** ARE EQUIVALENT *****************************************//
//*************************************************************************************//

  /**
    * check if the two specified objects are equivalents
    **/
  static public boolean areEquivalent(Object left, Object right)
  {
    return left==null? right==null : left.equals(right);
  }

}
