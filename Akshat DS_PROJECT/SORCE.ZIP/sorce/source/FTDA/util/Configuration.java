/**
  * File: Configuration.java
  * Content: Class to load the FTDA properties. These are defined in a file, where
  *          it must be specified:
  *				Configuration->
  *            a) verboseMode       			= true
	*                                                                                                                                                    	shows the configuration values at starting
  *       Logging->
  *           a) logging                = false
  *           b) remoteLoggingPort      = 0
  *                                     sets the port to do remote logging, or 0 if local logging required
  *				Debug->
  *            a) debugMode				       			= true
	*                                                                                                                                                    	set to true to enter debug mode (assertions are verified)
  *				GMS->
  *            a) GMS.channelLivenes			   = 10000 milliseconds
	*                                                                                                                                                  	period after which a channel is considered death
  *            b) GMS.maxProcessMessageDelay = 5000 milliseconds
	*                                                                                                                                                    	timeout for an application to process a message
  *            c) GMS.tokenStoppedPeriod	   = 50 milliseconds
	*                                                                                                                                                    	period to keep the token when no communications are needed
  *            d) GMS.tokenLostTimeout		   = 6000 milliseconds
	*                                                                                                                                                    	timeout to recover a token lost
  *            e) GMS.weakConsensus		       = false
	*                                                                                                                                                    	set to true to allow weak consensus, that is, is enough to
  *                                               have the middle of the members alive to continue in consensus.
  *                                               If set to true, channelLiveness should be increased
  *					   f) GMS.trace								   = false
  *																			                Log GMS traces
  *            g) GMS.traceCode              = false
  *                                                     Log GMS code traces
  *					   h) GMS.traceToken   				   = false
  *																			                Log the pass of the token
  *					   i) GMS.traceExceptions		     = false
  *																			                Log GMS exceptions
  *					   j) GMS.traceExceptionsDetailed= false
  *																			                Log GMS exceptions in long format
  *
  *				GMNS->
  *          a) GMNS.referenceFile	    The file to store the reference for the current GMNS instance.
  *																			Only this ot the referencePort are needed.
  *																			If the referenceFile is present, the reference Port is not
  *																			used. If both are unspecified, the default port is used
  *          b) GMNS.referencePort	    = 1212
  *																			The port to export the reference for the current GMNS instance.
  * 				 c) GMNS.backupFile			    = GMNS.backup
  *																			The file to store the backup information for the current
  *																			GMNS instance.
  * 				 d) GMNS.backupPeriod 	    = GMNS.backup period
  *																			Periodic time to store the GMNS information on the backup file
  *																			GMNS instance.
  * 				 e) GMNS.backupPeriod 	    = GMNS.backup period
  *																			Periodic time to store the GMNS information on the backup file
  *																			GMNS instance.
  *					 f) GMNS.checkPeriod  	    = 10
  *																			The number of gmnsHosts holding GMNS instances
  *          g) GMNS.hostSocket.xxx  or
  * 						GMNS.hostURL.xx					No default value, must be present for each GMNS.hosts
  *																			For each instance, the socket OR the URL to load the
  * 																		reference to the GMNS instance
  *          h) GMNS.collisionTimeout		= 2500 milliseconds
  *          														Defines the period to wait when 2 GMNS starting at same time
  * 																		discover themselves and one must wait this period while the
  *																			another one completes its initialitation
  *																			to the GMNS instance
  *					 i) GMNS.Trace							= false
  *																			Log GMNS traces
  *          j) GMNS.traceCode          = false
  *                                     Log GMNS code traces
  *					 k) GMNS.TraceExceptions		= false
  *					  													Log GMNS exceptions
  *					 l) GMNS.TraceExceptionsDetailed		= false
  *																			Log GMNS exceptions in long format
  *
  *				DOMAINS->
  *					 a) DOMAINS.Trace							  = false
  *																			Log DOMAINS traces
  *          b) DOMAINS.traceCode           = false
  *                                     Log DOMAINS code traces
  *					 c) DOMAINS.TraceExceptions		  = false
  *																			Log DOMAINS exceptions
  *					 d) DOMAINS.TraceExceptionsDetailed		= false
  *																			Log DOMAINS exceptions in long format
  *
  *				UMA->
  *					 a) UMA.Trace							  = false
  *																			Log UMA traces
  *          b) UMA.traceCode           = false
  *                                     Log UMA code traces
  *					 c) UMA.TraceExceptions		  = false
  *																			Log UMA exceptions
  *					 d) UMA.TraceExceptionsDetailed		= false
  *																			Log UMA exceptions in long format
  *
  * The configuration file is searched in three folders, in the following order:
  *				1- Current directory
  *				2- User's home directory
  *				3- Java home directory
  *
  * Author: LuisM Pena
  * Date: 11th September 2000
  * Version: 0.97.00
  * Last change:
  *
  **/

package FTDA.util;

import FTDA.util.logging.Logger;

import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.net.URL;

import java.util.Map;
import java.util.Properties;
import java.util.Vector;

/**
  * Class loading the FTDA properties
  **/
public class Configuration
{

//*************************************************************************************//
//**************************** GET SINGLETON ******************************************//
//*************************************************************************************//

  /**
    * Basic constructor: reads the default properties file, and, if not found, gets default values
    **/
  static public Configuration getSingleton()
  {
    return getSingleton(null);
  }

  /**
    * Reads default properties, like getSingleton(), but allows for redefinitions
    **/
  static public Configuration getSingleton(Map redefinitions)
  {
    synchronized (DefaultPropertiesFile)	//just any objetc also static!
    {
      if (singleton==null)
      {
        boolean doWarning;
        Properties defaultProperties;
        File defaultPropertiesFile = getPropertiesFile(DefaultPropertiesFile);
        if (defaultPropertiesFile==null)
        {
          defaultProperties = new Properties();
          doWarning = true;
        }
        else
          try
          {
            defaultProperties = readProperties(defaultPropertiesFile);
            doWarning = false;
            configurationFile = defaultPropertiesFile.toString();
          }
          catch (IOException ioex)
          {
            defaultProperties = new Properties();
            doWarning = true;
          }

        getSingleton(defaultProperties, redefinitions);

        if (doWarning)
          singleton.warning(DefaultConstructor);
        else
        {
          singleton.warning("configuration values read from default file " + defaultPropertiesFile.toString()
            + " loaded since " + new TraceInfo());
        }
      }
    }
    return singleton;
  }

  /**
    * The properties are read from a file. This file must be completely specified.
    * @param redefinitions Redefinitions over the file, can be null
    **/
  static public Configuration getSingleton(String propertiesFile, Map redefinitions) throws IOException
  {
    synchronized (DefaultPropertiesFile)	//just any objetc also static!
    {
      if (singleton==null)
      {
        File thePropertiesFile = getPropertiesFile(propertiesFile);

        if (thePropertiesFile == null)
        {
          getSingleton(redefinitions);

          singleton.warning("configuration file " + propertiesFile + " was not found");
        }
        else
        {
          getSingleton(readProperties(thePropertiesFile), redefinitions);
          configurationFile = thePropertiesFile.toString();
          singleton.warning("configuration values read from file " + configurationFile.toString());
        }
      }
      else
        singleton.warning(ReconstructorError);
    }
    return singleton;
  }

  /**
    * The properties are read directly from a Properties file
    **/
  static private Configuration getSingleton(Properties properties, Map redefinitions)
  {
    synchronized (DefaultPropertiesFile)	//just any object also static!
    {
      if (singleton==null)
      {
        if (redefinitions != null)
          properties.putAll(redefinitions);
        new Configuration().constructor(properties);
      }
      else
        singleton.warning(ReconstructorError);
    }
    return singleton;
  }

//*************************************************************************************//
//**************************** LOGGIGN PUBLIC *****************************************//
//*************************************************************************************//

  /**
    * Returns the remote logging port
    **/
  public int getRemoteLoggingPort(){return remoteLoggingPort;}

  /**
    * Returns the logging policy
    **/
  public boolean hasLogging(){return logging;}


//*************************************************************************************//
//**************************** GMS PUBLIC *********************************************//
//*************************************************************************************//

  /**
    * Returns the period after which a channel is considered death
    **/
  public int getGMSChannelLiveness(){return gmsChannelLiveness;}


  /**
    * Returns the timeout for an application to process a message
    **/
  public int getGMSMaxProcessMessageDelay(){return gmsApplicationTimeout;}

  /**
    * Returns the period to keep the token when no communications are needed
    **/
  public int getGMSTokenStoppedPeriod(){return gmsTokenStoppedPeriod;}

  /**
    * Returns the timeout to recover a token lost
    **/
  public int getGMSTokenLostTimeout(){return gmsTokenLostTimeout;}

  /**
    * Returns the consensus policy
    **/
  public boolean hasGMSWeakConsensus(){return gmsWeakConsensus;}

  /**
    * Returns true if GMS needs tracing
    **/
  public boolean traceGMS(){return gmsTrace;}

  /**
    * Returns true if GMS needs tracing on the code (call to methods)
    **/
  public boolean traceGMSCode(){return gmsTraceCode;}

  /**
    * Returns true if GMS needs tracing on the pass of the token
    **/
  public boolean traceGMSToken(){return gmsTraceToken;}

  /**
    * Returns true if GMS needs tracing on exceptions
    **/
  public boolean traceExceptionsGMS(){return gmsTraceExceptions;}

  /**
    * Returns true if GMS needs detailed tracing on exceptions
    **/
  public boolean traceExceptionsDetailedGMS(){return gmsTraceExceptionsDetailed;}


//*************************************************************************************//
//**************************** INNER CLASS FOR GMNS ***********************************//
//*************************************************************************************//

  public class GMNShost
  {
    public boolean socketSpecified(){return url==null;}
    public URL url;
    public String host;
    public int port;
    public String toString(){return socketSpecified()? "@"+host+":"+port : "URL: " + url;}
    GMNShost(URL url){this.url=url;host=null;}
    GMNShost(String host, int port){this.host=host;this.port=port;url=null;}
  }

//*************************************************************************************//
//**************************** GMNS PUBLIC ********************************************//
//*************************************************************************************//

  /**
    * Returns the gmnsHost by default
    **/
   public GMNShost getGMNSHost(){return gmnsHost;}


  /**
    * Returns the gmnsHosts read (all but the current one)
    **/
  public GMNShost[] getGMNSHosts(){return gmnsHosts;}


  /**
    * Returns true if the GMNS reference must be publicshed by socket, not on file
    **/
  public boolean isGMNSReferencePublishedBySocket(){return gmnsReferenceFile==null;}


  /**
    * Returns the file for the reference file. Null if reference specified by socket
    **/
  public File getGMNSReferenceFile(){return gmnsReferenceFile;}


  /**
    * Returns the port to publish the reference
    **/
  public int getGMNSReferencePort(){return gmnsReferencePort;}


  /**
    * Returns the period to check the members in the GMNS (in seconds)
    **/
  public int getGMNSCheckPeriod(){return gmnsCheckPeriod;}

  /**
    * Returns the file for the backup file (can be null)
    **/
  public File getGMNSBackupFile(){return gmnsBackupFile;}

  /**
    * Returns the period to store the backup file (in seconds)
    **/
  public int getGMNSBackupPeriod(){return gmnsBackupPeriod;}

  /**
    * Returns the collision timeout
    **/
  public int getGMNSCollisionTimeout(){return gmnsCollisionTimeout;}

  /**
    * Returns true if GMNS needs tracing
    **/
  public boolean traceGMNS(){return gmnsTrace;}

  /**
    * Returns true if GMNS needs code tracing
    **/
  public boolean traceGMNSCode(){return gmnsTraceCode;}

  /**
    * Returns true if GMNS needs tracing on exceptions
    **/
  public boolean traceExceptionsGMNS(){return gmnsTraceExceptions;}

  /**
    * Returns true if GMNS needs detailed tracing on exceptions
    **/
  public boolean traceExceptionsDetailedGMNS(){return gmnsTraceExceptionsDetailed;}


//*************************************************************************************//
//**************************** DOMAINS PUBLIC *********************************************//
//*************************************************************************************//

  /**
    * Returns true if DOMAINS needs tracing
    **/
  public boolean traceDOMAINS(){return domainsTrace;}

  /**
    * Returns true if DOMAINS needs tracing on the code (call to methods)
    **/
  public boolean traceDOMAINSCode(){return domainsTraceCode;}

  /**
    * Returns true if DOMAINS needs tracing on exceptions
    **/
  public boolean traceExceptionsDOMAINS(){return domainsTraceExceptions;}

  /**
    * Returns true if DOMAINS needs detailed tracing on exceptions
    **/
  public boolean traceExceptionsDetailedDOMAINS(){return domainsTraceExceptionsDetailed;}


//*************************************************************************************//
//**************************** OTHERS PUBLIC ******************************************//
//*************************************************************************************//

  public boolean debuggingMode(){return debugMode;}

  public String getConfigurationFile(){return configurationFile;}


//*************************************************************************************//
//**************************** CONSTRUCTOR ********************************************//
//*************************************************************************************//

  /**
    * Real constuctor
    * @param 			propertiesFile the file where the properties are located
    * @exception  IOException if there are problems with the properties file
    **/
  private void constructor(Properties properties)
  {
    singleton = this;

    //generic properties
    loadGenericProperties(properties);
    //load gms properties
    loadGMSProperties (properties);
    //load gmns properties
    loadGMNSProperties (properties);
    //load domains properties
    loadDOMAINSProperties (properties);
  }

//*************************************************************************************//
//**************************** LOAD GMS PROPERTIES ************************************//
//*************************************************************************************//

  void loadGMSProperties(Properties properties)
  {
    gmsChannelLiveness=readUnsigned(properties, gmsChannelLivenessString, gmsChannelLivenessDefault);
    gmsApplicationTimeout=readUnsigned(properties, gmsApplicationSlowString, gmsApplicationSlowDefault);
    gmsTokenStoppedPeriod=readUnsigned(properties, gmsTokenStoppedString, gmsTokenStoppedDefault);
    gmsTokenLostTimeout=readUnsigned(properties, gmsTokenLostTimeoutString, gmsTokenLostTimeoutDefault);
    gmsWeakConsensus=readBoolean(properties, gmsWeakConsensusString, gmsWeakConsensusDefault);

    gmsTrace = readBoolean(properties, gmsTraceString, gmsTraceDefault);
    gmsTraceCode = readBoolean(properties, gmsTraceCodeString, gmsTraceCodeDefault);
    gmsTraceToken = readBoolean(properties, gmsTraceTokenString, gmsTraceTokenDefault);
    gmsTraceExceptions = readBoolean(properties, gmsTraceExceptionsString, gmsTraceExceptionsDefault);
    gmsTraceExceptionsDetailed = readBoolean(properties, gmsTraceExDetailedString, gmsTraceExDetailedDefault);

    gmsTraceToken = gmsTrace && gmsTraceToken;
    gmsTraceExceptions = gmsTrace && gmsTraceExceptions;
    gmsTraceExceptionsDetailed = gmsTraceExceptions && gmsTraceExceptionsDetailed;

    log(gmsString, gmsChannelLivenessString, gmsChannelLiveness);
    log(gmsString, gmsApplicationSlowString, gmsApplicationTimeout);
    log(gmsString, gmsTokenStoppedString, gmsTokenStoppedPeriod);
    log(gmsString, gmsTokenLostTimeoutString, gmsTokenLostTimeout);
    log(gmsString, gmsWeakConsensusString, gmsWeakConsensus);
    log(gmsString, gmsTraceString, gmsTrace);
    log(gmsString, gmsTraceCodeString, gmsTraceCode);
    log(gmsString, gmsTraceTokenString, gmsTraceToken);
    log(gmsString, gmsTraceExceptionsString, gmsTraceExceptions);
    log(gmsString, gmsTraceExDetailedString, gmsTraceExceptionsDetailed);
  }

//*************************************************************************************//
//**************************** LOAD GMNS PROPERTIES ***********************************//
//*************************************************************************************//

  void loadGMNSProperties(Properties properties)
  {
    String refFile, backFile, prop;
    gmnsTrace = gmnsTraceDefault;
    gmnsTraceCode = gmnsTraceCodeDefault;
    gmnsTraceExceptions = gmnsTraceExceptionsDefault;
    gmnsTraceExceptionsDetailed = gmnsTraceExDetailedDefault;

    //1- look for the entrance gmnsReferenceFile or gmnsReferencePort
    gmnsReferencePort = gmnsReferencePortDefault;
    refFile = properties.getProperty(gmnsReferenceFileString);
    if (refFile==null)
    {
      gmnsReferencePort = readUnsigned(properties, gmnsReferencePortString, gmnsReferencePortDefault);
      gmnsReferenceFile = null;
    }
    else
    {
      gmnsReferenceFile = new File (refFile);
    }

    gmnsHost = createDefaultGMNSHost(gmnsReferenceFile, gmnsReferencePort);

    //3- look for the entrance gmnsCheckPeriod
    gmnsCheckPeriod		= readUnsigned(properties,gmnsCheckPeriodString, gmnsCheckPeriodDefault);

    //4- look for the entrance gmnsBackupFile
    backFile 				= properties.getProperty(gmnsBackupFileString, gmnsBackupFileDefault);
    gmnsBackupFile 	= new File (backFile);

    //5- look for the entrance gmnsBackupPeriod
    gmnsBackupPeriod		= readUnsigned(properties,gmnsBackupPeriodString, gmnsBackupPeriodDefault);

    //6- look for the entrance gmnsCollisionTimeout
    gmnsCollisionTimeout = readUnsigned(properties, gmnsCollisionTimeoutString, gmnsCollisionTimeoutDefault);

    //7- look for the entrance Hosts
    gmnsHosts = readHosts(properties, readUnsigned(properties, gmnsHostsString, 0));

    //8- look for the entrances for traces
    gmnsTrace = readBoolean(properties, gmnsTraceString, gmnsTraceDefault);
    if (gmnsTrace)
    {
      gmnsTraceCode = readBoolean(properties, gmnsTraceCodeString, gmnsTraceCodeDefault);
      gmnsTraceExceptions = readBoolean(properties, gmnsTraceExceptionsString, gmnsTraceExceptionsDefault);
      if (gmnsTraceExceptions)
        gmnsTraceExceptionsDetailed = readBoolean(properties, gmnsTraceExDetailedString, gmnsTraceExDetailedDefault);
    }

    gmnsTraceCode = gmnsTrace && gmnsTraceCode;
    gmnsTraceExceptions = gmnsTrace && gmnsTraceExceptions;
    gmnsTraceExceptionsDetailed = gmnsTraceExceptions && gmnsTraceExceptionsDetailed;


    //logging
    if (gmnsReferenceFile==null)
      log(gmnsString, gmnsReferencePortString, gmnsReferencePort);
    else
      log(gmnsString, gmnsReferenceFileString, refFile);

    log(gmnsString, gmnsCheckPeriodString, gmnsCheckPeriod);
    log(gmnsString, gmnsBackupFileString, backFile);
    log(gmnsString, gmnsBackupPeriodString, gmnsBackupPeriod);
    log(gmnsString, gmnsCollisionTimeoutString, gmnsCollisionTimeout);
    log(gmnsString, gmnsTraceString, gmnsTrace);
    log(gmnsString, gmnsTraceCodeString, gmnsTraceCode);
    log(gmnsString, gmnsTraceExceptionsString, gmnsTraceExceptions);
    log(gmnsString, gmnsTraceExDetailedString, gmnsTraceExceptionsDetailed);
  }

//*************************************************************************************//
//**************************** CREATE DEFAULT GMNS HOST *******************************//
//*************************************************************************************//

  /**
    * Creates a default GMNS host using the file or port specified
    **/
  GMNShost createDefaultGMNSHost(File file, int port)
  {
    GMNShost ret = null;
    try
    {
      if (file==null)
        ret = new GMNShost(InetAddress.getLocalHost().getHostName(),port);
      else
        ret = new GMNShost(file.toURL());
    }
    catch(Exception ex)
    {
      warning(gmnsErrorOnDefaultGMNShost);
      ret = new GMNShost("localhost",port);
    }
    return ret;
  }

//*************************************************************************************//
//**************************** READ HOSTS *********************************************//
//*************************************************************************************//

  /**
    * Loads the specified hosts. It only returns those found, or null if none found
    **/
  GMNShost[] readHosts(Properties properties, int nhosts)
  {
    GMNShost ret[]=null;
    Vector hosts = new Vector();
    int iHost=0;
    while(iHost++<nhosts)
    {
      GMNShost host=readHost(properties, iHost);
      if (host!=null)
        hosts.add(host);
    }
    ret = new GMNShost[hosts.size()];
    if (hosts.isEmpty())
      warning(gmnsNoHostsWarning);
    else
      hosts.toArray(ret);
    return ret;
  }

//*************************************************************************************//
//**************************** READ HOST **********************************************//
//*************************************************************************************//

  /**
    * Read the URL or socket for the specific host, returning null if not found or when is wrong.
    **/
  GMNShost readHost(Properties properties, int host)
  {
    GMNShost ret=readURL(properties, host);
    if (ret==null)
      ret=readSocket(properties, host);

    if (ret==null)
      warning(gmnsHostNotDefined + host);

    return ret;
  }

//*************************************************************************************//
//**************************** READ URL ***********************************************//
//*************************************************************************************//

  /**
    * Read the URL for the specific host, returning null if not found or when is wrong.
    * If found, it is logged, and if it is incorrect, it is logged the mistake, but no
    * log is produced if no URL found
    **/
  GMNShost readURL(Properties properties, int host)
  {
    GMNShost ret=null;
    String index = gmnsURLxString + Integer.toString(host);
    String prop = properties.getProperty(index);
    if (prop!=null)
      try
      {
        //it must have the form host:port
        URL url = new URL(prop);
        ret = new GMNShost(url);
        log(gmnsString,index,prop);
      }
      catch(MalformedURLException ex)
      {
        ret=null;
        warning(index + gmnsBadURLWarning);
      }
    return ret;
  }

//*************************************************************************************//
//**************************** READ SOCKET ********************************************//
//*************************************************************************************//

  /**
    * Read the Socket for the specific host, returning null if not found or when is wrong.
    * If found, it is logged, and if it is incorrect, it is logged the mistake, but no
    * log is produced if no info found
    **/
  GMNShost readSocket(Properties properties, int host)
  {
    GMNShost ret=null;
    String index = gmnsSocketxString + Integer.toString(host);
    String prop = properties.getProperty(index);
    if (prop!=null)
    {
      int n=prop.lastIndexOf(':');
      if (n>0)
        try
        {
          ret = new GMNShost (prop.substring(0,n), Integer.valueOf(prop.substring(n+1)).intValue());
          log(gmnsString,index,prop);
        }
        catch(Exception ex)
        {
          ret = null;
        }
      if (ret == null)
        warning(index + gmnsBadSocketWarning);
    }
    return ret;
  }


//*************************************************************************************//
//**************************** LOAD GENERIC PROPERTIES ********************************//
//*************************************************************************************//

  /**
    * Loads from the properties the generic properties, assigning
    * default values when possible.
    **/
  void loadGenericProperties(Properties properties)
  {
    //1- look for the entrance verboseMode
    verboseMode = readBoolean(properties, VerboseModeString, VerboseModeDefault);

    //2- look for the entrance debugMode
    debugMode = readBoolean(properties, DebugModeString, DebugModeDefault);

    //3- look for the entrance logging & remoteLoggingPort
    logging = readBoolean(properties, LoggingString, LoggingDefault);
    if (logging)
    {
      remoteLoggingPort = readUnsigned(properties, RemoteLoggingPortString, RemoteLoggingPortDefault);

      log(loggingString, RemoteLoggingPortString, remoteLoggingPort);
      log(debugString, DebugModeString, debugMode);

      if (remoteLoggingPort==0)
        logger.useLocalLogging();
      else
        logger.useRemoteLogging(remoteLoggingPort);
    }
    else
      logger.doNotUseLogging();
  }

//*************************************************************************************//
//**************************** LOAD DOMAINS PROPERTIES ************************************//
//*************************************************************************************//

  void loadDOMAINSProperties(Properties properties)
  {
    domainsTrace = readBoolean(properties, domainsTraceString, domainsTraceDefault);
    domainsTraceCode = readBoolean(properties, domainsTraceCodeString, domainsTraceCodeDefault);
    domainsTraceExceptions = readBoolean(properties, domainsTraceExceptionsString, domainsTraceExceptionsDefault);
    domainsTraceExceptionsDetailed = readBoolean(properties, domainsTraceExDetailedString, domainsTraceExDetailedDefault);

    domainsTraceExceptions = domainsTraceExceptions && domainsTrace;
    domainsTraceExceptionsDetailed = domainsTraceExceptionsDetailed && domainsTraceExceptions;

    log(domainsString, domainsTraceString, domainsTrace);
    log(domainsString, domainsTraceCodeString, domainsTraceCode);
    log(domainsString, domainsTraceExceptionsString, domainsTraceExceptions);
    log(domainsString, domainsTraceExDetailedString, domainsTraceExceptionsDetailed);
  }

  //*************************************************************************************//
  //**************************** GET PROPERTIES FILE ************************************//
  //*************************************************************************************//

  /**
    * Read the properties file specified. The file is searched in three locations:
    * the current directory, the user's home directory, and the java home directory.
    * @returns null if no such a file exists
    **/
  static File getPropertiesFile(String file)
  {
    File specifiedFile = new File(file);
    if (specifiedFile.isFile())
      return specifiedFile;

    String directory = System.getProperty("user.home");
    if (directory!=null)
    {
      specifiedFile = new File(directory, file);
      if (specifiedFile.isFile())
        return specifiedFile;
    }

    directory = System.getProperty("java.home");
    if (directory!=null)
    {
      specifiedFile = new File(directory, file);
      if (specifiedFile.isFile())
        return specifiedFile;
    }

    return null;
  }

  //*************************************************************************************//
  //**************************** READ PROPERTIES ****************************************//
  //*************************************************************************************//

  /**
    * Read the properties file specified.
    **/
  static Properties readProperties(File file) throws IOException
  {
    FileInputStream propertiesStream = new FileInputStream(file);
    Properties properties = new Properties();
    try
    {
      properties.load(propertiesStream);
    }
    finally
    {
      propertiesStream.close();
    }
    return properties;
  }

  //*************************************************************************************//
  //**************************** READ UNSIGNED ******************************************//
  //*************************************************************************************//

  int readUnsigned(Properties properties, String name, int defaultValue)
  {
    int ret=-1;
    String prop = properties.getProperty(name);
    if (prop==null)
    {
      ret = defaultValue;
      warning(name + NotDefinedWarning);
    }
    else
    {
      try
      {
        ret = Integer.parseInt(prop);
      }
      catch(NumberFormatException ex)
      {
        ret = -1;
      }
      if (ret<0)
      {
        warning(name + InvalidIntegerWarning);
        ret = defaultValue;
      }
    }
    return ret;
  }

  //************************************************************************************//
  //**************************** READ BOOLEAN *******************************************//
  //*************************************************************************************//

  boolean readBoolean(Properties properties, String name, boolean defaultValue)
  {
    boolean ret=defaultValue;
    String prop = properties.getProperty(name);
    if (prop==null)
      warning (name + NotDefinedWarning);
    else
      if (prop.equalsIgnoreCase(FalseValue))
        ret = false;
      else if (prop.equalsIgnoreCase(TrueValue))
        ret = true;
      else
        warning (name + InvalidBooleanWarning);
    return ret;
  }

  //*************************************************************************************//
  //**************************** LOG ****************************************************//
  //*************************************************************************************//

  void log(String group, String variable, String value)
  {
    if (verboseMode)
    {
      logger.log(group + " - " + variable + " = " + value);
    }
  }

  void log(String group, String variable, boolean value)
  {
    log(group, variable, value? TrueValue : FalseValue);
  }

  void log(String group, String variable, int value)
  {
    log(group, variable, String.valueOf(value));
  }

  //*************************************************************************************//
  //**************************** WARNING ************************************************//
  //*************************************************************************************//

  void warning(String message)
  {
    if (verboseMode)
      logger.log("Warning : " + message);
  }

  //*************************************************************************************//
  //**************************** DEFAULT CONSTRUCTOR ************************************//
  //*************************************************************************************//

  /**
    * Configuration objects can not be built outside the factory methods
    **/
  private Configuration()
  {
    logger=Logger.getLogger(LogName, true);
  }


  //*************************************************************************************//
  //**************************** DATA MEMBERS *******************************************//
  //*************************************************************************************//

  Logger logger = null;
  boolean verboseMode, logging;
  int remoteLoggingPort;

  //Debug variables
  boolean debugMode;

  static String configurationFile;

  //GMS variables
  int gmsChannelLiveness;
  int gmsApplicationTimeout;
  int gmsTokenStoppedPeriod;
  int gmsTokenLostTimeout;
  boolean gmsWeakConsensus;
  boolean gmsTrace, gmsTraceCode, gmsTraceToken, gmsTraceExceptions, gmsTraceExceptionsDetailed;

  //GMNS variables
  File 			gmnsReferenceFile;
  File 			gmnsBackupFile;
  GMNShost	gmnsHosts[], gmnsHost;
  int				gmnsCheckPeriod, gmnsBackupPeriod, gmnsCollisionTimeout, gmnsReferencePort;
  boolean 	gmnsReferenceSpecifiedBySocket;
  boolean 	gmnsTrace, gmnsTraceCode, gmnsTraceExceptions, gmnsTraceExceptionsDetailed;

  //DOMAINS variables
  boolean domainsTrace, domainsTraceCode, domainsTraceExceptions, domainsTraceExceptionsDetailed;

  static Configuration singleton = null;
  //General
  public  static final String  DefaultPropertiesFile      = "FTDA.properties";
  public  static final String  LogName                    = "Configuration";
  public  static final String  FalseValue                 = "false";
  public  static final String  TrueValue                  = "true";
  private static final String  NotDefinedWarning     		  = " is not defined";
  private static final String  InvalidIntegerWarning      = " contains an invalid integer value";
  private static final String  InvalidBooleanWarning      = " contains an invalid boolean value";
  private static final String  DefaultConstructor         =
    "No configuration file found, default configuration values have been loaded";
  private static final String  ReconstructorError         =
    "Configuration has been already loaded, perhaps with default values. " +
    "It is a singleton class that should be created very soon in the program flow";

  //PROPERTY KEYS
          //Configuration
  public static final String  VerboseModeString 	 			 = "verboseMode";
          //Logging
  public static final String  LoggingString              = "logging";
  public static final String  RemoteLoggingPortString    = "remoteLoggingPort";
          //Debug
  public static final String  DebugModeString 	 	 			 = "debugMode";
          //GMS
  public static final String  gmsChannelLivenessString	 = "GMS.channelLiveness";
  public static final String  gmsApplicationSlowString	 = "GMS.maxProcessMessageDelay";
  public static final String  gmsTokenStoppedString      = "GMS.tokenStoppedPeriod";
  public static final String  gmsTokenLostTimeoutString  = "GMS.tokenLostTimeout";
  public static final String  gmsWeakConsensusString     = "GMS.weakConsensus";
  public static final String  gmsTraceString 			       = "GMS.trace";
  public static final String  gmsTraceCodeString         = "GMS.traceCode";
  public static final String  gmsTraceTokenString        = "GMS.traceToken";
  public static final String  gmsTraceExceptionsString   = "GMS.traceExceptions";
  public static final String  gmsTraceExDetailedString   = "GMS.traceExceptionsDetailed";
          //GMNS
  public static final String  gmnsReferencePortString 	 = "GMNS.referencePort";
  public static final String  gmnsReferenceFileString 	 = "GMNS.referenceFile";
  public static final String  gmnsCheckPeriodString	     = "GMNS.checkPeriod";
  public static final String  gmnsBackupFileString 		   = "GMNS.backupFile";
  public static final String  gmnsBackupPeriodString	   = "GMNS.backupPeriod";
  public static final String  gmnsHostsString 		       = "GMNS.hosts";
  public static final String  gmnsURLxString 			       = "GMNS.hostURL.";
  public static final String  gmnsSocketxString		       = "GMNS.hostSocket.";
  public static final String  gmnsCollisionTimeoutString = "GMNS.collisionTimeout";
  public static final String  gmnsTraceString 			     = "GMNS.trace";
  public static final String  gmnsTraceCodeString 			 = "GMNS.traceCode";
  public static final String  gmnsTraceExceptionsString  = "GMNS.traceExceptions";
  public static final String  gmnsTraceExDetailedString  = "GMNS.traceExceptionsDetailed";
          //DOMAINS
  public static final String  domainsTraceString 			       = "DOMAINS.trace";
  public static final String  domainsTraceCodeString         = "DOMAINS.traceCode";
  public static final String  domainsTraceExceptionsString   = "DOMAINS.traceExceptions";
  public static final String  domainsTraceExDetailedString   = "DOMAINS.traceExceptionsDetailed";


  //DEFAULT VALUES
          //Configuration
  private static final boolean VerboseModeDefault			   = true;
          //Logging
  private static final boolean LoggingDefault            = false;
  private static final int     RemoteLoggingPortDefault  = 0;
          //Debug
  private static final boolean DebugModeDefault			   	 = true;
          //GMS
  private static final int     gmsChannelLivenessDefault = 10000;
  private static final int     gmsApplicationSlowDefault = 5000;
  private static final int     gmsTokenStoppedDefault 	 = 50;
  private static final int     gmsTokenLostTimeoutDefault= 6000;
  private static final boolean gmsWeakConsensusDefault   = false;
  private static final boolean gmsTraceDefault 			     = false;
  private static final boolean gmsTraceCodeDefault       = false;
  private static final boolean gmsTraceTokenDefault	     = false;
  private static final boolean gmsTraceExceptionsDefault = false;
  private static final boolean gmsTraceExDetailedDefault = false;
          //GMNS
  private static final int  	 gmnsReferencePortDefault  = 1212;
  private static final int     gmnsCheckPeriodDefault    = 10;
  private static final String  gmnsBackupFileDefault		 = "gmns.backup";
  private static final int     gmnsBackupPeriodDefault   = 300;
  private static final int     gmnsCollisionTimeoutDefault=2500;
  private static final boolean gmnsTraceDefault 			   = false;
  private static final boolean gmnsTraceCodeDefault		   = false;
  private static final boolean gmnsTraceExceptionsDefault= false;
  private static final boolean gmnsTraceExDetailedDefault= false;
          //DOMAINS
  private static final boolean domainsTraceDefault 			   	 = false;
  private static final boolean domainsTraceCodeDefault       = false;
  private static final boolean domainsTraceExceptionsDefault = false;
  private static final boolean domainsTraceExDetailedDefault = false;

  //WARNING STRINGS
  private static final String  debugString             	 = "Debug";
  private static final String  loggingString             = "Logging";
          //GMS
  private static final String  gmsString                 = "GMS";
          //GMNS
  private static final String  gmnsString                = "GMNS";
  private static final String  gmnsBadURLWarning				 = " is a wrong URL";
  private static final String  gmnsBadSocketWarning			 = " is incorrectlySpecified (no host:port)";
  private static final String  gmnsHostNotDefined        = " is not defined an URL o Socket for GMNShost ";
  private static final String  gmnsNoHostsWarning			   = "no other GMNS hosts";
  private static final String  gmnsErrorOnDefaultGMNShost= "Error determining the default GMNS";
          //DOMAINS
  private static final String  domainsString                 = "DOMAINS";
}
