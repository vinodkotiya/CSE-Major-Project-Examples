package senseiTests.chat.corba;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class ChatFrame extends javax.swing.JFrame implements Runnable
{

    /** Creates new form JFrame */
  public ChatFrame(ChatMember user)
  {
    this.user=user;
    valid=true;

    initComponents ();
    enableMessages(false);
    pack ();
    int x = (int) getGraphicsConfiguration().getBounds().getWidth();
    int y = (int) getGraphicsConfiguration().getBounds().getHeight();
    setLocation(x/10+new java.util.Random().nextInt(2*(x/5)),
                y/10+new java.util.Random().nextInt(2*(y/5)));
    show();

//    new Thread(this).start();

  }

    /** This method is called from within the constructor to
     * initialize the form.
   
  private void initComponents()//GEN-BEGIN:initComponents
  {
    jPanel1 = new javax.swing.JPanel();
    jLabel1 = new javax.swing.JLabel();
    messageField = new javax.swing.JTextField();
    sendButton = new javax.swing.JButton();
    jPanel5 = new javax.swing.JPanel();
    jScrollPane1 = new javax.swing.JScrollPane();
    chatTextArea = new javax.swing.JTextArea();
    getContentPane().setLayout(new javax.swing.BoxLayout(getContentPane(), 1));
    setName("");
    setTitle("Chat Members");
    addWindowListener(new java.awt.event.WindowAdapter()
    {
      public void windowClosing(java.awt.event.WindowEvent evt)
      {
        exitForm(evt);
      }
    }
    );

    jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, 0));
    jPanel1.setBorder(new javax.swing.border.CompoundBorder(
    new javax.swing.border.TitledBorder("Input"),
    new javax.swing.border.EtchedBorder()));
    jPanel1.setMaximumSize(new java.awt.Dimension(2147483647, 250));

    jLabel1.setText("Message:");
      jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
      jPanel1.add(jLabel1);


    jPanel1.add(messageField);


    sendButton.setText("Send");
      sendButton.addActionListener(new java.awt.event.ActionListener()
      {
        public void actionPerformed(java.awt.event.ActionEvent evt)
        {
          sendButtonActionPerformed(evt);
        }
      }
      );
      jPanel1.add(sendButton);


    getContentPane().add(jPanel1);

    jPanel5.setLayout(new java.awt.GridLayout(0, 1));
    jPanel5.setBorder(new javax.swing.border.CompoundBorder(
    new javax.swing.border.TitledBorder(
    new javax.swing.border.EtchedBorder(), "Group chat"),
    new javax.swing.border.EtchedBorder()));

    jScrollPane1.setPreferredSize(new java.awt.Dimension(300, 300));

      chatTextArea.setEditable(false);
        jScrollPane1.setViewportView(chatTextArea);

        jPanel5.add(jScrollPane1);


    getContentPane().add(jPanel5);

//    sensei.gms.TraceGraphical trace=new ftda.gms.TraceGraphical(false,true);
//    getContentPane().add(trace);
//    ftda.gms.Trace.addTracer(trace);

  }//GEN-END:initComponents

  private void sendButtonActionPerformed(java.awt.event.ActionEvent evt) {
    final String text=messageField.getText();
    new Thread(){
      public void run()
      {
        user.ownMessage(text);
      }
    }.start();
    Thread.yield();
    messageField.setText("");
  }

    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
      if (valid)
      {
        valid=false;
        user.exiting();
        System.exit (0);
      }
    }//GEN-LAST:event_exitForm

    public void addChatMessage(final java.lang.String chatMessage)
    {
      SwingUtilities.invokeLater(new Runnable(){
        public void run()
        {
          chatTextArea.append(chatMessage+"\n");
          chatTextArea.setCaretPosition(chatTextArea.getDocument().getLength()-1);
        }
      });
    }

    public void error(java.lang.String message)
    {
      JOptionPane.showMessageDialog(this, message, "Error",  JOptionPane.ERROR_MESSAGE);
    }

    public void enableMessages(final boolean enable)
    {
      enabled=enable;
      SwingUtilities.invokeLater(new Runnable(){
        public void run()
        {
          messageField.setEnabled(enable);
          sendButton.setEnabled(enable);
        }
      });
    }

    public void run()
    {
      try
      {
        int i=0;
        Thread thread = Thread.currentThread();
        while(valid)
        {
          if (enabled)
            user.ownMessage("Automatic message number " + (++i));
          thread.sleep((long)(SLEEP_PERIOD*rnd.nextDouble()));
        }
      }
      catch(InterruptedException ex)
      {
        error(ex.getMessage());
      }
    }

    ChatMember user;
    boolean valid, enabled;
    java.util.Random rnd=new java.util.Random();

    static final long SLEEP_PERIOD=20000;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField messageField;
    private javax.swing.JButton sendButton;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea chatTextArea;
    // End of variables declaration//GEN-END:variables

}
