package ftdaTests.chat.corba;

import ftda.middleware.gms.GroupHandler;
import ftda.middleware.gms.Message;
import ftda.middleware.gms.View;


public class ChatMember extends ftda.middleware.gms.GroupMemberImpl
{

    /** Creates new ChatMember */
  public ChatMember() throws Exception
  {
    handler=null;
    gui = new ChatFrame(this);
  }

    /**
     * The member is excluded from the group, because it has requested it or because
     * it's considered to be faulty.
     */
  public void excludedFromGroup()
  {
    gui.enableMessages(false);
    gui.error("Member excluded from the group");
    System.exit(0);
  }

    /**
     * The member receives a new view, including the list of members
     * @param message The message to process
     */
  public void installView(View view)
  {
  }

  public void changingView()
  {
  }

    /**
     * The member is accepted in the group, and receives the first view and its identity
     * It receives as well the GroupHandler to use for communications
     */
  public void memberAccepted(int identity,GroupHandler handler,View view)
  {
    this.handler=handler;
    gui.enableMessages(true);
  }

    /**
     * The member receives a group message to be processed
     * @param message The message to process
     */
  public void processCastMessage(int sender,Message message)
  {
    ChatMessage msg = (ChatMessage) message;
    gui.addChatMessage(msg.msg);
  }

    /**
     * The member receives a point to point message to be processed
     * @param message The message to process
     */
  public void processPTPMessage(int sender,Message message)
  {
  }

  /**
   * Called by the ChatFrame instance when the Send button is pressed
   **/
  public void ownMessage(java.lang.String message)
  {
    try {handler.castMessage(ChatMessageFactory.create(message));}
    catch(Exception ex){gui.error(ex.getMessage());}
  }

  /**
   * Called by the ChatFrame instance when closing the frame
   **/
  public void exiting()
  {
    try {handler.leaveGroup();}
    catch(Exception ex){gui.error(ex.getMessage());}
  }

  ChatFrame gui;
  GroupHandler handler;
}
