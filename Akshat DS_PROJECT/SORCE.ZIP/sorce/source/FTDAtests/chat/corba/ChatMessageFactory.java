package ftdaTests.chat.corba;

import ftda.middleware.util.ORBcentral;

import org.omg.CORBA.portable.ValueFactory;
import org.omg.CORBA_2_3.ORB;
import org.omg.CORBA_2_3.portable.InputStream;

public class ChatMessageFactory implements ValueFactory
{
  public java.io.Serializable read_value(InputStream in)
  {
    return in.read_value(new ChatMessageImpl());
  }

  static public ChatMessage create(String message)
  {
    return new ChatMessageImpl(message);
  }

  static public void register()
  {
    ((ORB)(ORBcentral.getORB())).register_value_factory(ChatMessageHelper.id(), new ChatMessageFactory());
  }

};

class ChatMessageImpl extends ChatMessage
{
  ChatMessageImpl(String message){super.msg=message;}
  ChatMessageImpl(){}
}
