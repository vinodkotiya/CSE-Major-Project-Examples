package ftdaTests.chat.corba;

import ftda.gmns.GroupMembershipNamingServiceFactory;
import ftda.util.Configuration;
import ftda.middleware.gmns.GroupHandlerFactoryImpl;
import ftda.middleware.gmns.GroupMembershipNamingService;
import ftda.middleware.util.ORBcentral;

import java.util.Properties;

import org.omg.CORBA.ORB;

/**
 *
 * @author  Administrator
 * @version
 */
public class Main extends java.lang.Object
{

    /** Creates new Main */
  public Main (String args[])
  {
    ORB orb = null;
    try
    {
      Properties props = System.getProperties();

//      args=vnet2.OOCInterceptor.setup(null, args, props);//only change for virtual net

      orb = ORB.init(args, props);

      if (args.length>0)
        Configuration.getSingleton(args[args.length-1], null);

      ORBcentral.setORB(orb);
      ChatMessageFactory.register();

      GroupMembershipNamingService gmns = GroupMembershipNamingServiceFactory.load();
      if (gmns==null)
        System.out.println("No GroupMembershipNamingService found");
      else
      {
        if (gmns.findAndJoinGroup("ChatMember group",
            new GroupHandlerFactoryImpl(new ChatMember().theGroupMember()).theGroupHandlerFactory(),
            "NoName", null)
           == null)
          System.out.println("Not joined :-(");
        else
          orb.run();
      }
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
    }
    if (orb!=null)
      try {orb.destroy();}catch(Exception ex){}
  }


    /**
     * @param args the command line arguments
     */
  public static void main (String args[])
  {
    new Main(args);
  }

}
