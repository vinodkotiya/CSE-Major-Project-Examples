package ftdaTests.chat.rmi;

import java.rmi.RemoteException;
import ftda.gms.ActiveGroupMember;
import ftda.middleware.gms.GroupHandler;
import ftda.middleware.gms.Message;
import ftda.middleware.gms.ftdaGMSMember;
import ftda.middleware.gms.View;


/**
 *
 * @author  Administrator
 * @version
 */
public class ChatMember extends ftda.middleware.gms.GroupMemberImpl
{

    /** Creates new ChatMember */
  public ChatMember() throws Exception
  {
    handler=null;
    gui = new ChatFrame(this);
  }

  public ftdaGMSMember connect(ftdaGMSMember toJoin)
  {
    ftdaGMSMember created=null;
    try
    {
      created=new ActiveGroupMember(this);
      boolean ok= (toJoin==null)? created.createGroup() : created.joinGroup(toJoin);
      if (!ok) gui.error("Error creating / joining group");
    }
    catch(Exception ex){gui.error(ex.getMessage());}
    return created;
  }

    /**
     * The member is excluded from the group, because it has requested it or because
     * it's considered to be faulty.
     */
  public void excludedFromGroup()
  {
    gui.error("Member excluded from the group");
  }

  public void changingView()
  {
  }

    /**
     * The member receives a new view, including the list of members
     * @param message The message to process
     */
  public void installView(View view) throws RemoteException
  {
  }

    /**
     * The member is accepted in the group, and receives the first view and its identity
     * It receives as well the GroupHandler to use for communications
     */
  public void memberAccepted(int identity,GroupHandler handler,View view)
  {
    this.handler=handler;
    gui.enableMessages(true);
  }

    /**
     * The member receives a group message to be processed
     * @param message The message to process
     */
  public void processCastMessage(int sender,Message message)
  {
    ChatMessage msg = (ChatMessage) message;
    gui.addChatMessage(msg.getChatMessage());
  }

    /**
     * The member receives a point to point message to be processed
     * @param message The message to process
     */
  public void processPTPMessage(int sender,Message message)
  {
  }

  /**
   * Called by the ChatFrame instance when the Send button is pressed
   **/
  public void ownMessage(java.lang.String message)
  {
    try {handler.castMessage(new ChatMessage(message));}
    catch(Exception ex){gui.error(ex.getMessage());}
  }

  /**
   * Called by the ChatFrame instance when closing the frame
   **/
  public void exiting()
  {
    try {handler.leaveGroup();}
    catch(Exception ex){gui.error(ex.getMessage());}
  }

  ChatFrame gui;
  GroupHandler handler;
}
