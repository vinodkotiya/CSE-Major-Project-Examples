package ftdaTests.chat.rmi;

import ftda.middleware.gms.Message;

/**
 *
 * @author  Administrator
 * @version
 */
public class ChatMessage extends Message{


  public ChatMessage(java.lang.String message)
  {
      this.message=message;
  }


  public String getChatMessage()
  {
      return message;
  }

  String message;

}

