package ftdaTests.chat.rmi;

/**
 *
 * @author  Administrator
 * @version
 */
public class Main extends java.lang.Object
{

    /** Creates new Main */
  public Main ()
  {
    try
    {
      new ChatMember().connect(new ChatMember().connect(new ChatMember().connect(null)));
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
    }
  }


    /**
     * @param args the command line arguments
     */
  public static void main (String args[])
  {
    new Main();
  }

}
