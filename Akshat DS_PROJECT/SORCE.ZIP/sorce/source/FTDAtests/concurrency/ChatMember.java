package ftdaTests.concurrency;

import ftda.middleware.gms.*;

public class ChatMember extends GroupMemberImpl
{
  Factory factory;
  GroupHandler handler;
  int id;
  Printer printer;

  public ChatMember(Factory factory, Printer printer) throws Exception
  {
    this.factory=factory;
    this.printer=printer;
  }

  public void castString(String string) throws Exception
  {
    handler.castMessage(factory.createStringMessage(string));
  }

  public void changingView(){}
  public void installView(View view){}
  public void processPTPMessage(int sender, Message msg){}
  public void excludedFromGroup(){}
  public void memberAccepted(int id, GroupHandler groupHandler, View view)
  {
    this.handler=groupHandler;
    this.id=id;
  }
  public void processCastMessage(int sender, Message msg)
  {
    printer.print("------Msg from " + sender+": " + factory.getContentOnStringMessage(msg));
  }
}

