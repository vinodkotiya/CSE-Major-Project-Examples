package ftdaTests.concurrency;

import ftda.middleware.gms.Message;

public interface Factory
{
  public Message createStringMessage(String content);
  public String getContentOnStringMessage(Message message);
}
