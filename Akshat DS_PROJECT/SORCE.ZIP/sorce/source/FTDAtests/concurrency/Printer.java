package ftdaTests.concurrency;

class Printer
{
  public void print(String line)
  {
    if (waitingInput)
      System.out.print("\b\b"+line+"\n> ");
    else
      System.out.println(line);
  }

  public void onInputRequest()
  {
    waitingInput=true;
    System.out.print("\n> ");
  }

  public void inputGiven()
  {
    waitingInput=false;
  }

  boolean waitingInput;
}

