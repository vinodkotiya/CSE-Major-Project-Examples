package ftdaTests.concurrency.corba;

import ftdaTests.concurrency.Factory;

import ftda.middleware.gms.Message;
import ftda.middleware.util.ORBcentral;

import org.omg.CORBA.portable.ValueFactory;
import org.omg.CORBA_2_3.ORB;
import org.omg.CORBA_2_3.portable.InputStream;


public class CorbaFactory implements Factory
{

  public Message createStringMessage(String content)
  {
    return new StringMessageImpl(content);
  }

  public String getContentOnStringMessage(Message message)
  {
    return ((StringMessage)message).content;
  }

  //*************************************************************************************//
  //**************************** INNER CLASSES *******************************************//
  //*************************************************************************************//

  //message is not queued on state transfers, but it is transactionable!
  static class StringMessageImpl extends StringMessage
  {
    public StringMessageImpl (String content) {this.content=content;unqueuedOnST=true;}
  }

  //*************************************************************************************//
  //**************************** ORB REGISTERING ****************************************//
  //*************************************************************************************//

  static void register(){}
  static
  {
    ORB orb = ((ORB)(ORBcentral.getORB()));
    orb.register_value_factory
    (
      StringMessageHelper.id(),
      new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new StringMessage(){});}}
    );
  }

}
