package senseiTests.concurrency.rmi;

import senseiTests.concurrency.TestMonitor;

import sensei.util.Parameters;
import sensei.util.ParameterException;

public class Main
{
  public Main(String args[])
  {
    Parameters parameters = TestMonitor.readArgs(args);
    if (parameters!=null)
    {
      try
      {
        new TestMonitor(new RMIFactory(),parameters);
      }
      catch(ParameterException ex)
      {
        System.out.println(ex);
      }
      catch(Exception ex)
      {
        ex.printStackTrace();
      }
    }
  }

  public static void main(String args[])
  {
    new Main(args);
  }
}

