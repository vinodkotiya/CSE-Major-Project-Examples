package senseiTests.concurrency.rmi;

import senseiTests.concurrency.Factory;

import sensei.middleware.gms.Message;

public class RMIFactory implements Factory
{

  public Message createStringMessage(String content)
  {
    return new StringMessageImpl(content);
  }

  public String getContentOnStringMessage(Message message)
  {
    return ((StringMessage)message).content;
  }

  //*************************************************************************************//
  //**************************** INNER CLASSES *******************************************//
  //*************************************************************************************//

  //message is not queued on state transfers, but it is transactionable!
  static class StringMessageImpl extends StringMessage implements java.io.Serializable
  {
    public StringMessageImpl (String content) {this.content=content;unqueuedOnST=true;}
  }

  //*************************************************************************************//
  //**************************** ORB REGISTERING ****************************************//
  //*************************************************************************************//

  static void register(){}
}
