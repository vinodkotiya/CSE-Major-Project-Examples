package senseiTests.concurrency.rmi;

public class StringMessage extends sensei.middleware.domains.DomainMessage implements java.io.Serializable
{
  public String content;
}
