package ftdaTests.domainsTest;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class ColoursInfoPanel extends JPanel implements ActionListener
{
  public ColoursInfoPanel(UIFrame parent, StateChanger stateChanger, int identity, String stType)
  {
    super(new BorderLayout());
    this.uiFrame = parent;
    this.setBorder(BorderFactory.createTitledBorder("Subgroup " + identity + " - " + stType));
    this.stateChanger=stateChanger;
    withState=false;
    init();
    enableUserInteraction(false);
  }

  public void enableUserInteraction()
  {
    setStatus("");
    enableUserInteraction(true);
  }

  public void colourChangePropagated()
  {
    enableUserInteraction();
  }

  public void setStatus(String st)
  {
    SwingThreadedChanger.setText(status, st);
  }

  public void setState(String state)
  {
    SwingThreadedChanger.setText(this.state, state);
  }

  public void showError(Exception ex)
  {
    uiFrame.showError(ex);
  }

  void init()
  {
    Box box = Box.createVerticalBox();
    box.add(createStateRow());
    box.add(Box.createVerticalStrut(5));
    box.add(createButtonsRow());
    add(box);
  }

  Component createStateRow()
  {
    Box box = Box.createHorizontalBox();
    box.add(new JLabel("State: "));
    state = new JTextField();
    state.setEditable(false);
    state.setBorder(BorderFactory.createLoweredBevelBorder());
    box.add(state);
    return box;
  }

  Component createButtonsRow()
  {
    Box box = Box.createHorizontalBox();
    addButton = new JButton("Add color");
    box.add(addButton);
    box.add(Box.createHorizontalStrut(5));
    removeButton=new JButton("Rem? color");
    box.add(removeButton);
    box.add(Box.createHorizontalStrut(20));
    status = new JTextField("stateless member",12);
    status.setEditable(false);
    status.setBorder(BorderFactory.createLoweredBevelBorder());
    box.add(status);

    addButton.addActionListener(this);
    removeButton.addActionListener(this);
    return box;
  }

  public void actionPerformed(ActionEvent e)
  {
    Object obj = e.getSource();
    if (obj==addButton)
    {
      enableUserInteraction(false);
      stateChanger.addColour(this);
    }
    else if (obj==removeButton)
    {
      enableUserInteraction(false);
      stateChanger.remColour(this);
    }
  }

  void enableUserInteraction(final boolean enable)
  {
    SwingUtilities.invokeLater(new Runnable(){
        public void run()
        {
          addButton.setEnabled(enable);
          removeButton.setEnabled(enable);
        }
      });
  }

  StateChanger stateChanger;
  JTextField state, status;
  JButton addButton, removeButton;
  boolean withState;
  UIFrame uiFrame;
};
