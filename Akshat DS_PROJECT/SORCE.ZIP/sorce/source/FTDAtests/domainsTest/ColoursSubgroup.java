package ftdaTests.domainsTest;

interface ColoursSubgroup
{
  public void setIdentity(int id);
  public void setState(String substates[]);
  public int getId();
  public String getColour(int pos);
  public String getAColour();
  public void addColour(String colour) throws Exception;
  public void remColour() throws Exception;
};
