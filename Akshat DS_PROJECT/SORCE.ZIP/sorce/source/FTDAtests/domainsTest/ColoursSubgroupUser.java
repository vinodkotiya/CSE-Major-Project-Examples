package senseiTests.domainsTest;

interface ColoursSubgroupUser
{
  //just shows the current state
  public void changedState(int subgroup, String state);
};
