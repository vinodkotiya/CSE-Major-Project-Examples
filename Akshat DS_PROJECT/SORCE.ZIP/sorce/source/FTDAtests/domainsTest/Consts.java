package senseiTests.domainsTest;

class Consts
{
  public static final String AREA="StateTransferTester";
};
