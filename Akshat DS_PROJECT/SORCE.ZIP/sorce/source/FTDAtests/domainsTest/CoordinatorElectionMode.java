package senseiTests.domainsTest;

import sensei.middleware.domains.Property;

final public class CoordinatorElectionMode
{
    private static CoordinatorElectionMode [] values_ = new CoordinatorElectionMode[3];
    private int value_;

    public final static int _InfrastructureControlled = 0;
    public final static CoordinatorElectionMode InfrastructureControlled =
      new CoordinatorElectionMode(_InfrastructureControlled);
    public final static int _SelectedByWeights = 1;
    public final static CoordinatorElectionMode SelectedByWeights = new CoordinatorElectionMode(_SelectedByWeights);
    public final static int _SelectedByUser = 2;
    public final static CoordinatorElectionMode SelectedByUser = new CoordinatorElectionMode(_SelectedByUser);


    protected
    CoordinatorElectionMode(int value)
    {
        values_[value] = this;
        value_ = value;
    }

    public int
    value()
    {
        return value_;
    }

    public static CoordinatorElectionMode
    from_int(int value)
    {
        return values_[value];
    }
}
