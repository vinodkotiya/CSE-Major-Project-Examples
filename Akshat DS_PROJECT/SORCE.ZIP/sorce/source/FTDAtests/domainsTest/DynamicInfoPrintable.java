package senseiTests.domainsTest;

import senseiTests.middleware.domainsTest.StateTransferType;

interface DynamicInfoPrintable
{
  public void showCreatedDynamicGroup(int subgroupId, StateTransferType type, String info);

  public void showRemovedDynamicGroup(int subgroupId, String info);
};
