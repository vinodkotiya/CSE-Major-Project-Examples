package senseiTests.domainsTest;

import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;


class EditablePhasePanel extends PhasePanel implements ItemListener
{

  public EditablePhasePanel(String name, PhasePanelUser user)
  {
    super(name);
    this.user=user;
  }

  /**
   * maxPhases is not displayed, is used just to limit the number of items to be shown. Use 0 for default
   * behaviour
   */
  public void display(int phaseNumber, int maxPhases, boolean ended)
  {
    setMaxPhases(maxPhases);
    SwingThreadedChanger.setSelectedIndex(phaseTermination,ended? 0 : 1);
    display(phaseNumber);
    ((CardLayout)(selector.getLayout())).first(selector);
  }

  public boolean getPhaseTermination()
  {
    return phaseTermination.getSelectedIndex()==0;
  }

  /**
   * Implementation method, not intended to be directly public
   */
  public void itemStateChanged(ItemEvent e)
  {
    if (e.getStateChange()==ItemEvent.SELECTED)
      user.phaseChanged(((Integer) (e.getItem())).intValue());
  }


  JPanel createValidPanel(String name)
  {
    JPanel ret = super.createValidPanel(name);
    phaseTermination = new JComboBox(possibleStates);

    boxPhase.add(Box.createRigidArea(new Dimension(5,5)));
    boxPhase.add(new JLabel("ended: "));
    boxPhase.add(phaseTermination);

    phase.setEnabled(true);
    phase.addItemListener(this);

    return ret;
  }

  JComboBox phaseTermination;
  PhasePanelUser user;

  static final String[] possibleStates=new String[2];
  static
  {
    possibleStates[0]=new String("YES");
    possibleStates[1]=new String("NO");
  }

};
