package senseiTests.domainsTest;

import java.awt.CardLayout;
import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * Panel just showing a label for the field concept, and an uneditable edit component
 * for the field value. It includes the option to be disable (make unvisible) without
 * changing the component size
 */
class FieldPanel extends JPanel
{
  /**
   * Constructor
   */
  public FieldPanel(String concept, int columns)
  {
    super(new CardLayout());
    add(createValidPanel(concept, columns),"1");//string not used
    add(new JPanel(),"0");
  }

  public void makeUnvisible()
  {
    ((CardLayout) getLayout()).last(this);
  }

  public void makeVisible()
  {
    ((CardLayout) getLayout()).first(this);
  }

  public void displayIfVisible(String what)
  {
    SwingThreadedChanger.setText(value, what);
  }

  public void display(String what)
  {
    makeVisible();
    displayIfVisible(what);
  }

  private JPanel createValidPanel(String concept, int columns)
  {
    value = new JTextField(columns);
    value.setEditable(false);
    JPanel ret = new JPanel();
    Box boxPhase = Box.createHorizontalBox();
    boxPhase.add(new JLabel(concept));
    boxPhase.add(value);
    ret.add(boxPhase);
    return ret;
  }

  JTextField value;

};
