package senseiTests.domainsTest;

import senseiTests.middleware.domainsTest.MiddlewareInitialitation;
import sensei.util.ParameterException;
import sensei.util.Parameters;

public class Main
{
  public static void main(String args[]) throws Exception
  {
    try
    {
      Parameters parameters = Tester.readArgs(args);
      if (parameters!=null)
      {
        Runnable realMain = new Tester(parameters);
        MiddlewareInitialitation.init(realMain, args);
      }
    }
    catch(ParameterException pex)
    {
      System.out.println(pex);
    }
  }
}
