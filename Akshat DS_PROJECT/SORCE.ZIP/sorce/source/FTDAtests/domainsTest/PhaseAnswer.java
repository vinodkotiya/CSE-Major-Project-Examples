package senseiTests.domainsTest;

import senseiTests.middleware.domainsTest.ColourPhaseCoordination;

class PhaseAnswer
{
  PhaseAnswer()
  {
    phase=0;
    finished=false;
  }

  PhaseAnswer(int phase, boolean finished)
  {
    this.phase=phase;
    this.finished=finished;
  }

  void set(int phase, boolean finished)
  {
    this.phase=phase;
    this.finished=finished;
  }

  void convert(ColourPhaseCoordination phase, int maxPhases, boolean incNextPhase)
  {
    phase.phase=this.phase;
    phase.numPhases=maxPhases;
    phase.transferFinished=finished;
    if (incNextPhase)
    {
      phase.nextPhase=phase.phase+1;
      if (phase.nextPhase>=maxPhases)
        phase.nextPhase=maxPhases-1;
    }
    else
      phase.nextPhase=phase.phase;
  }

  void convert(ColourPhaseCoordination phase)
  {
    phase.phase=this.phase;
    phase.transferFinished=finished;
    phase.nextPhase=phase.phase;
  }
  int phase;
  boolean finished;
};
