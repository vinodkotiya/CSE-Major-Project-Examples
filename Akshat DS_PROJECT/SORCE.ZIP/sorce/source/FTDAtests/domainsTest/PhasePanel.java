package senseiTests.domainsTest;

import java.awt.FlowLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;



class PhasePanel extends JPanel
{
  public PhasePanel(String name)
  {
    super(new FlowLayout());
    selector = new JPanel(new CardLayout());
    add(selector);
    this.maxPhases=0;
    selector.add(createValidPanel(name),"1");//string not used
    selector.add(new JPanel(),"0");
    disable();
  }

  public void makeUnvisible()
  {
    ((CardLayout)(selector.getLayout())).last(selector);
  }

  /**
   * maxPhases is not displayed, is used just to limit the number of items to be shown. Use 0 for default
   * behaviour
   */
  public void display(int phaseNumber)
  {
    int input=(phaseNumber<0)? 0 : (phaseNumber>=maxPhases)? maxPhases-1 : phaseNumber;
    SwingThreadedChanger.setSelectedIndex(phase,input);
    ((CardLayout)(selector.getLayout())).first(selector);
  }

  JPanel createValidPanel(String name)
  {

    phase = new JComboBox();

    JPanel ret = new JPanel();
    boxPhase = Box.createHorizontalBox();
    boxPhase.add(new JLabel("number: "));
    boxPhase.add(phase);
    ret.add(boxPhase);
    ret.setBorder(BorderFactory.createTitledBorder(name));

    phase.setEnabled(false);
    setMaxPhases(MAXNUMPHASES);

    return ret;
  }

  /**
   * NumPhases must be in [1..MAXNUMPHASES], otherwise MAXNUMPHASES is assumed
   */
  public void setMaxPhases(int numPhases)
  {
    int input = ((numPhases>0) && (numPhases<MAXNUMPHASES)? numPhases : MAXNUMPHASES);
    while(input>maxPhases)
      phase.addItem(numbers[maxPhases++]);
    while(input<maxPhases)
      phase.removeItem(numbers[--maxPhases]);
  }

  /**
   * Returns the current phase
   */
  public int getPhase()
  {
    return phase.getSelectedIndex();
  }

  JPanel selector;
  JComboBox phase;
  Box boxPhase;
  int maxPhases;

  static public final int MAXNUMPHASES=25;
  static final Integer[] numbers=new Integer[MAXNUMPHASES];
  static
  {
    for(int i=0;i<MAXNUMPHASES;i++)
      numbers[i]=new Integer(i);
  }

};
