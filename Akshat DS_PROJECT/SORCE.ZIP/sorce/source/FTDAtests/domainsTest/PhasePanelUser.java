package senseiTests.domainsTest;

interface PhasePanelUser
{
  public void phaseChanged(int phase);
};
