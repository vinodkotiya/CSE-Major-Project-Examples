package senseiTests.domainsTest;

import sensei.middleware.domains.Property;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.DefaultMutableTreeNode;

import java.util.Iterator;
import java.util.TreeSet;

import sensei.util.IntWrapper;

class PropertiesPanel extends JPanel
{
  public PropertiesPanel()
  {
    super(new BorderLayout());
    setBorder(BorderFactory.createTitledBorder("Properties info"));
    propertiesKnown=false;
    init();
  }

  public void clearProperties()
  {
    ((CardLayout)(cardPanel.getLayout())).last(cardPanel);
    propertiesKnown=false;
    root.removeAllChildren();
    treeModel.nodeStructureChanged(root);
  }

  public void setProperties(int member, Property[] properties)
  {
    if (!propertiesKnown)
    {
      propertiesKnown=true;
      ((CardLayout)(cardPanel.getLayout())).first(cardPanel);
    }
    Node memberNode = findMember(member);
    if (memberNode==null)
    {
      memberNode = new Node(member);
      treeModel.insertNodeInto(memberNode, root, findMemberPosition(member));
    }
    else
    {
      memberNode.removeAllChildren();
      treeModel.nodeStructureChanged(memberNode);
    }

    setProperties(memberNode, properties);
  }

  void setProperties(Node node, Property[] properties)
  {
    int size = properties.length;
    TreeSet sortedProperties = new TreeSet();
    while(size-->0)
    {
      Property prop = properties[size];
      sortedProperties.add(prop.nam+ " = " + prop.val);
    }
    Iterator it = sortedProperties.iterator();
    while(it.hasNext())
    {
      Node toInsert = new Node((String)(it.next()));
      treeModel.insertNodeInto(toInsert, node, ++size);
    }
  }

  public Dimension getPreferredSize()
  {
    return new Dimension(250, 150);
  }

  JPanel createDataPanel()
  {
    JPanel ret = new JPanel(new BorderLayout());
    root   = new Node(0);
    treeModel = new DefaultTreeModel(root, true);
    JTree tree = new JTree(treeModel);
    tree.setRootVisible(false);

    //Create the scroll pane and add the tree to it.
    JScrollPane treeView = new JScrollPane(tree);
    ret.add(treeView, BorderLayout.CENTER);
    ret.setBorder(BorderFactory.createEtchedBorder());
    return ret;
  }

  JPanel createEmptyPanel()
  {
    JPanel ret = new JPanel(new BorderLayout());
    ret.add(new JLabel("Without knowledge yet", SwingConstants.CENTER), BorderLayout.CENTER);
    return ret;
  }

  void init()
  {
    cardPanel = new JPanel(new CardLayout());
    cardPanel.add(createDataPanel(),"1");//string not used
    cardPanel.add(createEmptyPanel(),"0");
    clearProperties();
    add(cardPanel, BorderLayout.CENTER);
  }

  //*************************************************************************************
  //**************************** SUPPORT CLASS ******************************************
  //*************************************************************************************

  class Node extends DefaultMutableTreeNode
  {
    public int id;
    public Node(String Property)
    {
      super(Property, false);
      id=0;
    }
    public Node(int id)
    {
      super(String.valueOf(id), true);
      this.id=id;
    }
    public Object clone()
    {
      Node n = (Node) super.clone();
      n.id=id;
      return n;
    }
  }

//*************************************************************************************//
//**************************** FIND MEMBER POSITION ***********************************//
//*************************************************************************************//

  /**
    * Finds the member position to insert a member.
    **/
  int findMemberPosition(int memberId)
  {
    int len = root.getChildCount();
    for (int i=0; i<len ; i++)
    {
      Node member = (Node) root.getChildAt(i);
      if (memberId < member.id)
        return i;
    }
    return len;
  }


//*************************************************************************************//
//**************************** FIND MEMBER ********************************************//
//*************************************************************************************//

  /**
    * Finds a member in the tree
    **/
  Node findMember(int id)
  {
    int len = root.getChildCount();
    for (int i=0; i<len ; i++)
    {
      Node member = (Node) root.getChildAt(i);
      if (member.id==id)
        return member;
    }
    return null;
  }


  //*************************************************************************************
  //**************************** DATA MEMEBRS *******************************************
  //*************************************************************************************

  JPanel cardPanel;
  boolean propertiesKnown;

  DefaultMutableTreeNode root;
  DefaultTreeModel treeModel;

};
