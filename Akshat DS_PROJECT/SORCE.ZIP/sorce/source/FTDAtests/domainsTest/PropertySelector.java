package senseiTests.domainsTest;

import sensei.middleware.domains.Property;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.util.Map;
import java.util.TreeMap;

class PropertySelector extends JDialog  implements ActionListener
{
  public PropertySelector(Property[] props, JFrame owner, String title, String name, String value, boolean add,
    boolean allowCancel)
  {
    super(owner, title, true);
    this.allowCancel=false;
    convertToMap(props);
    init(name, value, add, allowCancel, properties.keySet().toArray());
    pack();
    setLocation(owner.getLocation());
  }

  Property getInput()
  {
    pressedOk=false;
    show();
    Property ret;
    if (pressedOk || (!allowCancel))
    {
      String name = (String)(names.getSelectedItem());
      String val = (String)(value.getText());
      ret=new Property(name, val);
    }
    else
      ret=null;
    return ret;
  }

  void init(String nameField, String valueField, boolean add, boolean allowCancel, Object [] props)
  {
    JPanel total = new JPanel(new BorderLayout());
    JPanel twoLines = new JPanel(new GridLayout(0,1,5,5));
    JPanel buttons = new JPanel(new BorderLayout());

    JPanel labelPlusField = new JPanel(new BorderLayout());
    names = new JComboBox(props);
    names.addActionListener(this);
    labelPlusField.add(new JLabel(nameField+": "), BorderLayout.WEST);
    labelPlusField.add(names, BorderLayout.CENTER);
    twoLines.add(labelPlusField);

    labelPlusField = new JPanel(new BorderLayout());
    value = new JTextField();
    labelPlusField.add(new JLabel(valueField+": "), BorderLayout.WEST);
    labelPlusField.add(value, BorderLayout.CENTER);
    twoLines.add(labelPlusField);

    twoLines.setBorder(BorderFactory.createTitledBorder("Property"));

    okButton = new JButton("Ok");
    okButton.setMnemonic(KeyEvent.VK_O);
    okButton.addActionListener(this);
    if (allowCancel)
    {
      cancelButton = new JButton("Cancel");
      cancelButton.setMnemonic(KeyEvent.VK_C);
      cancelButton.addActionListener(this);
      JPanel okCancel = new JPanel(new GridLayout(1,0,5,5));
      okCancel.add(okButton);
      okCancel.add(cancelButton);
      buttons.add(okCancel, BorderLayout.EAST);
    }
    else
    {
      buttons.add(okButton, BorderLayout.NORTH);
    }

    total.add(twoLines, BorderLayout.NORTH);
    total.add(buttons, BorderLayout.SOUTH);
    getContentPane().add(total, BorderLayout.NORTH);

    names.setEditable(add);
    value.setEditable(add);

    changedSelection();
  }

  void convertToMap(Property[] props)
  {
    properties = new TreeMap();
    int size = props.length;
    while(size-->0)
      properties.put(props[size].nam, props[size].val);
  }

  public void actionPerformed(ActionEvent e)
  {
    Object obj = e.getSource();
    if (obj==names)
      changedSelection();
    else if (obj==okButton)
    {
      pressedOk=true;
      dispose();
    }
    else if (obj==cancelButton)
      dispose();
  }

  void changedSelection()
  {
    String name = (String)(names.getSelectedItem());
    String val = (String) (properties.get(name));
    value.setText(val==null? "" : val);
  }

  Map properties;
  JButton okButton, cancelButton;
  JComboBox names;
  JTextField value;
  boolean pressedOk, allowCancel;
};
