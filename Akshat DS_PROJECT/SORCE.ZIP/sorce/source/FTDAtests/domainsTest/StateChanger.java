package senseiTests.domainsTest;

import sensei.middleware.domains.DomainGroupHandler;
import sensei.util.RestartableThread;

public class StateChanger extends RestartableThread
{
  class Info
  {
    ColoursInfoPanel panel;
    boolean add;
    Info(ColoursInfoPanel panel, boolean add) { this.panel=panel; this.add=add;}
  }

  public StateChanger(DomainGroupHandler groupHandler, ColoursSubgroup coloursSubgroup)
  {
    this.coloursSubgroup=coloursSubgroup;
    this.groupHandler=groupHandler;
  }

  public boolean addColour(ColoursInfoPanel panel)
  {
    try
    {
      activate(0, new Info(panel, true));
      return true;
    }
    catch(InterruptedException ex)
    {
    }
    return false;
  }

  public boolean remColour(ColoursInfoPanel panel)
  {
    try
    {
      activate(0, new Info(panel, false));
      return true;
    }
    catch(InterruptedException ex)
    {
    }
    return false;
  }

  public boolean activated(Object task)
  {
    Info info = (Info) task;
    try
    {
      if (info.add)
      {
        String toAdd = coloursSubgroup.getAColour();
        info.panel.setStatus("Adding colour " + toAdd);
        coloursSubgroup.addColour(toAdd);
      }
      else
      {
        info.panel.setStatus("Removing a colour");
        coloursSubgroup.remColour();
      }
      info.panel.colourChangePropagated();
    }
    catch(Exception ex)
    {
      info.panel.showError(ex);
      return false;
    }
    return true;
  }

  ColoursSubgroup coloursSubgroup;
  DomainGroupHandler groupHandler;
}
