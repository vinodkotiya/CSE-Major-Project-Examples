package senseiTests.domainsTest;

interface StateTransferAnswerer
{
  //shows the assume state event
  public void onAssumeState(ColoursSubgroup subgroup);

  //shows the current sync_transfer process, requesting the new phase coordination
  public PhaseAnswer onSyncTranfer(ColoursSubgroup subgroup, int coordinator, int phase);

  //shows the current interrupt_transfer process, requesting the new phase coordination
  public PhaseAnswer onInterruptTransfer(ColoursSubgroup subgroup, int phase);

  //shows the current continue_transfer process, requesting the new phase coordination
  public PhaseAnswer onContinueTransfer(ColoursSubgroup subgroup, int joiningMember, int phase, int joiningPhase, int maxPhases);

  //shows the current start_transfer process, requesting the new phase coordination
  public PhaseAnswer onStartTransfer(ColoursSubgroup subgroup, int joiningMember, int phase, int maxPhases);

  //shows the current get_state process, requesting the new phase coordination and the state
  public PhaseAnswer onGetState(ColoursSubgroup subgroup, int phase, int maxPhases);

  //shows the current set_state process
  public void onSetState(ColoursSubgroup subgroup, String subState, int phase);

  //shows the current get_state process, on a one-step process
  public void onGetState(ColoursSubgroup subgroup);

  //shows the current set_state process, on a one-step process
  public void onSetState(ColoursSubgroup subgroup, String subState);

  //shows the current stop_transfer process
  public void onStopTransfer(ColoursSubgroup subgroup, int joiningMember, boolean transferFinished);
};
