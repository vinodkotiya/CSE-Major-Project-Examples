package senseiTests.domainsTest;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

import senseiTests.middleware.domainsTest.StateTransferType;

class StateTransferInfoListingPanel extends JPanel implements TransferInfoPrintable, DynamicInfoPrintable
{
  public StateTransferInfoListingPanel()
  {
    super(new BorderLayout());
    init();
  }

  public void clear()
  {
    SwingThreadedChanger.setText(textArea,"");
  }

  public void showCreatedDynamicGroup(int subgroupId, StateTransferType type, String info)
  {
    print("Created dynamic group ["+subgroupId+"]; type="+StateTransferTypeConverter.asString(type)+"; info="+info);
  }

  public void showRemovedDynamicGroup(int subgroupId, String info)
  {
    print("Removed dynamic group ["+subgroupId+"]; info="+info);
  }

  public void showAssumeState(int subgroupId)
  {
    print("AssumeState ["+subgroupId+"]");
  }

  public void showSyncTransferFields(int subgroupId, int coordinator, int inPhase, int outPhase, boolean outPhaseEnded)
  {
    print("SyncTransfer ["+subgroupId+"] coordinator="+coordinator+", phase="+inPhase);
  }

  public void showStartTransferFields(int subgroupId, int coordinated, int inPhase, int maxPhases,
    int outPhase, boolean outPhaseEnded)
  {
    print("StartTransfer["+subgroupId+"] coord.="+coordinated+", phase="+inPhase+ ", maxPhases="+maxPhases);
  }

  public void showGetStateFields(int subgroupId, int inPhase, int maxPhases, int outPhase, boolean outPhaseEnded)
  {
    print("GetState["+subgroupId+"] phase="+inPhase+ ", maxPhases="+maxPhases);
  }

  public void showSetStateFields(int subgroupId, String substate, int inPhase)
  {
    print("SetState["+subgroupId+"] phase="+inPhase+ ", substate="+substate);
  }

  public void showGetStateFields(int subgroupId)
  {
    print("GetState["+subgroupId+"]");
  }

  public void showSetStateFields(int subgroupId, String substate)
  {
    print("SetState["+subgroupId+"] , state="+substate);
  }

  public void showStopTransferFields(int subgroupId, int member, boolean transferEnded)
  {
    print("StopTransfer["+subgroupId+"] member="+member+", transfer ended="+transferEnded);
  }

  public void showInterruptTransferFields(int subgroupId, int inPhase, int maxPhases, int outPhase,
    boolean outPhaseEnded)
  {
    print("InterruptTransfer["+subgroupId+"] phase="+inPhase+ ", maxPhases="+maxPhases);
  }

  public void showContinueTransferFields(int subgroupId, int member, int inPhase, int maxPhases, int clientPhase,
    int outPhase, boolean outPhaseEnded)
  {
    print("ContinueTransfer["+subgroupId+"] phase="+inPhase+ ", maxPhases="+maxPhases+", client phase=" +
      clientPhase + ", member=" + member);
  }

  public void showCoordinatorElector(int target, int coordinator)
  {
    print("*** Coordinato elector for member " + target + " is " + coordinator);
  }

  void print(String s)
  {
    SwingThreadedChanger.addText(textArea,s);
  }

  void init()
  {
    this.setBorder(BorderFactory.createTitledBorder("State Transfer Events"));
    textArea = new JTextArea(5, 30);
    JScrollPane scrollPane = new JScrollPane(textArea);
    setPreferredSize(new Dimension(150, 100));
    add(scrollPane, BorderLayout.CENTER);
  }

  JTextArea textArea;
};
