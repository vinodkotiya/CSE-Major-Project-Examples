package senseiTests.domainsTest;

interface StateTransferInfoPanelUser
{
  /**
   * called when the confirm button is pressed. Cannot be called after makeUnvisible()
   */
  public void confirmed(int phase, boolean finished);

  /**
   * Informs that the phase has changed. The associated substring should be returned, or null if it's not valid
   * or displayable
   */
  public String phaseChanged(int phase);

  static public final int MAX_NUM_PHASES=PhasePanel.MAXNUMPHASES;
};
