package senseiTests.domainsTest;

import senseiTests.middleware.domainsTest.StateTransferType;

class StateTransferTypeConverter
{
  static public String[] getTypeAsStringArray(){return transferTypes;}

  static public StateTransferType getType(int index){return StateTransferType.from_int(index);}

  static public String asString(StateTransferType type){return transferTypes[type.value()];}

  static String[] transferTypes;
  static
  {
    transferTypes = new String[5];
    transferTypes[0] = "State Handler";
    transferTypes[1] = "Basic State Handler";
    transferTypes[2] = "Extended Checkpointable";
    transferTypes[3] = "Checkpointable";
    transferTypes[4] = "No state transfer support";
  }
};
