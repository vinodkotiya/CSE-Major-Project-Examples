package senseiTests.domainsTest;

import senseiTests.middleware.domainsTest.StateTransferType;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.util.Map;
import java.util.TreeMap;

class SubgroupRequester extends JDialog  implements ActionListener
{
  public SubgroupRequester(JFrame owner, int id)
  {
    this(owner, id, null);
  }

  public SubgroupRequester(JFrame owner, String state)
  {
    this(owner, 0, state);
  }

  SubgroupRequester(JFrame owner, int id, String state)
  {
    super(owner, "Create subgroup", true);
    init(id, state);
    pack();
    setLocation(owner.getLocation());
  }

  boolean getInput()
  {
    pressedOk=false;
    show();
    return pressedOk;
  }

  StateTransferType getType()
  {
    return StateTransferTypeConverter.getType(types.getSelectedIndex());
  }

  int getId()
  {
    return subgroupId;
  }

  boolean getWait()
  {
    return booleanOptions.getSelectedIndex()==0;
  }

  void init(int id, String state)
  {
    JPanel total = new JPanel(new BorderLayout());
    JPanel twoLines = new JPanel(new GridLayout(0,1,5,5));
    JPanel buttons = new JPanel(new BorderLayout());

    JPanel labelPlusField = new JPanel(new BorderLayout());
    if (state==null)
    {
      subgroup= new JTextField(5);
      labelPlusField.add(new JLabel("Subgroup Id: "), BorderLayout.WEST);
      labelPlusField.add(subgroup, BorderLayout.CENTER);
      subgroup.setText(String.valueOf(id));
      twoLines.add(labelPlusField);
    }
    else
    {
      labelPlusField.add(new JLabel("State: "+state, SwingConstants.CENTER), BorderLayout.CENTER);
      twoLines.add(labelPlusField);
    }

    types = new JComboBox(StateTransferTypeConverter.getTypeAsStringArray());
    labelPlusField = new JPanel(new BorderLayout());
    labelPlusField.add(new JLabel("Transfer type: "), BorderLayout.WEST);
    labelPlusField.add(types, BorderLayout.CENTER);
    if (state==null)
      twoLines.add(labelPlusField);
    else
    {
      booleanOptions = new JComboBox(booleanValues);
      JPanel waitPanel = new JPanel();
      waitPanel.add(labelPlusField);
      waitPanel.add(new JLabel(" Wait: "));
      waitPanel.add(booleanOptions);
      twoLines.add(waitPanel);
    }

    twoLines.setBorder(BorderFactory.createTitledBorder("Subgroup properties"));

    okButton = new JButton("Ok");
    okButton.setMnemonic(KeyEvent.VK_O);
    okButton.addActionListener(this);
    cancelButton = new JButton("Cancel");
    cancelButton.setMnemonic(KeyEvent.VK_C);
    cancelButton.addActionListener(this);
    JPanel okCancel = new JPanel(new GridLayout(1,0,5,5));
    okCancel.add(okButton);
    okCancel.add(cancelButton);
    buttons.add(okCancel, BorderLayout.EAST);

    total.add(twoLines, BorderLayout.NORTH);
    total.add(buttons, BorderLayout.SOUTH);
    getContentPane().add(total, BorderLayout.NORTH);
  }

  public void actionPerformed(ActionEvent e)
  {
    Object obj = e.getSource();
    if (obj==okButton)
    {
      if (checkSubgroup())
      {
        pressedOk=true;
        dispose();
      }
    }
    else if (obj==cancelButton)
      dispose();
  }

  boolean checkSubgroup()
  {
    boolean ret;
    if (subgroup==null)
      ret=true;
    else
    {
      try
      {
        subgroupId = Integer.valueOf(subgroup.getText()).intValue();
        ret= subgroupId>0;
      }
      catch(Exception ex)
      {
        ret=false;
      }
      if (!ret)
        JOptionPane.showMessageDialog(this, "The subgroupId is not valid");
    }
    return ret;
  }

  static String[] booleanValues;
  static
  {
    booleanValues = new String[2];
    booleanValues[0] = "Yes";
    booleanValues[1] = "No";
  }
  JButton okButton, cancelButton;
  JComboBox types, booleanOptions;
  JTextField subgroup;
  int subgroupId;
  boolean pressedOk;
};
