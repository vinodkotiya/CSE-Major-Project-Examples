package senseiTests.domainsTest;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JTextArea;
import javax.swing.text.JTextComponent;
import javax.swing.SwingUtilities;

class SwingThreadedChanger
{
  public static void setText(final JTextComponent component, final String text)
  {
    SwingUtilities.invokeLater(new Runnable(){
        public void run()
        {
          component.setText(text);
        }
      });
  }

  public static void setSelectedIndex(final JComboBox combo, final int index)
  {
    SwingUtilities.invokeLater(new Runnable(){
        public void run()
        {
          combo.setSelectedIndex(index);
        }
      });
  }

  public static void addText(final JTextArea component, final String text)
  {
    int pos=component.getDocument().getLength();
    if (pos>0)
      component.append("\n"+text);
    else
      component.append(text);
    component.setSelectionStart(pos);
    component.setSelectionEnd(pos);
  }
};
