package senseiTests.domainsTest;

import sensei.middleware.domains.CoordinatorElectorBaseImpl;
import sensei.middleware.domains.CoordinatorInformation;
import sensei.middleware.domains.DomainGroupHandler;
import sensei.middleware.domains.MemberProperties;
import sensei.middleware.domains.Property;

//import sensei.util.Debug;

class TestCoordinatorElector extends CoordinatorElectorBaseImpl
{
  public TestCoordinatorElector(boolean useWeights, DomainGroupHandler domainGroup,
    UIFrame display) throws Exception
  {
    this.useWeights=useWeights;
    this.domainGroup=domainGroup;
    this.display=display;
  }

  public void changeToUseWeights(boolean set)
  {
    useWeights=set;
  }

  public int getCoordinator(int loc, CoordinatorInformation[] info)
  {
    int ret = useWeights?  getCoordinatorByWeights(loc, info) : getCoordinatorByUser(loc, info);
    display.showCoordinatorElector(loc, ret);
    return ret;
  }

  int getCoordinatorByUser(int loc, CoordinatorInformation[] info)
  {
    try
    {
      MemberProperties[] properties=null;
      if (domainGroup.arePropertiesEnabled())
        properties = domainGroup.getPropertyForAllMembers(NAME);
      int length = info.length;
      Property []props = new Property[length];
      for (int i=0; i < length; i++)
        props[i]=new Property(getMemberId(info[i].statusMember, properties), String.valueOf(info[i].currentCoordinations.length));
      Property input = new PropertySelector(props, display, "Select coordinator", "Member", "Coordinations",
         false, false).getInput();
      return extractMember(input.nam);
    }
    catch(Exception ex)
    {
      display.showError(ex);
    }
    return 0;
  }

  String getMemberId(int member, MemberProperties[] props)
  {
    StringBuffer buf = new StringBuffer(String.valueOf(member));
    if (props!=null)
    {
      String name = getName(member, props);
      if (name!=null)
        buf.append(" (").append(name).append(")");
    }
    return buf.toString();
  }

  int extractMember(String memberId)
  {
    int name=memberId.indexOf(' ');
    if (name==-1)
      return Integer.valueOf(memberId).intValue();
    else
      return Integer.valueOf(memberId.substring(0, name)).intValue();
  }

  int getCoordinatorByWeights(int loc, CoordinatorInformation[] info)
  {
    try
    {
      MemberProperties[] props = domainGroup.getPropertyForAllMembers(WEIGHT);
      int statusMember=info[0].statusMember;
      double value=Double.MIN_VALUE;
      int length = info.length;
      for(int i=0; i < length; i++)
      {
        double itsValue=getWeight(info[i].statusMember, props)/(info.length+1);
        if (itsValue>value)
        {
          value=itsValue;
          statusMember=info[i].statusMember;
        }
      }
      return statusMember;
    }
    catch(Exception ex)
    {
      display.showError(ex);
    }
    return 0;
  }

  double getWeight(int member, MemberProperties []props)
  {
    try
    {
      String property=getProperty(member, props);
      if (property!=null)
        return Double.valueOf(property).doubleValue();
    }
    catch(Exception ex)
    {
    }
    return 0;
  }

  String getName(int member, MemberProperties []props)
  {
    return getProperty(member, props);
  }

  String getProperty(int member, MemberProperties []props)
  {
    int i = props.length;
    while(i-->0)
    {
      MemberProperties prop = props[i];
      if (prop.member==member)
      {
        //Debug.assert(prop.props.length==1, Consts.AREA, "TestCoordinatorElector::GetProperty::1");
        return prop.props[0].val;
      }
    }
    return null;
  }


  final static String WEIGHT="weight";
  final static String NAME="name";
  boolean useWeights;
  DomainGroupHandler domainGroup;
  UIFrame display;
}
