package senseiTests.domainsTest;

import sensei.middleware.domains.DomainGroupUserBaseImpl;
import sensei.middleware.domains.DomainExpulsionReason;

class TesterDomainGroupUser extends DomainGroupUserBaseImpl
{
  public TesterDomainGroupUser(Tester center, UIFrame display, TesterPropertiesUser propertiesUser) throws Exception
  {
    this.center=center;
    this.display = display;
    this.propertiesUser = propertiesUser;
  }

  public void domainAccepted(int id)
  {
    display.joined(id);
  }

  public void domainExpulsed(DomainExpulsionReason reason)
  {
    StringBuffer str = new StringBuffer("Member excluded from the group");
    if (reason!=DomainExpulsionReason.GMSLeaveEvent)
      if (reason==DomainExpulsionReason.WrongPropertyAllowance)
        str.append(": properties policy collision");
      else if (reason==DomainExpulsionReason.WrongStaticSubgroupsComposition)
        str.append(": static subgroups composition collision");
      else if (reason==DomainExpulsionReason.WrongCoordinatorElectionPolicy)
        str.append(": coordinator election policy collision");
      else if (reason==DomainExpulsionReason.WrongBehaviourMode)
        str.append(": behavior mode collision");
      else if (reason==DomainExpulsionReason.WrongDynamicPolicy)
        str.append(": dynamic subgroups policy collision");
      else if (reason==DomainExpulsionReason.WrongSubgroupsTypes)
        str.append(": created dynamic group does not match the expected type");
      else
        str.append(": unknown reason!!!"+reason.value());
    display.showError(str.toString());
    center.reset();
  }

  public void stateObtained(boolean t)
  {
    display.stateTransfered();
    propertiesUser.updateProperties();
  }

  public void offendingSubgroup(int subgroup, String reason)
  {
    display.showError("Subgroup " + subgroup + " has STRANGELY commited the following error: " + reason);
  }

  Tester center;
  UIFrame display;
  TesterPropertiesUser propertiesUser;
}
