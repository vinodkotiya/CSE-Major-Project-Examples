package senseiTests.domainsTest;

import senseiTests.middleware.domainsTest.ColoursStates;
import senseiTests.middleware.domainsTest.ColourDynamicSubgroupInfo;
import senseiTests.middleware.domainsTest.StateTransferType;
import sensei.middleware.gms.GroupMember;
import sensei.middleware.domains.DynamicSubgroupInfo;
import sensei.middleware.domains.DynamicSubgroupInfoAsString;
import sensei.middleware.domains.DynamicSubgroupsUserBaseImpl;
import sensei.middleware.domains.State;

class TesterDynamicsGroupsUser extends DynamicSubgroupsUserBaseImpl
{
  public TesterDynamicsGroupsUser(Tester center, UIFrame display) throws Exception
  {
    this.center=center;
    this.display = display;
  }

  public GroupMember acceptSubgroup(int id, DynamicSubgroupInfo dinfo)
  {
    ColourDynamicSubgroupInfo info = (ColourDynamicSubgroupInfo) dinfo;
    display.showCreatedDynamicGroup(id, info.transferType, info.info);
    return center.subgroupCreated(id, info.transferType, null);
  }

  public GroupMember subgroupCreated(int creator, int id, DynamicSubgroupInfo dinfo)
  {
    ColourDynamicSubgroupInfo info = (ColourDynamicSubgroupInfo) dinfo;
    display.showCreatedDynamicGroup(id, info.transferType, info.info);
    return center.subgroupCreated(id,info.transferType, info.initialState.chain);
  }

  public void subgroupRemoved(int remover, int id, DynamicSubgroupInfo info)
  {
    display.showRemovedDynamicGroup(id, ((DynamicSubgroupInfoAsString)info).info);
    display.removeColourPanel(id);
  }

  Tester center;
  UIFrame display;
}
