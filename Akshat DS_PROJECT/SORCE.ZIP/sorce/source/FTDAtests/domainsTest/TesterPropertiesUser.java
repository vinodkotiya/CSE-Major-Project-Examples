package senseiTests.domainsTest;

import sensei.middleware.domains.DomainGroupHandler;
import sensei.middleware.domains.MemberStateException;
import sensei.middleware.domains.PropertiesDisabledException;
import sensei.middleware.domains.PropertiesListenerBaseImpl;
import sensei.middleware.domains.Property;

//import sensei.util.Debug;

import java.util.Iterator;
import java.util.Map;

class TesterPropertiesUser extends PropertiesListenerBaseImpl implements UIPropertiesUser
{
  public TesterPropertiesUser(DomainGroupHandler domainGroup, Map properties) throws Exception
  {
    this.domainGroup = domainGroup;
    this.display = null;
    useProperties = false;
    changedProps=null;

    int length=properties.size();
    if (length>0)
    {
      enableProperties();
      Property [] initialProps = new Property[length];
      Iterator it = properties.entrySet().iterator();
      while(it.hasNext())
      {
        //Debug.assert(length>0, Consts.AREA, "TesterPropertiesUser::TesterPropertiesUser::1");
        Map.Entry entry = (Map.Entry)(it.next());
        initialProps[--length]=new Property((String)(entry.getKey()), (String)(entry.getValue()));
      }
      //Debug.assert(length==0, Consts.AREA, "TesterPropertiesUser::TesterPropertiesUser::2");
      domainGroup.setProperties(initialProps);
    }
    changedProps=new Property[1];
  }

  public void setDisplay(UIFrame display)
  {
    this.display = display;
  }

  public void propertiesUpdated (int loc)
  {
    if ((display!=null) && useProperties)
      try
      {
        Property [] props = domainGroup.getMemberProperties(loc);
        display.setProperties(loc, props);
      }
      catch (Exception mse)
      {
        display.showError(mse);
      }
  }

  public void enableProperties()
  {
    try
    {
      domainGroup.enableProperties();
      useProperties=true;
    }
    catch(Exception ex)
    {
      if (display!=null)
        display.showError(ex);
    }
  }

  public void updatePropertiesAutomatically(boolean set, boolean alreadyJoined)
  {
    try
    {
      if (set)
      {
        domainGroup.setPropertiesListener(this.thePropertiesListener());
        if (alreadyJoined && (display!=null))
          updateProperties();
      }
      else
        domainGroup.setPropertiesListener(null);
    }
    catch(PropertiesDisabledException ex)
    {
      if (alreadyJoined && (display!=null))
        display.showError(ex);
    }
    catch(Exception ex)
    {
      if (display!=null)
        display.showError(ex);
    }
  }

  public Property[] getProperties()
  {
    Property[] ret=null;
    try
    {
      ret=domainGroup.getProperties();
    }
    catch(Exception pde)
    {
      if (display!=null)
        display.showError(pde);
    }
    return ret;
  }

  public void addProperty(Property prop)
  {
    changedProps[0]=prop;
    try
    {
      domainGroup.addProperties(changedProps);
    }
    catch(Exception ex)
    {
      if (display!=null)
        display.showError(ex);
    }
  }

  public void removeProperty(Property prop)
  {
    changedProps[0]=prop;
    try
    {
      domainGroup.removeProperties(changedProps);
    }
    catch(Exception igex)
    {
      display.showError(igex);
    }
  }

  public void updateProperties()
  {
    display.clearProperties();
    try
    {
      int members[]=domainGroup.getStatefulMembers();
      int size=members.length;
      while(size-->0)
        propertiesUpdated(members[size]);
    }
    catch(Exception ex)
    {
      display.showError(ex);
    }
  }

  DomainGroupHandler domainGroup;
  UIFrame display;
  Property[] changedProps;
  boolean useProperties;
}
