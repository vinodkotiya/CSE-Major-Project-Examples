package senseiTests.domainsTest;

interface TransferInfoPrintable
{
  public void showAssumeState(int subgroupId);

  public void showSyncTransferFields(int subgroupId, int coordinator, int inPhase, int outPhase, boolean outPhaseEnded);

  public void showStartTransferFields(int subgroupId, int coordinated, int inPhase, int maxPhases,
    int outPhase, boolean outPhaseEnded);

  public void showGetStateFields(int subgroupId, int inPhase, int maxPhases, int outPhase, boolean outPhaseEnded);

  public void showSetStateFields(int subgroupId, String substate, int inPhase);

  public void showGetStateFields(int subgroupId);

  public void showSetStateFields(int subgroupId, String substate);

  public void showStopTransferFields(int subgroupId, int member, boolean transferEnded);

  public void showInterruptTransferFields(int subgroupId, int inPhase, int maxPhases, int outPhase,
    boolean outPhaseEnded);

  public void showContinueTransferFields(int subgroupId, int member, int inPhase, int maxPhases, int clientPhase,
    int outPhase, boolean outPhaseEnded);
};
