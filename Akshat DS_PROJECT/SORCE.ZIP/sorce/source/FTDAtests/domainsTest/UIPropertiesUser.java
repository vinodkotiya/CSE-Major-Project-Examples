package senseiTests.domainsTest;

import sensei.middleware.domains.Property;

interface UIPropertiesUser
{
  public Property[] getProperties();
  public void addProperty(Property prop);
  public void removeProperty(Property prop);
  public void updateProperties();
  public void updatePropertiesAutomatically(boolean set, boolean alreadyJoined);
  public void enableProperties();
}
