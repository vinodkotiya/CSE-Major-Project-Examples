package senseiTests.domainsTest;

import sensei.middleware.domains.BehaviourOnViewChanges;
import senseiTests.middleware.domainsTest.StateTransferType;

interface UIUser
{
  public boolean doJoin(BehaviourOnViewChanges behaviour, CoordinatorElectionMode ceMode, boolean dynamicSubgroups);
  public void doLeave();
  public void doCreateSubgroup(int id, StateTransferType type);
  public void doRemoveSubgroup(int id);
  public void doCreateDynamicSubgroup(String initialStates[], StateTransferType type, boolean block);
  public void changedCoordinatorElection(boolean toWeights); //only after join!
  public void onExit();
}
