package ftdaTests.middleware.domainsTest;

import ftda.middleware.domains.DomainMessage;

public class AddColourMessage extends DomainMessage implements java.io.Serializable
{
  public String colour;
}
