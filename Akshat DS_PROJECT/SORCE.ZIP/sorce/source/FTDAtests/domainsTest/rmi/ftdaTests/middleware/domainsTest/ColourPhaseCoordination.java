package ftdaTests.middleware.domainsTest;

import ftda.middleware.domains.PhaseCoordination;

public class ColourPhaseCoordination extends PhaseCoordination implements java.io.Serializable
{
  public int phase;
  public int nextPhase;
  public int numPhases;
}
