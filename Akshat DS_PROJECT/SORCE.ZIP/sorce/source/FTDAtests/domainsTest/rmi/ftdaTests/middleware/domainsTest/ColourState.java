package ftdaTests.middleware.domainsTest;

import ftda.middleware.domains.State;

public class ColourState implements State, java.io.Serializable
{
  public String chain;
}
