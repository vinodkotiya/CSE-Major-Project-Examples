package ftdaTests.middleware.domainsTest;

import ftda.middleware.domains.State;

public class ColoursStates implements State, java.io.Serializable
{
  public String[] chain;
}
