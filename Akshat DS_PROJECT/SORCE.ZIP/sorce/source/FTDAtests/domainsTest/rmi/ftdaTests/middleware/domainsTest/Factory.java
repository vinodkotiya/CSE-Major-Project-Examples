package ftdaTests.middleware.domainsTest;


public class Factory
{
  public ColourState createState(String substate)
  {
    return new ColourStateImpl(substate);
  }

  public ColoursStates createState(String substates[])
  {
    return new ColoursStatesImpl(substates);
  }

  public ColourPhaseCoordination createCoordinationPhase(int phase, int nextPhase, int numPhases, boolean ended)
  {
    return new ColourPhaseCoordinationImpl(phase, nextPhase, numPhases, ended);
  }

  public AddColourMessage createAddColourMessage(int subgroup, String colour)
  {
    return new AddColourMessageImpl(subgroup, colour);
  }

  public RemColourMessage createRemColourMessage(int subgroup)
  {
    return new RemColourMessageImpl(subgroup);
  }

  public ColourDynamicSubgroupInfo createColourDynamicSubgroupInfo(String info, StateTransferType type, String substates[])
  {
    return new ColourDynamicSubgroupInfoImpl(info, type, createState(substates));
  }

//*************************************************************************************//
//**************************** INNER CLASSES *******************************************//
//*************************************************************************************//

  static class ColourPhaseCoordinationImpl extends ColourPhaseCoordination
  {
    public ColourPhaseCoordinationImpl(){}
    public ColourPhaseCoordinationImpl (int p, int next, int nP, boolean finished)
      {phase=p;nextPhase=next;numPhases=nP;transferFinished=finished;}
  }

  static class ColoursStatesImpl extends ColoursStates
  {
    public ColoursStatesImpl (String substates[]) {chain=substates;}
  }

  static class ColourStateImpl extends ColourState
  {
    public ColourStateImpl (String substate) {chain=substate;}
  }

  static class AddColourMessageImpl extends AddColourMessage
  {
    public AddColourMessageImpl(int subgroup, String colour)
    {
      this.subgroup=subgroup;
      this.colour=colour;
    }
  }

  static class RemColourMessageImpl extends RemColourMessage
  {
    public RemColourMessageImpl(int subgroup)
    {
      this.subgroup=subgroup;
    }
  }

  static class ColourDynamicSubgroupInfoImpl extends ColourDynamicSubgroupInfo
  {
    public ColourDynamicSubgroupInfoImpl(String info, StateTransferType type, ColoursStates state)
    {
      this.info=info;
      this.transferType=type;
      this.initialState=state;
    }
  }

}
