package ftdaTests.middleware.domainsTest;

public class MiddlewareInitialitation
{
  public static void init(Runnable realMain, String args[]) throws Exception
  {
    realMain.run();
  }
}

