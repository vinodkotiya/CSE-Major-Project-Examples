package ftdaTests.middleware.domainsTest;

import ftda.middleware.domains.DomainMessage;

public class RemColourMessage extends DomainMessage implements java.io.Serializable
{
}
