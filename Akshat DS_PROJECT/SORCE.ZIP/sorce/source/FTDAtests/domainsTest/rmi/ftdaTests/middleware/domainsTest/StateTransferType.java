package ftdaTests.middleware.domainsTest;

final public class StateTransferType implements java.io.Serializable
{
    private static StateTransferType [] values_ = new StateTransferType[5];
    private int value_;

    public final static int _StateHandler = 0;
    public final static StateTransferType StateHandler = new StateTransferType(_StateHandler);
    public final static int _BasicStateHandler = 1;
    public final static StateTransferType BasicStateHandler = new StateTransferType(_BasicStateHandler);
    public final static int _ExtendedCheckpointable = 2;
    public final static StateTransferType ExtendedCheckpointable = new StateTransferType(_ExtendedCheckpointable);
    public final static int _Checkpointable = 3;
    public final static StateTransferType Checkpointable = new StateTransferType(_Checkpointable);
    public final static int _StatelessTransfer = 4;
    public final static StateTransferType StatelessTransfer = new StateTransferType(_StatelessTransfer);

    protected
    StateTransferType(int value)
    {
        values_[value] = this;
        value_ = value;
    }

    public int
    value()
    {
        return value_;
    }

    public int
    hash()
    {
        return value_;
    }

    protected Object readResolve() throws java.io.ObjectStreamException
    {
      return values_[value_];
    }

    public static StateTransferType
    from_int(int value)
    {
        return values_[value];
    }
}
