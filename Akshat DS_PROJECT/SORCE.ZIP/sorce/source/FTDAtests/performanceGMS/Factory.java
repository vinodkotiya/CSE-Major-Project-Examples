package ftdaTests.performanceGMS;

import ftda.middleware.gms.Message;

public interface Factory
{
  public Message createMessage();
};
