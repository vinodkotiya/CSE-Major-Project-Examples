package ftdaTests.performanceGMS;

class Performance
{
  public Performance()
  {
    times = new long[MEASURES+1];
    total = new int[MEASURES+1];
    max=0;
    time0=System.currentTimeMillis();
  }

  int speed()
  {
    return max>1? (int)(1000.0*((double)total[0]-total[max-1])/((double)times[0]-times[max-1])) : 0;
  }

  int totalSpeed()
  {
    return max>1? (int)(1000.0*((double)total[0])/((double)times[0]-time0)) : 0;
  }

  void addMeasure(int measure)
  {
    for (int i=max;i>0;--i)
    {
      times[i]=times[i-1];
      total[i]=total[i-1];
    }
    if (max<MEASURES)
      ++max;
    total[0]=measure;
    times[0]=System.currentTimeMillis();
  }

  static int MEASURES=10;
  long times[],time0;
  int total[];
  int max;
};
