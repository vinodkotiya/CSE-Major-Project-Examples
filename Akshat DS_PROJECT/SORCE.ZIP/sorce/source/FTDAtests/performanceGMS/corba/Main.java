package ftdaTests.performanceGMS.corba;

import ftdaTests.performanceGMS.Factory;
import ftdaTests.performanceGMS.Stresser;
import ftda.middleware.gms.Message;
import ftda.middleware.gms.MessageHelper;
import ftda.middleware.util.ORBcentral;

import org.omg.CORBA.portable.ValueFactory;
import org.omg.CORBA_2_3.ORB;
import org.omg.CORBA_2_3.portable.InputStream;


public class Main implements Factory
{
  public Message createMessage()
  {
    return new Message(){};
  }

  public static void main(String[] args) throws Exception
  {
    if (args.length!=2)
      System.out.println("Usage: 2 parameters, the name, and the period to send messages (milliseconds)");
    else
    {
      int n = Integer.valueOf(args[1]).intValue();
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args, System.getProperties());
      ORBcentral.setORB(orb);
      ((org.omg.CORBA_2_3.ORB)orb).register_value_factory
      (
        MessageHelper.id(),
        new ValueFactory(){public java.io.Serializable read_value(InputStream in){return in.read_value(new Message(){});}}
      );
      Stresser stresser1 = new Stresser(args[0],n, new Main());
      orb.run();
    }
  }
}
