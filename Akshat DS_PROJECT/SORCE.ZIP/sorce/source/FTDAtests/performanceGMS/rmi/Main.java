package ftdaTests.performanceGMS.rmi;

import ftdaTests.performanceGMS.Factory;
import ftdaTests.performanceGMS.Stresser;
import ftda.middleware.gms.Message;

public class Main implements Factory
{
  public Message createMessage()
  {
    return new Message(){};
  }

  public static void main(String[] args)
  {
    if (args.length!=2)
      System.out.println("Usage: 2 parameters, the name, and the period to send messages (milliseconds)");
    else
    {
      try
      {
        int n = Integer.valueOf(args[1]).intValue();
        Stresser stresser1 = new Stresser(args[0],n, new Main());
      }
      catch(Exception ex)
      {
        ex.printStackTrace();
      }
    }
  }
}
