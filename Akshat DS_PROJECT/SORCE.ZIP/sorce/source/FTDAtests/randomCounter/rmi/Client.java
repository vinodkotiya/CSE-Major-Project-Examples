package ftdaTests.randomCounter.rmi;

import ftda.middleware.gmns.GroupMembershipNamingService;
import ftda.middleware.gmns.ReplicatedServer;

class Client
{
  public Client(GroupMembershipNamingService service, String groupName) throws Exception
  {
    ReplicatedServer toCastServer = (ReplicatedServer) service.getValidGroupServer(groupName);
    RandomCounterServer server = (RandomCounterServer) toCastServer;
    if (server==null)
    {
      System.err.println("Error: no server found on the group " + groupName);
    }
    else
    {
      System.out.println("Requesting unique number...");
      int number = server.getNumber();
      System.out.println("Number served: " + number);
    }
  }
}

