package ftdaTests.randomCounter.rmi;

import ftda.util.Configuration;
import ftda.util.Parameters;
import ftda.util.ParameterException;
import ftda.gmns.GroupMembershipNamingServiceFactory;
import ftda.middleware.gmns.GroupMembershipNamingService;

import java.io.IOException;
import java.util.Vector;

public class Main
{
  public Main(String args[])
  {
    Parameters parameters = readArgs(args);
    if (parameters!=null)
    {
      try
      {
        GroupMembershipNamingService service = GroupMembershipNamingServiceFactory.load();
        if (service==null)
        {
          System.err.println("GroupMembershipNamingService is not available");
        }
        else
        {
          if (parameters.hasParameter(SERVER))
          {
            new Server(service, parameters.getArgument(0));
          }
          else
          {
            new Client(service, parameters.getArgument(0));
            System.exit(0);
          }
        }
      }
      catch(ParameterException ex)
      {
        System.out.println(ex);
      }
      catch(Exception ex)
      {
        ex.printStackTrace();
      }
    }
  }

  //*************************************************************************************
  //**************************** READ ARGS **********************************************
  //*************************************************************************************

  /**
    * Reads the command line arguments, and initializes the
    * Configuration singleton class; arguments are translated into the Parameter class and
    * returned.
    * It returns null if arguments are incorrect or they do not require any GMNS processing
    **/
  Parameters readArgs(String args[])
  {
    Parameters ret = null;
    try
    {
      Vector params=new Vector();
      params.add(CONF);
      params.add(SERVER);
      params.add(HELP);

      ret = new Parameters(args, params, null,1,1);
      if (ret.hasParameter(HELP))
      {
        ret=null;
        help();
      }
      else
      {
        if (ret.hasParameter(CONF))
          Configuration.getSingleton(ret.getParameter(CONF), ret.getDefinitions());
        else
          Configuration.getSingleton(ret.getDefinitions());
      }
    }
    catch (ParameterException pex)
    {
      System.err.println("Arguments error: " + pex.getMessage());
      help();
    }
    catch (IOException ioex)
    {
      System.err.println("Error reading the configuration file: " + ioex.getMessage());
    }
    return ret;
  }

  //*************************************************************************************
  //**************************** HELP ***************************************************
  //*************************************************************************************

  static void help()
  {
      System.out.println("arguments: [options...] groupName\n\tOptions:\n\t\t"
        + CONF + "=configuration file\n\t\t\t--> ftda properties file \n\t\t"
        + SERVER + "\n\t\t\t--> indicates weather the counter behaves as a client or a server\n\t\t"
        + HELP + "\n\t\t\t--> shows this brief help \n\n\t"
      );
  }

  //*************************************************************************************
  //**************************** DATA MEMBERS *******************************************
  //*************************************************************************************

  static final String CONF      = "config";
  static final String SERVER    = "server";
  static final String HELP      = "help";


  public static void main(String args[])
  {
    new Main(args);
  }
}
