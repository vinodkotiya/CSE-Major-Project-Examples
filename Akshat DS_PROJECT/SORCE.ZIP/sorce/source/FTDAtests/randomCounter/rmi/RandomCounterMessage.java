package ftdaTests.randomCounter.rmi;

import ftda.middleware.gms.Message;

public class RandomCounterMessage extends Message
{
  public int randomNumber;
  public int messageId;
}
