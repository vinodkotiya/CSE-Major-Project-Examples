package ftdaTests.randomCounter.rmi;

import ftda.middleware.gmns.ReplicatedServer;

import java.rmi.RemoteException;

public interface RandomCounterServer extends ReplicatedServer
{
  public int getNumber() throws RemoteException;
}
