package ftdaTests.testerGMNS;

import ftda.gmns.*;
import ftda.util.*;
import ftda.middleware.gms.*;
import ftda.middleware.gmns.*;

import java.util.Timer;
import java.util.TimerTask;

class TestGroupMember extends GroupMemberImpl
{
  public TestGroupMember(String group, String name, int live) throws Exception
  {
    this.name=name;
    this.group=group;
    this.live=live;
  }

  public void changingView(){}
  public void installView(View parm1){}
  public void processCastMessage(int parm1, Message parm2){}
  public void processPTPMessage(int parm1, Message parm2){}
  public void excludedFromGroup()
  {
    System.out.println("["+group+"]<<"+name);
    group=name=null;
    handler=null;
  }
  public void memberAccepted(int parm1, GroupHandler handler, View parm3)
  {
    System.out.println("["+group+"]>>"+name);
    this.handler=handler;
    new Timer(false).schedule(new Leaver(),live*1000);
  }

  class Leaver extends TimerTask
  {
    public void run()
    {
      try
      {
        if (handler!=null)
        {
          System.out.println(".........................["+group+"]--"+name);
          handler.leaveGroup();
        }
      }
      catch(Exception ex)
      {
      }
    }
  }

  String name, group;
  GroupHandler handler;
  int live;
}

