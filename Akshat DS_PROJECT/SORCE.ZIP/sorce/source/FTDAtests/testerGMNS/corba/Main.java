package ftdaTests.testerGMNS.corba;

import ftdaTests.testerGMNS.Tester;

import ftda.util.Parameters;
import ftda.util.ParameterException;
import org.omg.CORBA.ORB;

import ftda.middleware.util.ORBcentral;

public class Main
{
  public Main(String args[])
  {
    Parameters parameters = Tester.readArgs(args);
    if (parameters!=null)
    {
      ORB orb = null;
      try
      {
        orb = ORB.init(args, System.getProperties());

        ORBcentral.setORB(orb);

        new Tester(parameters);
        orb.run();
      }
      catch(ParameterException ex)
      {
        System.out.println(ex);
      }
      catch(Exception ex)
      {
        ex.printStackTrace();
      }
      if (orb!=null)
        try {orb.destroy();}catch(Exception ex){}
    }
  }

  public static void main(String args[])
  {
    new Main(args);
  }
}
