package ftdaTests.testerGMNS.rmi;

import ftdaTests.testerGMNS.Tester;

import ftda.util.Parameters;
import ftda.util.ParameterException;

public class Main
{
  public Main(String args[])
  {
    Parameters parameters = Tester.readArgs(args);
    if (parameters!=null)
    {
      try
      {
        new Tester(parameters);
      }
      catch(ParameterException ex)
      {
        System.out.println(ex);
      }
      catch(Exception ex)
      {
        ex.printStackTrace();
      }
    }
  }

  public static void main(String args[])
  {
    new Main(args);
  }
}
